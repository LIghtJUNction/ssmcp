#!/usr/bin/python3
"""Prepare evidence for the pinned, unpublished native listener feature cohort."""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import signal
import stat
import subprocess
import tarfile
import time
import tomllib


REPO = Path("/home/lightjunction/Documents/GITHUB/zcalld")
FEATURE = REPO / ".worktrees/ssmcp-listener-p1-20261120"
REVISION = "ef4394ac0928cd53cda5f25862851465ca97f009"
PARENTS = ("d722eb3732f6efb476184a1211e05fb8c8bc5e4a",
           "31e55247bb44e4e4d06f3a5f4638e5a953ea9427")
GITLINKS = {
    "apps/zcall-gui": "e6ed24bdd5d7d193d76fc03a53d2bc1e10edec74",
    "apps/zcall-omarchy": "7db52e74ceb6c9d398791406e01265eecc127f87",
    "extensions/compat": "be72b3aa3ef17032a360ea5b9a9d38fe40c4b622",
    "vendor/zcall": "45df84f93848a9f7dc66eb7da953d18d14bb08f7",
    "vendor/zconv": "0af1f7eb0766ff0ce9db5cee7c6184eff511a8c1",
    "vendor/zplugin": "00d566eedcff7b2932e90b9dfeb44910c783d305",
    "vendor/zsys": "808fcfdb73584ca7ca122e20b76f0209f56ab0f7",
}
MODULES = {
    "extensions/compat": REPO / "extensions/compat",
    **{path: REPO / ".git/modules" / path for path in GITLINKS if path.startswith("vendor/")},
}
ROOT = Path("/var/tmp/ssmcp-zcalld-ef439-feature-gate-20261120")
CARGO_LOCK = Path("/var/tmp/ssmcp-iteration-converge-20261120/isolated-target/.root-gate.lock")
RUST_CHAIN = Path("/home/lightjunction/.rustup/toolchains/1.100.0-x86_64-unknown-linux-gnu")
RUST_WRAPPER = Path("/home/lightjunction/.cargo/rustc-serial")
RUST_LOCK = RUST_WRAPPER.with_suffix(".lock")
CARGO_DONOR = Path("/var/tmp/ssmcp-zcalld-release-prep-20261120/attempt-02/cargo-home/registry")
GO_ROOT = Path("/usr/lib/go")
GO_DONOR = Path("/home/lightjunction/go/pkg/mod/cache/download")
BUN = Path("/home/lightjunction/.bun/bin/bun")
SYSTEM = Path("/usr/bin")
HOSTNAME = "zcalld-ef439-fixture"
ADDRESS = "192.0.2.42"
HELPER_SHA256 = "767e5581d0b18f3fe4b2ab58e7825a65500dff7e0224acc1143249124bff0ef2"
REVIEWED_TOOLS = {
    "bun": "21c4ace204eed2c3fa02eadef0d3b744fc7f6a2ae255d5bb3de4f4797f7d4402",
    "go": "2ffad463dade83f99b9c601073826e6d8efd47e1a56b36927b1314e74d6d7fdd",
    "rustc-wrapper": "8b61096a9869fc6e790c963715efded612b17583cee90c830aadda2da8917a43",
}
VERSION = "0.4.0"
TARGET = "x86_64-unknown-linux-gnu"
STEM = f"zcalld-{VERSION}-{TARGET}"
RUST_ARTIFACTS = (
    "zcalld", "libzcalld_aliases.so", "libzcalld_policy.so", "libzcalld_redact.so",
    "libzcalld_community.so", "libzcalld_plugin_routing.so",
)
GO_ARTIFACTS = ("zcalld-pluginctl", "zcalld-privacy")
GO_MODULES = {
    "github.com/clipperhouse/uax29/v2": "v2.5.0",
    "github.com/clipperhouse/stringish": "v0.1.1",
    "golang.org/x/net": "v0.56.0",
    "golang.org/x/sys": "v0.49.0",
    "gopkg.in/yaml.v3": "v3.0.1",
}
STAGES = (
    "preflight", "cargo-lock", "worktree", "vendors", "freeze-source", "private-caches",
    "tool-versions", "network-preflight", "rust-wrapper-preflight", "fmt", "clippy",
    "workspace-tests", "release-build",
    "release-check", "release-transactions", "freeze-rust", "go-pluginctl", "go-privacy",
    "freeze-go", "http", "transport", "control", "keys", "library", "cutover",
    "codex-metadata", "codex-compaction", "shellcheck", "native-package", "staged-install",
    "staged-reinstall", "integrity",
)
DOCS = ("ssmcp-listener.md", "ssmcp-listener-validation.md")


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def metadata(path):
    path = Path(path)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        need(stat.S_ISREG(info.st_mode), f"expected a regular file: {path}")
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"path": str(path), "bytes": info.st_size, "mode": stat.S_IMODE(info.st_mode),
            "sha256": digest}


def write_json(path, value):
    scratch = path.with_suffix(".writing")
    with scratch.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, sort_keys=True)
        stream.write("\n")
    scratch.replace(path)


def safe_path(name):
    path = PurePosixPath(name)
    need(path.parts and path.as_posix() == name and not path.is_absolute()
         and not {".git", ".."}.intersection(path.parts), f"unsafe source path: {name!r}")
    return path


def stored_tree(root):
    """Return a no-follow inventory for derived outputs, including empty directories."""
    rows = {}
    for path in sorted(root.rglob("*")):
        info = path.lstat()
        name = path.relative_to(root).as_posix()
        mode = stat.S_IMODE(info.st_mode)
        if stat.S_ISDIR(info.st_mode):
            rows[name] = {"type": "directory", "mode": mode}
        elif stat.S_ISLNK(info.st_mode):
            rows[name] = {"type": "symlink", "target": os.readlink(path), "mode": mode}
        else:
            rows[name] = metadata(path)
    return rows


def git_environment():
    return {
        "GIT_CONFIG_GLOBAL": "/dev/null", "GIT_CONFIG_NOSYSTEM": "1", "GIT_ATTR_NOSYSTEM": "1",
        "GIT_NO_REPLACE_OBJECTS": "1", "GIT_NO_LAZY_FETCH": "1", "GIT_ALLOW_PROTOCOL": "file",
        "GIT_TERMINAL_PROMPT": "0", "GIT_OPTIONAL_LOCKS": "0",
    }


def stop_owned(process):
    if process.poll() is not None:
        return
    for signum, grace in ((signal.SIGTERM, 5), (signal.SIGKILL, 5)):
        try:
            os.killpg(process.pid, signum)
        except ProcessLookupError:
            pass
        try:
            process.wait(timeout=grace)
            return
        except subprocess.TimeoutExpired:
            continue
    raise RuntimeError("owned process group did not exit after TERM/KILL")


class Gate:
    def __init__(self, args):
        self.args = args
        self.root = args.out
        self.source = self.root / "source"
        self.logs = self.root / "logs"
        self.out = self.root / "evidence"
        self.dist = self.root / "dist"
        self.target = self.root / "target"
        self.cargo = self.root / "cargo-home"
        self.go_cache = self.root / "go-build-cache"
        self.go_path = self.root / "go"
        self.go_mod = self.root / "go-mod-cache"
        self.go_output = self.root / "go-output"
        self.installed = self.root / "staged-install"
        self.frozen = self.root / "frozen/release"
        self.inputs = self.root / "frozen/inputs"
        self.manifest_path = self.root / "source-manifest.json"
        self.before = None
        self.received = None
        self.guard = None
        self.row = None
        self.log = None
        self.tools = {}
        self.object_stores = {}
        self.original_object_paths = {}
        self.attested = {}
        self.report = {
            "revision": REVISION, "parents": list(PARENTS), "version": VERSION,
            "scope": "unpublished independent native-listener feature cohort, not official zcalld 0.4.0",
            "status": "running", "run_root": str(self.root),
            "stages": [{"name": name, "status": "not_run", "exit_code": None} for name in STAGES],
            "binaries": {}, "source_unchanged": False, "binaries_unchanged": False,
            "started_at": time.time(),
        }

    def save(self):
        write_json(self.root / "gate-report.json", self.report)

    def check_signal(self):
        need(self.received is None, f"gate interrupted by signal {self.received}")

    def stage(self, name, action):
        row = next(row for row in self.report["stages"] if row["name"] == name)
        need(row["status"] == "not_run", f"stage repeated: {name}")
        self.row = row
        self.report["active_stage"] = name
        path = self.logs / f"{name}.log"
        row.update(status="running", log=str(path), commands=[])
        self.save()
        print(json.dumps({"started": name, "log": str(path)}), flush=True)
        started = time.monotonic()
        try:
            with path.open("xb", buffering=0) as log:
                self.log = log
                try:
                    self.check_signal()
                    action()
                    self.check_signal()
                except BaseException as error:
                    log.write((f"{type(error).__name__}: {error}\n").encode())
                    raise
            row.update(status="passed", exit_code=0)
        except BaseException as error:
            last = row["commands"][-1].get("exit_code") if row["commands"] else None
            row.update(status="failed", exit_code=last if type(last) is int and last else 1,
                       error=f"{type(error).__name__}: {error}")
            raise
        finally:
            self.log = None
            row["seconds"] = round(time.monotonic() - started, 3)
            if path.is_file():
                row["log_sha256"] = metadata(path)["sha256"]
            self.save()

    def command(self, args, *, cwd=None, capture=False, timeout=300):
        self.check_signal()
        argv = list(map(str, args))
        detail = {"argv": argv, "cwd": str(cwd or self.root), "exit_code": None}
        self.row["commands"].append(detail)
        process = subprocess.Popen(argv, cwd=cwd or self.root, env=self.host_env,
                                   stdin=subprocess.DEVNULL,
                                   stdout=subprocess.PIPE if capture else self.log,
                                   stderr=self.log, start_new_session=True)
        deadline = time.monotonic() + timeout
        output = None
        try:
            while True:
                self.check_signal()
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    detail["timed_out"] = True
                    raise TimeoutError(f"command exceeded {timeout}s: {argv[0]}")
                try:
                    output, _ = process.communicate(timeout=min(0.5, remaining))
                    break
                except subprocess.TimeoutExpired:
                    continue
            if capture:
                self.log.write(output)
            need(process.returncode == 0, f"command exited {process.returncode}: {argv[0]}")
            return output
        finally:
            try:
                stop_owned(process)
                if capture and output is None:
                    try:
                        partial, _ = process.communicate(timeout=2)
                    except subprocess.TimeoutExpired as error:
                        partial = error.output or b""
                    self.log.write(partial)
            finally:
                detail["exit_code"] = process.returncode

    def git(self, repo, *args):
        # Some vendor object stores are standalone Git directories with a
        # worktree setting referring to the primary checkout. Override cwd.
        git = [SYSTEM / "git", "-c", "core.fsmonitor=false"]
        if (repo / "objects").is_dir():
            git += [f"--git-dir={repo}", f"--work-tree={self.root}"]
        else:
            git += ["-C", repo]
        return self.command([*git, *args], capture=True, timeout=120)

    def attest(self, path):
        row = metadata(path)
        need(self.attested.setdefault(str(path), row) == row, f"previously verified input changed: {path}")
        return row

    def freeze(self, origin, destination, mode):
        origin = Path(origin).resolve(strict=True)
        before = self.attest(origin)
        with origin.open("rb") as source, destination.open("xb") as output:
            shutil.copyfileobj(source, output)
        destination.chmod(mode)
        frozen = self.attest(destination)
        need(frozen["sha256"] == before["sha256"], f"input changed while freezing {origin}")
        return {**frozen, "origin": before}

    def environment(self, *, rust=False, go=False, packaging=False, install=False):
        env = {
            "PATH": f"{RUST_CHAIN / 'bin'}:/usr/bin:/bin" if rust else "/usr/bin:/bin",
            "HOME": "/tmp/home", "TMPDIR": "/tmp",
            "XDG_CONFIG_HOME": "/tmp/config", "XDG_CACHE_HOME": "/tmp/cache",
            "XDG_DATA_HOME": "/tmp/data", "XDG_STATE_HOME": "/tmp/state",
            "XDG_RUNTIME_DIR": "/tmp/runtime",
            "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8", "TZ": "UTC",
            "PYTHONDONTWRITEBYTECODE": "1", "GIT_CONFIG_COUNT": "0",
            **git_environment(),
        }
        if rust:
            env.update(CARGO_HOME=str(self.cargo), CARGO_TARGET_DIR=str(self.target),
                       CARGO_NET_OFFLINE="true", CARGO_BUILD_JOBS="1", CARGO_INCREMENTAL="0",
                       CARGO_PROFILE_DEV_DEBUG="0", CARGO_PROFILE_TEST_DEBUG="0",
                       CARGO_TERM_COLOR="never", RUSTC=str(RUST_CHAIN / "bin/rustc"),
                       RUSTFMT=str(RUST_CHAIN / "bin/rustfmt"), RUSTC_WRAPPER=str(RUST_WRAPPER))
        if go:
            env.update(GOROOT=str(GO_ROOT), GOPATH=str(self.go_path), GOMODCACHE=str(self.go_mod),
                       GOCACHE=str(self.go_cache), GOENV="off", GOWORK="off",
                       GOTOOLCHAIN="local", GOPROXY="off", GOSUMDB="off", GOVCS="*:off",
                       CGO_ENABLED="0")
        if packaging:
            env.update(CARGO_TARGET_DIR=str(self.frozen.parent), SOURCE_DATE_EPOCH=self.epoch)
        if install:
            env.update(PREFIX="/usr", DESTDIR=str(self.installed))
        if self.report["binaries"].get("zcalld"):
            env["ZCALLD_TEST_BINARY"] = str(self.frozen / "zcalld")
        return env

    def sandbox(self, args, *, cwd=None, rust=False, go=False, lan=False, evidence=False,
                packaging=False, install=False, capture=False, timeout=300):
        # Keep Unix fixture socket paths short and keep all stage scratch owned.
        scratch = self.root / "tmp" / self.row["name"]
        if not scratch.exists():
            scratch.mkdir(mode=0o700)
            for name in ("home", "config", "cache", "data", "state", "runtime"):
                (scratch / name).mkdir(mode=0o700)
        # LAN setup is privileged only inside the new user/network namespace.
        uid, gid = (0, 0) if lan else (os.getuid(), os.getgid())
        cmd = [SYSTEM / "bwrap", "--unshare-user", "--uid", str(uid),
               "--gid", str(gid), "--unshare-net", "--unshare-pid",
               "--unshare-ipc", "--unshare-uts", "--hostname", HOSTNAME,
               "--new-session", "--die-with-parent", "--clearenv", "--ro-bind", "/", "/",
               "--proc", "/proc", "--dev", "/dev", "--tmpfs", "/run", "--tmpfs", "/home",
               "--tmpfs", "/root", "--bind", scratch, "/tmp",
               "--ro-bind", self.inputs / "hosts", "/etc/hosts",
               "--ro-bind", self.inputs / "nsswitch.conf", "/etc/nsswitch.conf"]
        if rust:
            cmd += ["--ro-bind", RUST_CHAIN, RUST_CHAIN,
                    "--ro-bind", self.inputs / "rustc-serial", RUST_WRAPPER,
                    "--ro-bind", RUST_LOCK, RUST_LOCK,
                    "--bind", self.cargo, self.cargo, "--bind", self.target, self.target]
        if go:
            for path in (self.go_mod, self.go_cache, self.go_path, self.go_output):
                cmd += ["--bind", path, path]
        if lan:
            cmd += ["--cap-add", "CAP_NET_ADMIN"]
        if evidence:
            cmd += ["--bind", self.out, self.out]
        if packaging:
            cmd += ["--bind", self.dist, self.source / "dist"]
        if install:
            cmd += ["--bind", self.installed, self.installed]
        if Path("/etc/zcalld").is_dir():
            cmd += ["--tmpfs", "/etc/zcalld", "--remount-ro", "/etc/zcalld"]
        cmd += ["--remount-ro", "/run", "--remount-ro", "/root", "--remount-ro", "/home",
                "--chdir", cwd or self.source]
        for key, value in self.environment(rust=rust, go=go, packaging=packaging, install=install).items():
            cmd += ["--setenv", key, value]
        return self.command([*cmd, "--", *args], capture=capture, timeout=timeout)

    def preflight(self):
        need(os.uname().sysname == "Linux" and os.uname().machine == "x86_64",
             "this feature gate requires Linux x86_64")
        driver = Path(__file__).resolve(strict=True)
        need(metadata(driver)["sha256"] == self.args.controller_sha256,
             "controller bytes differ from the reviewed SHA-256")
        helper = driver.with_name("feature_fixture.py")
        need(metadata(helper)["sha256"] == HELPER_SHA256, "feature fixture helper hash differs")
        tools = {
            **{name: SYSTEM / name for name in ("python3", "git", "bwrap", "ip", "findmnt",
                                               "shellcheck", "bash", "sh", "install", "flock",
                                               "cc", "ld", "ar")},
            **{name: RUST_CHAIN / "bin" / name for name in
               ("cargo", "rustc", "rustfmt", "cargo-fmt", "cargo-clippy", "clippy-driver")},
            "go": GO_ROOT / "bin/go",
            **{f"go-{name}": GO_ROOT / "pkg/tool/linux_amd64" / name
               for name in ("compile", "asm", "link")},
            "bun": BUN, "rustc-wrapper": RUST_WRAPPER,
        }
        for name, path in tools.items():
            need(path.is_file() and os.access(path, os.X_OK), f"missing required tool {name}: {path}")
            self.tools[name] = {"requested_path": str(path), **self.attest(path.resolve())}
        need(all(self.tools[name]["sha256"] == expected for name, expected in REVIEWED_TOOLS.items()),
             "the reviewed Bun, Go, or compiler wrapper changed")
        self.report["tools"] = self.tools
        for lock in (CARGO_LOCK, RUST_LOCK):
            info = lock.lstat()
            need(stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid(), f"unowned lock: {lock}")
        need(os.access(RUST_LOCK, os.R_OK), f"cannot read the normal compiler lock: {RUST_LOCK}")
        self.rust_lock_identity = (RUST_LOCK.stat().st_dev, RUST_LOCK.stat().st_ino)
        self.report["compiler_lock"] = {"path": str(RUST_LOCK), "wrapper": str(RUST_WRAPPER),
                                        "read_only_bind_during_cargo_only": True}
        self.go_cache_files = [GO_DONOR / module / "@v" / f"{version}.{suffix}"
                               for module, version in GO_MODULES.items()
                               for suffix in ("info", "mod", "zip", "ziphash")]
        self.cargo_cache_dirs = [CARGO_DONOR / name for name in ("cache", "index")]
        # Limit the copy to package/index cache data. No donor configuration,
        # credential files, extracted sources, VCS cache or Go global environment.
        copies = [self.tools["bun"]["bytes"]]
        for path in self.go_cache_files:
            copies.append(metadata(path)["bytes"])
        for directory in self.cargo_cache_dirs:
            need(directory.is_dir() and not directory.is_symlink(), f"missing Cargo donor: {directory}")
            for path in directory.rglob("*"):
                info = path.lstat()
                need(stat.S_ISDIR(info.st_mode) or stat.S_ISREG(info.st_mode),
                     f"unsupported Cargo cache entry: {path}")
                if stat.S_ISREG(info.st_mode):
                    need(path.name not in {"credentials", "credentials.toml", "auth.json", ".netrc",
                                           ".git-credentials"}, f"unexpected auth entry: {path}")
                    copies.append(info.st_size)
        for repo in (REPO, *MODULES.values()):
            objects = Path(os.fsdecode(self.git(repo, "rev-parse", "--path-format=absolute",
                                                 "--git-path", "objects").rstrip(b"\n")))
            need(objects.is_dir() and not (objects / "info/alternates").exists(),
                 f"expected a self-contained local object donor: {objects}")
            self.original_object_paths[repo] = objects
            copies.extend(path.stat().st_size for path in objects.rglob("*") if path.is_file())
        mount = self.command([SYSTEM / "findmnt", "--json", "--target", self.root,
                              "--output", "TARGET,SOURCE,FSTYPE,OPTIONS"], capture=True)
        space = os.statvfs(self.root)
        available = space.f_bavail * space.f_frsize
        reserve = self.args.build_reserve_gib * 1024**3
        self.report["storage"] = {"mount": json.loads(mount), "available_bytes": available,
                                  "copy_input_bytes": sum(copies), "build_reserve_bytes": reserve}
        need(available >= sum(copies) + reserve, "insufficient free space for private copies/build reserve")
        self.host_netns = os.readlink("/proc/self/ns/net")
        self.report["input_files"] = {
            "controller": self.freeze(driver, self.inputs / "gate.py", 0o400),
            "fixture_helper": self.freeze(helper, self.inputs / "feature_fixture.py", 0o400),
        }
        need(self.report["input_files"]["controller"]["sha256"] == self.args.controller_sha256
             and self.report["input_files"]["fixture_helper"]["sha256"] == HELPER_SHA256,
             "reviewed preparation changed during freezing")
        self.tools["bun"]["frozen"] = self.freeze(BUN, self.inputs / "bun", 0o500)
        self.tools["rustc-wrapper"]["frozen"] = self.freeze(
            RUST_WRAPPER, self.inputs / "rustc-serial", 0o500)
        for name, contents in (
            ("hosts", f"127.0.0.1 localhost\n::1 localhost\n{ADDRESS} {HOSTNAME}\n"),
            ("nsswitch.conf", "passwd: files\ngroup: files\nhosts: files\n"),
        ):
            path = self.inputs / name
            path.write_text(contents, encoding="ascii")
            path.chmod(0o400)
            self.report["input_files"][name] = self.attest(path)

    def acquire_cargo(self):
        fd = os.open(CARGO_LOCK, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
        self.guard = os.fdopen(fd, "rb")
        info = os.fstat(fd)
        need(stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid(),
             "root Cargo lock is not the expected owned file")
        deadline = time.monotonic() + self.args.lock_timeout
        waiting = False
        while True:
            self.check_signal()
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                self.report["cargo_lock"] = {"path": str(CARGO_LOCK), "status": "held",
                                             "waited": waiting}
                return
            except BlockingIOError:
                if not waiting:
                    waiting = True
                    print(f"Shared Cargo lock busy, waiting up to {self.args.lock_timeout}s", flush=True)
                need(time.monotonic() < deadline,
                     "shared Cargo lock busy; retain this receipt and retry in a fresh run directory")
                time.sleep(0.5)

    def release_cargo(self):
        if self.guard is not None:
            self.guard.close()
            self.guard = None
            if "cargo_lock" in self.report:
                self.report["cargo_lock"]["status"] = "released"

    def detached_checkout(self, origin, destination, revision):
        need(self.git(origin, "cat-file", "-t", revision).strip() == b"commit",
             f"local commit unavailable: {revision} in {origin}")
        if destination.exists():
            need(destination.is_dir() and not destination.is_symlink() and not any(destination.iterdir()),
                 f"checkout destination is not empty: {destination}")
        self.command([SYSTEM / "git", "clone", "--local", "--no-hardlinks", "--no-checkout",
                      "--no-tags", "--template=", "--", origin, destination], timeout=180)
        self.git(destination, "-c", "core.autocrlf=false", "checkout", "--detach",
                 "--no-recurse-submodules", revision)
        self.object_stores[str(destination.relative_to(self.source))] = {
            "origin": str(origin), "pin": revision, "owned_checkout": str(destination),
            "origin_objects": str(self.original_object_paths[origin]),
        }

    def checkout_main(self):
        declared = self.git(REPO, "show", "-s", "--format=%P", REVISION).decode().split()
        need(declared == list(PARENTS), "wrong candidate merge parents")
        need(self.git(FEATURE, "rev-parse", "HEAD").decode().strip() == REVISION,
             "read-only feature worktree is not at the reviewed pin")
        self.detached_checkout(REPO, self.source, REVISION)
        self.epoch = self.git(self.source, "show", "-s", "--format=%ct", REVISION).decode().strip()
        need(self.epoch.isdecimal(), "missing source-date epoch")

    def checkout_modules(self):
        exact = {name: oid for name, (mode, oid) in self.git_tree(self.source, REVISION).items()
                 if mode == b"160000"}
        need(exact == GITLINKS, "main Git links differ from the reviewed pins")
        for relative, origin in MODULES.items():
            self.detached_checkout(origin, self.source / relative, GITLINKS[relative])
        for relative in GITLINKS.keys() - MODULES.keys():
            (self.source / relative).mkdir(exist_ok=True)
        # package.py resolves ROOT/dist from its own file path. Only the
        # packaging namespace mounts mutable output over this empty marker.
        (self.source / "dist").mkdir()

    def git_tree(self, tree, pin):
        rows = {}
        for line in self.git(tree, "ls-tree", "-rz", "--full-tree", pin).split(b"\0"):
            if line:
                header, raw = line.split(b"\t", 1)
                mode, kind, oid = header.split()
                path = os.fsdecode(raw)
                safe_path(path)
                need(path not in rows and ((mode == b"160000" and kind == b"commit")
                     or (mode in (b"100644", b"100755", b"120000") and kind == b"blob")),
                     f"unexpected Git entry: {path}")
                rows[path] = (mode, oid.decode("ascii"))
        need(rows, f"empty Git tree: {tree}")
        return rows

    def source_snapshot(self):
        expected, dirs, metadata_dirs = {}, {".", "dist"}, {".git"}
        for prefix, pin in [("", REVISION), *((p, GITLINKS[p]) for p in MODULES)]:
            tree = self.source / prefix
            need((tree / ".git").is_dir() and not (tree / ".git").is_symlink(),
                 f"owned Git metadata missing: {tree}")
            need(not os.path.lexists(tree / ".git/objects/info/alternates"),
                 f"owned checkout still depends on a different object store: {tree}")
            need(self.git(tree, "rev-parse", "HEAD").decode().strip() == pin
                 and self.git(tree, "rev-parse", "--abbrev-ref", "HEAD").strip() == b"HEAD",
                 f"source is not detached at the reviewed pin: {tree}")
            self.git(tree, "diff-index", "--cached", "--quiet", pin, "--")
            entries = self.git_tree(tree, pin)
            links = {name: oid for name, (mode, oid) in entries.items() if mode == b"160000"}
            need(links == ({} if prefix else GITLINKS), f"unexpected Git links: {tree}")
            if prefix:
                metadata_dirs.add(prefix + "/.git")
            for name, (mode, oid) in entries.items():
                relative = (PurePosixPath(prefix) / name).as_posix()
                dirs.update(parent.as_posix() for parent in PurePosixPath(relative).parents)
                if mode == b"160000":
                    dirs.add(relative)
                else:
                    need(relative not in expected, f"overlapping Git trees at {relative}")
                    expected[relative] = (mode, oid)
        files, details = {}, {}
        seen_dirs = set()

        def visit(directory):
            for path in sorted(directory.iterdir()):
                relative = path.relative_to(self.source).as_posix()
                if relative in metadata_dirs:
                    need(path.is_dir() and not path.is_symlink(), f"invalid Git metadata: {relative}")
                    continue
                mode = path.lstat().st_mode
                if stat.S_ISDIR(mode):
                    need(relative in dirs, f"untracked source directory: {relative}")
                    seen_dirs.add(relative)
                    details[relative] = {"type": "directory", "mode": stat.S_IMODE(mode)}
                    visit(path)
                    continue
                need(relative in expected, f"untracked source entry: {relative}")
                git_mode, oid = expected[relative]
                detail = {"mode": stat.S_IMODE(mode), "git_mode": git_mode.decode(), "blob": oid}
                if git_mode == b"120000":
                    need(stat.S_ISLNK(mode), f"source link changed type: {relative}")
                    target = os.readlink(path)
                    need(not os.path.isabs(target)
                         and path.resolve(strict=True).is_relative_to(self.source),
                         f"source link escapes the checkout: {relative}")
                    body = os.fsencode(target)
                    detail.update(type="symlink", target=target)
                else:
                    need(stat.S_ISREG(mode) and bool(mode & 0o111) == (git_mode == b"100755"),
                         f"source file mode/type differs from Git: {relative}")
                    body = path.read_bytes()
                    detail.update(type="file", bytes=len(body))
                header = b"blob " + str(len(body)).encode("ascii") + b"\0"
                need(hashlib.sha1(header + body, usedforsecurity=False).hexdigest() == oid,
                     f"source bytes differ from Git: {relative}")
                files[relative] = hashlib.sha256(body).hexdigest()
                details[relative] = {**detail, "sha256": files[relative]}

        visit(self.source)
        need(files.keys() == expected.keys(), f"missing tracked files: {sorted(expected.keys() - files.keys())[:10]}")
        need(seen_dirs == dirs - {"."}, "missing pinned source directory")
        return {"revision": REVISION, "parents": list(PARENTS), "gitlinks": GITLINKS,
                "materialized_gitlinks": sorted(MODULES), "files": files, "entries": details,
                "object_stores": self.object_stores}

    def freeze_source(self):
        # Preserve checkout modes so packaging can write to its directory copies.
        # Bubblewrap mounts the checkout read-only during stages.
        self.before = self.source_snapshot()
        for name in ("docs/ssmcp-listener.md", "docs/ssmcp-listener-validation.md",
                     "scripts/test-codex-metadata.py", "scripts/test-codex-compaction.py",
                     "scripts/test-builtin-fetch.py",
                     "extensions/compat/cmd/zcalld-pluginctl/main.go",
                     "extensions/compat/cmd/zcalld-privacy/main.go"):
            need(name in self.before["files"], f"required fixture source is missing: {name}")
        package = tomllib.loads((self.source / "Cargo.toml").read_text())
        need(package["workspace"]["package"]["version"] == VERSION, "wrong workspace version")
        write_json(self.manifest_path, self.before)
        self.manifest_path.chmod(0o400)
        self.report["source_manifest_sha256"] = self.attest(self.manifest_path)["sha256"]
        self.report["source_files"] = len(self.before["files"])
        self.report["source_epoch"] = self.epoch

    def private_caches(self):
        copies = {}
        for directory in self.cargo_cache_dirs:
            private = self.cargo / "registry" / directory.name
            private.mkdir(parents=True)
            for path in sorted(directory.rglob("*")):
                destination = private / path.relative_to(directory)
                if path.is_dir():
                    destination.mkdir()
                else:
                    copies[str(destination)] = self.freeze(path, destination, 0o600)
        for path in self.go_cache_files:
            destination = self.go_mod / "cache/download" / path.relative_to(GO_DONOR)
            destination.parent.mkdir(parents=True, exist_ok=True)
            copies[str(destination)] = self.freeze(path, destination, 0o600)
        manifest = self.root / "cache-inputs.json"
        write_json(manifest, copies)
        manifest.chmod(0o400)
        self.report["cache_inputs"] = self.attest(manifest)

    def versions(self):
        fields = {
            "bwrap": self.command([SYSTEM / "bwrap", "--version"], capture=True),
            "ip": self.command([SYSTEM / "ip", "-Version"], capture=True),
            "shellcheck": self.command([SYSTEM / "shellcheck", "--version"], capture=True),
            "go": self.sandbox([GO_ROOT / "bin/go", "version"], go=True, capture=True),
            "bun": self.sandbox([self.inputs / "bun", "--version"], capture=True),
        }
        self.report["tool_versions"] = {name: text.decode().strip() for name, text in fields.items()}
        self.report["release_workflow_versions"] = {"go": "1.26.8", "bun": "1.4.0"}
        go_version = fields["go"].decode().strip()
        need(re.fullmatch(r"go version go1\.\d+(?:\.\d+)?(?:-[^ ]+)? linux/amd64", go_version) is not None,
             f"unexpected local Go toolchain: {go_version}")
        self.report["feature_go_version_differs"] = go_version.split()[2] != "go1.26.8"
        need(fields["bun"].strip() == b"1.4.0", "the frozen Bun version must be 1.4.0")

    def freeze_artifacts(self, origin, names):
        for name in names:
            artifact = origin / name
            need(artifact.is_file() and not artifact.is_symlink() and os.access(artifact, os.X_OK),
                 f"missing executable build artifact: {artifact}")
            self.report["binaries"][name] = self.freeze(artifact, self.frozen / name, 0o500)

    def freeze_rust(self):
        self.freeze_artifacts(self.target / "release", RUST_ARTIFACTS)
        version = self.sandbox([self.frozen / "zcalld", "--version"], capture=True).decode().strip()
        self.report["cli_version"] = version
        need(version == f"zcalld {VERSION}", "wrong frozen gateway version")

    def go_build(self, name):
        self.sandbox([GO_ROOT / "bin/go", "build", "-mod=readonly", "-trimpath",
                      "-o", self.go_output / name, f"./cmd/{name}"],
                     cwd=self.source / "extensions/compat", go=True, timeout=self.args.build_timeout)

    def validate_fixture(self, name, raw):
        report = json.loads(raw)
        need(isinstance(report, dict) and report.get("suite") == name
             and report.get("status") == "passed", f"{name} did not produce a passing fixture receipt")
        if name in ("network-preflight", "codex-metadata"):
            network = report.get("network", {})
            need(isinstance(network.get("network_namespace"), str)
                 and network["network_namespace"] != self.host_netns
                 and network.get("hostname") == HOSTNAME and network.get("resolved") == [ADDRESS]
                 and network.get("accepted_peer") == ADDRESS
                 and network.get("setup_capabilities_dropped") is True,
                 f"{name} lacks proof of a private non-loopback peer")
        if name != "network-preflight":
            count = 16 if name == "codex-metadata" else 2
            expected = report.get("expected")
            need(isinstance(expected, list) and len(expected) == count
                 and all(isinstance(item, str) and item for item in expected)
                 and len(set(expected)) == count and type(report.get("tests_run")) is int
                 and report["tests_run"] == count and type(report.get("script_exit_code")) is int
                 and report["script_exit_code"] == 0, f"{name} did not execute the exact method count")
            need(all(isinstance(report.get(field), list) and sorted(report[field]) == sorted(expected)
                     for field in ("started", "finished", "passed"))
                 and all(report.get(field) == [] for field in
                         ("failures", "errors", "skipped", "expected_failures", "unexpected_successes")),
                 f"{name} contains skipped, incomplete or failed methods")
            if name == "codex-metadata":
                lan_id = ("__main__.CodexMetadataTests."
                          "test_real_lan_peer_cannot_claim_loopback_or_another_caller_with_headers")
                need(report.get("lan_test_id") == lan_id and lan_id in report["passed"]
                     and report.get("lan_test_passed") is True, "real LAN method did not pass")
        return report

    def feature_fixture(self, name):
        path = self.out / (name + ".json")
        cli = [SYSTEM / "python3", "-B", self.inputs / "feature_fixture.py", name, self.source,
               path, self.host_netns]
        if name != "network-preflight":
            cli += ["--", "--binary", self.frozen / "zcalld",
                    "--community-plugin", self.frozen / "libzcalld_community.so",
                    "--pluginctl", self.frozen / "zcalld-pluginctl",
                    "--redact-plugin", self.frozen / "libzcalld_redact.so",
                    "--privacy-worker", self.frozen / "zcalld-privacy",
                    "--routing-plugin", self.frozen / "libzcalld_plugin_routing.so",
                    "--bun", self.inputs / "bun"]
        try:
            self.sandbox(cli, lan=name != "codex-compaction", evidence=True, timeout=900)
        finally:
            if os.path.lexists(path):
                self.row["fixture_receipt"] = self.attest(path)
        need("fixture_receipt" in self.row, f"missing {name} evidence")
        raw = path.read_bytes()
        need(hashlib.sha256(raw).hexdigest() == self.row["fixture_receipt"]["sha256"],
             f"{name} receipt changed after reading")
        self.row["fixture_summary"] = self.validate_fixture(name, raw)

    def native_package(self):
        self.python("package.py", "--no-build", "--target", TARGET, packaging=True)
        archive = self.dist / f"{STEM}.tar.gz"
        self.report["packages"] = {}
        for path in sorted(self.dist.iterdir()):
            row = metadata(path)
            path.chmod(0o500 if row["mode"] & 0o111 else 0o400)
            self.report["packages"][path.name] = self.attest(path)
        need(set(self.report["packages"]) == {STEM, archive.name}, "unexpected native package outputs")
        need(self.report["packages"][STEM]["sha256"] == self.report["binaries"]["zcalld"]["sha256"],
             "standalone package executable differs from the frozen binary")
        unpacked = self.root / "unpacked"
        unpacked.mkdir(mode=0o700)
        with tarfile.open(archive) as stream:
            self.report["package_members"] = stream.getnames()
            need(len(self.report["package_members"]) == len(set(self.report["package_members"])),
                 "native archive has duplicate members")
            stream.extractall(unpacked, filter="data")
        self.package = unpacked / STEM
        self.report["unpacked_before"] = stored_tree(unpacked)
        need((self.package / "install.sh").is_file(), "archive lacks its staged installer")

    def check_install(self):
        version = self.sandbox([self.installed / "usr/bin/zcalld", "--version"],
                               capture=True).decode().strip()
        need(version == f"zcalld {VERSION}", "wrong staged executable version")
        for name in RUST_ARTIFACTS:
            path = (self.installed / "usr/bin/zcalld" if name == "zcalld"
                    else self.installed / "usr/lib/zcalld/plugins" / name)
            need(metadata(path)["sha256"] == self.report["binaries"][name]["sha256"],
                 f"staged artifact differs from release output: {name}")
        for name in DOCS:
            path = self.installed / "usr/share/doc/zcalld/docs" / name
            need(metadata(path)["sha256"] == self.before["files"][f"docs/{name}"],
                 f"staged listener documentation missing or changed: {name}")

    def install_stage(self):
        self.sandbox([SYSTEM / "bash", "install.sh"], cwd=self.package, install=True)
        self.check_install()
        config = self.installed / "etc/zcalld/config.conf"
        self.report["installed_config_original"] = metadata(config)
        config.write_bytes(b"# owned preservation fixture\n")
        self.report["staged_install_before_reinstall"] = stored_tree(self.installed)

    def reinstall_stage(self):
        self.sandbox([SYSTEM / "bash", "install.sh"], cwd=self.package, install=True)
        self.check_install()
        config = self.installed / "etc/zcalld/config.conf"
        need(config.read_bytes() == b"# owned preservation fixture\n",
             "reinstall overwrote the owned config fixture")
        after = stored_tree(self.installed)
        need(after == self.report["staged_install_before_reinstall"],
             "reinstall changed existing package contents or modes")
        self.report["staged_install_after_reinstall"] = after

    def integrity(self):
        after = self.source_snapshot()
        write_json(self.root / "source-manifest-after.json", after)
        self.report["source_unchanged"] = after == self.before
        self.report["binaries_unchanged"] = set(self.report["binaries"]) == set((*RUST_ARTIFACTS, *GO_ARTIFACTS)) and all(
            metadata(path["path"]) == path for row in self.report["binaries"].values()
            for path in (row["origin"], {key: val for key, val in row.items() if key != "origin"}))
        baseline = self.root / "input-hashes-before.json"
        write_json(baseline, self.attested)
        self.report["inputs_before_sha256"] = metadata(baseline)["sha256"]
        post = {path: metadata(path) for path in self.attested}
        self.report["inputs_unchanged"] = post == self.attested
        need(all(Path(row["requested_path"]).resolve(strict=True) == Path(row["path"])
                 for row in self.tools.values()), "a tool path changed its resolved executable")
        write_json(self.root / "input-hashes-after.json", post)
        self.report["inputs_after_sha256"] = metadata(self.root / "input-hashes-after.json")["sha256"]
        self.report["unpacked_unchanged"] = stored_tree(self.root / "unpacked") == self.report["unpacked_before"]
        self.report["staged_install_unchanged"] = (
            stored_tree(self.installed) == self.report["staged_install_after_reinstall"])
        lock = RUST_LOCK.lstat()
        need((lock.st_dev, lock.st_ino) == self.rust_lock_identity, "compiler lock changed inode")
        need(all(self.report[key] is True for key in ("source_unchanged", "binaries_unchanged",
                 "inputs_unchanged", "unpacked_unchanged", "staged_install_unchanged")),
             "source, build, tool, report, or package inputs changed during the gate")

    def python(self, name, *args, **kwargs):
        return self.sandbox([SYSTEM / "python3", "-B", self.source / "scripts" / name, *args], **kwargs)

    def run(self):
        for path in (self.logs, self.out, self.dist, self.cargo, self.go_cache, self.go_path,
                     self.go_mod, self.go_output, self.target, self.installed, self.frozen,
                     self.inputs, self.root / "tmp", self.root / "host-home", self.root / "host-tmp"):
            path.mkdir(parents=True, mode=0o700)
        self.host_env = {
            "PATH": "/usr/bin:/bin", "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8",
            "HOME": str(self.root / "host-home"), "TMPDIR": str(self.root / "host-tmp"),
            "PYTHONDONTWRITEBYTECODE": "1", **git_environment(),
        }
        for kind in ("config", "cache", "data", "state", "runtime"):
            directory = self.root / "host-home" / kind
            directory.mkdir(mode=0o700)
            self.host_env[f"XDG_{kind.upper()}_HOME" if kind != "runtime" else "XDG_RUNTIME_DIR"] = str(directory)
        self.save()
        for name, action in (
            ("preflight", self.preflight), ("cargo-lock", self.acquire_cargo),
            ("worktree", self.checkout_main), ("vendors", self.checkout_modules),
            ("freeze-source", self.freeze_source), ("private-caches", self.private_caches),
            ("tool-versions", self.versions), ("network-preflight", lambda: self.feature_fixture("network-preflight")),
        ):
            self.stage(name, action)
        self.stage("rust-wrapper-preflight", lambda: self.sandbox(
            [RUST_WRAPPER, SYSTEM / "true"], rust=True, timeout=120))
        # Use the direct, installed 1.100.0 tools rather than a home-sensitive shim.
        for name, cli in (
            ("fmt", ("fmt", "--all", "--", "--check")),
            ("clippy", ("clippy", "--workspace", "--all-targets", "--locked", "--offline", "--", "-D", "warnings")),
            ("workspace-tests", ("test", "--workspace", "--all-targets", "--locked", "--offline")),
            ("release-build", ("build", "--release", "--workspace", "--locked", "--offline")),
        ):
            self.stage(name, lambda: self.sandbox([RUST_CHAIN / "bin/cargo", *cli], rust=True,
                                                  timeout=self.args.build_timeout))
        self.stage("release-check", lambda: self.python("release.py", "check"))
        self.stage("release-transactions", lambda: self.sandbox(
            [SYSTEM / "python3", "-B", "-m", "unittest", "discover", "-s", "scripts",
             "-p", "test_release.py"], rust=True, timeout=900))
        self.stage("freeze-rust", self.freeze_rust)
        self.release_cargo()
        self.stage("go-pluginctl", lambda: self.go_build("zcalld-pluginctl"))
        self.stage("go-privacy", lambda: self.go_build("zcalld-privacy"))
        self.stage("freeze-go", lambda: self.freeze_artifacts(self.go_output, GO_ARTIFACTS))
        self.report["artifact_inputs"] = {name: row["sha256"] for name, row in self.report["binaries"].items()}
        for name, script, cli in (
            ("http", "integration.py", ("--binary", self.frozen / "zcalld", "--plugin-dir", self.frozen)),
            ("transport", "test-transport.py", ("--binary", self.frozen / "zcalld")),
            ("control", "test-control.py", ()),
            ("keys", "test-keys.py", ()),
            ("library", "test-library.py", ()),
            ("cutover", "test-cutover.py", ()),
        ):
            self.stage(name, lambda: self.python(script, *cli, timeout=900))
        for name in ("codex-metadata", "codex-compaction"):
            self.stage(name, lambda: self.feature_fixture(name))
        self.stage("shellcheck", lambda: self.sandbox([
            SYSTEM / "shellcheck", "scripts/check.sh", "scripts/package.sh", "packaging/install.sh"]))
        self.stage("native-package", self.native_package)
        self.stage("staged-install", self.install_stage)
        self.stage("staged-reinstall", self.reinstall_stage)
        self.stage("integrity", self.integrity)
        need([row["name"] for row in self.report["stages"]] == list(STAGES)
             and all(row["status"] == "passed" and type(row["exit_code"]) is int and row["exit_code"] == 0
                     for row in self.report["stages"]), "the exact stage inventory did not pass")


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument("--revision", required=True)
    parser.add_argument("--controller-sha256", required=True)
    parser.add_argument("--out", type=Path, default=ROOT)
    parser.add_argument("--lock-timeout", type=int, default=900)
    parser.add_argument("--build-timeout", type=int, default=7200)
    parser.add_argument("--build-reserve-gib", type=int, default=8)
    args = parser.parse_args()
    if args.revision != REVISION:
        parser.error("only the reviewed feature revision is allowed")
    if not re.fullmatch(r"[0-9a-f]{64}", args.controller_sha256):
        parser.error("--controller-sha256 must be a lowercase SHA-256")
    if not (0 <= args.lock_timeout <= 3600 and 60 <= args.build_timeout <= 14400
            and args.build_reserve_gib >= 1):
        parser.error("invalid timing or space budget")
    out = args.out.absolute()
    if (out.parent != ROOT.parent or (out != ROOT and not re.fullmatch(
            re.escape(ROOT.name) + r"-retry-[a-z0-9]+", out.name)) or os.path.lexists(out)):
        parser.error("use the new reserved output path or a fresh -retry-N sibling")
    args.out = out
    return args


def main():
    args = parse_args()
    os.umask(0o077)
    args.out.mkdir(mode=0o700, exist_ok=False)
    gate = Gate(args)

    def cancel(signum, _frame):
        gate.received = signum

    for signum in (signal.SIGINT, signal.SIGTERM):
        signal.signal(signum, cancel)
    try:
        gate.run()
        gate.check_signal()
        gate.report["status"] = "passed"
    except BaseException as error:
        gate.report["status"] = "failed"
        gate.report["error"] = f"{type(error).__name__}: {error}"
        gate.report["failed_stage"] = gate.report.get("active_stage")
    finally:
        gate.release_cargo()
        if gate.received is not None:
            gate.report.update(status="failed", interrupted_by_signal=gate.received)
        gate.report["finished_at"] = time.time()
        for row in gate.report["stages"]:
            if row["status"] == "running":
                row.update(status="failed", exit_code=1, error="stage did not finish")
            elif row["status"] == "not_run":
                row["reason"] = "gate stopped before this stage"
        gate.save()
    print(json.dumps({"status": gate.report["status"], "receipt": str(args.out / "gate-report.json")}),
          flush=True)
    return int(gate.report["status"] != "passed")


if __name__ == "__main__":
    raise SystemExit(main())
