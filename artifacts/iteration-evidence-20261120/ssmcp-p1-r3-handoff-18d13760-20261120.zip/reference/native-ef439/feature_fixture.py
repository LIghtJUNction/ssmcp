"""Run the pinned suite main functions and record every actual unittest outcome."""
import argparse
import ast
import ctypes
import json
import os
from pathlib import Path
import runpy
import socket
import subprocess
import sys
import unittest

ADDRESS = "192.0.2.42"
HOSTNAME = "zcalld-ef439-fixture"
LAN_METHOD = "test_real_lan_peer_cannot_claim_loopback_or_another_caller_with_headers"
SUITES = {
    "codex-metadata": ("test-codex-metadata.py", "CodexMetadataTests", 16),
    "codex-compaction": ("test-codex-compaction.py", "CodexCompactionTests", 2),
}


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def check_names(script, class_name, count):
    tree = ast.parse(script.read_bytes(), filename=str(script))
    classes = [node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == class_name]
    need(len(classes) == 1, f"expected one {class_name} class")
    names = [node.name for node in classes[0].body
             if isinstance(node, ast.FunctionDef) and node.name.startswith("test_")]
    need(len(names) == len(set(names)) == count, f"expected {count} distinct methods in {class_name}")
    return sorted(f"__main__.{class_name}.{name}" for name in names)


def prepare_lan(host_netns):
    netns = os.readlink("/proc/self/ns/net")
    need(netns != host_netns, "refusing address setup in the operator's network namespace")
    need(socket.gethostname() == HOSTNAME, "private UTS hostname is missing")
    subprocess.run(["/usr/bin/ip", "address", "add", ADDRESS + "/32", "dev", "lo"],
                   check=True, timeout=8)
    # v3 capabilities use a pair of 32-bit data words. Clear ambient first,
    # then effective, permitted and inheritable. NNP prevents exec elevation.
    libc = ctypes.CDLL(None, use_errno=True)
    header = (ctypes.c_uint32 * 2)(0x20080522, 0)
    data = (ctypes.c_uint32 * 6)()
    need(libc.prctl(47, 4, 0, 0, 0) == 0,
         f"could not clear ambient capabilities; errno={ctypes.get_errno()}")
    need(libc.capset(ctypes.byref(header), ctypes.byref(data)) == 0,
         f"could not drop capabilities; errno={ctypes.get_errno()}")
    need(libc.prctl(38, 1, 0, 0, 0) == 0,
         f"could not set no_new_privs; errno={ctypes.get_errno()}")
    status = dict(row.split(":", 1) for row in Path("/proc/self/status").read_text().splitlines()
                  if ":" in row)
    need(all(int(status[key].strip(), 16) == 0 for key in ("CapInh", "CapPrm", "CapEff", "CapAmb"))
         and status["NoNewPrivs"].strip() == "1", "the test still has setup privileges")
    resolved = sorted({item[4][0] for item in socket.getaddrinfo(
        socket.gethostname(), 0, socket.AF_INET, socket.SOCK_STREAM)})
    need(resolved == [ADDRESS], f"private hostname returned unexpected addresses: {resolved}")
    with socket.socket() as listener:
        listener.settimeout(5)
        listener.bind(("0.0.0.0", 0))
        listener.listen(1)
        with socket.create_connection((ADDRESS, listener.getsockname()[1]), timeout=5) as sender:
            peer, address = listener.accept()
            with peer:
                need(address[0] == sender.getsockname()[0] == ADDRESS,
                     "the server did not observe a non-loopback test peer")
    return {"network_namespace": netns, "hostname": HOSTNAME, "resolved": resolved,
            "accepted_peer": address[0], "setup_capabilities_dropped": True}


class TrackedResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.started = []
        self.finished = []
        self.passed = []

    def startTest(self, test):
        self.started.append(test.id())
        super().startTest(test)

    def stopTest(self, test):
        self.finished.append(test.id())
        super().stopTest(test)

    def addSuccess(self, test):
        self.passed.append(test.id())
        super().addSuccess(test)


def run_suite(suite, source, forwarded, report):
    filename, class_name, count = SUITES[suite]
    script = source / "scripts" / filename
    expected = check_names(script, class_name, count)
    lan_id = f"__main__.{class_name}.{LAN_METHOD}" if suite == "codex-metadata" else None
    need(lan_id is None or lan_id in expected, "LAN test is absent from the pinned suite")
    results = []
    runner = unittest.TextTestRunner

    class TrackedRunner(runner):
        def run(self, tests):
            self.resultclass = TrackedResult
            result = super().run(tests)
            results.append(result)
            return result

    unittest.TextTestRunner = TrackedRunner
    argv = sys.argv
    sys.argv = [str(script), *forwarded]
    try:
        runpy.run_path(str(script), run_name="__main__")
    except SystemExit as error:
        report["script_exit_code"] = error.code if type(error.code) is int else 1
    finally:
        sys.argv = argv
        unittest.TextTestRunner = runner
    need(len(results) == 1, "the committed main function did not execute exactly one unittest suite")
    result = results[0]
    report.update(expected=expected, started=result.started, finished=result.finished,
                  passed=result.passed, tests_run=result.testsRun, lan_test_id=lan_id,
                  lan_test_passed=lan_id is not None and lan_id in result.passed,
                  failures=[case.id() for case, _ in result.failures],
                  errors=[case.id() for case, _ in result.errors],
                  skipped=[{"id": case.id(), "reason": reason} for case, reason in result.skipped],
                  expected_failures=[case.id() for case, _ in result.expectedFailures],
                  unexpected_successes=[case.id() for case in result.unexpectedSuccesses])
    need(report.get("script_exit_code") == 0 and result.wasSuccessful()
         and not any(report[key] for key in ("failures", "errors", "skipped",
                                            "expected_failures", "unexpected_successes"))
         and result.testsRun == count
         and all(sorted(report[key]) == expected for key in ("started", "finished", "passed"))
         and (lan_id is None or report["lan_test_passed"]),
         f"{suite} did not pass every required test")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("suite", choices=("network-preflight", *SUITES))
    parser.add_argument("source", type=Path)
    parser.add_argument("report", type=Path)
    parser.add_argument("host_netns")
    parser.add_argument("forwarded", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    forwarded = args.forwarded[1:] if args.forwarded[:1] == ["--"] else args.forwarded
    # Script and its dynamic sibling import resolve against the checked checkout.
    sys.path.insert(0, str(args.source / "scripts"))
    report = {"status": "failed", "suite": args.suite}
    try:
        if args.suite in ("network-preflight", "codex-metadata"):
            report["network"] = prepare_lan(args.host_netns)
        if args.suite != "network-preflight":
            run_suite(args.suite, args.source, forwarded, report)
        report["status"] = "passed"
    except Exception as error:
        report["error"] = f"{type(error).__name__}: {error}"
        print(report["error"], file=sys.stderr)
    finally:
        with args.report.open("x", encoding="utf-8") as stream:
            json.dump(report, stream, indent=2, ensure_ascii=False)
            stream.write("\n")
    return int(report["status"] != "passed")


if __name__ == "__main__":
    raise SystemExit(main())
