# P1 r3 验收交接

**状态：控制器已准备，最终 P1 尚未运行。真实用户完成许可为 `false`。**

本包用于在最终 SSMCP r3 门禁通过后，复用已验收的 zcalld `ef4394ac0928cd53cda5f25862851465ca97f009` / compat `be72b3aa3ef17032a360ea5b9a9d38fe40c4b622` 开发候选，执行一次有明确来源的原生监听、生成、回复与终端截图验收。它不是发布或部署回执。原 `f1a6…` 控制器和历史证据保持原样。

## 固定文件

完整字节长度和 SHA256 在包根目录 `manifest.json`；`SHA256SUMS` 可用于解包校验。

| 文件 | SHA256 |
| --- | --- |
| `ssmcp-zcalld-delivery/p1-r3/run_final_p1_r3.py` | `4550cf311ceca921a0b4e26031fdface4625765e8800832541ba46078915c38b` |
| `ssmcp-zcalld-delivery/p1-r3/gate_r3_binding.py` | `18d13760eebc42e0d83aeffe6ec25e7f95dc6a25c532c86f6f5f5f2f6802e0c4` |
| `ssmcp-zcalld-delivery/p1-r3/native_ef439_binding.py` | `4ff65e1a7d731196ed47779350fca25e482615acd9a9aac0b4f74987061b6541` |
| `final24-controller/gate_inventory_r3.py` | `b1a4c184c58ed32f8efaee34bb5e0636b07611a0dfd55643e1485fb16799c4fa` |
| 实际 r3 driver 副本 | `1ad9ec768988aa8aeba23ffbd97ce565908f88d6c64d3a14ebb64049c5bc782d` |
| 实际 outer launcher 副本 | `99b78f15e4be1a0653289897a255f2cfdb2d92f547c67b1f5cec11769f73f833` |

driver 与 launcher 副本分别保存在 `gate-r3-final-1517/source/controller/run_gates.py` 和 `gate-r3-final-1517/source/launch/run_bound.py`，供来源核对；本交接不要求重跑它们。native 契约所依据的旧控制器和 helper 在 `reference/native-ef439/`。

## 执行前的最小清单

1. 唯一构建 owner 给出最终完整 source SHA、同源 `candidate-gates.json` 原始字节 SHA256，以及实际 `release21-final-8-r3-launch/exit.json` SHA256。三份 `claim.json`、`launch.json`、`exit.json` 和两份 stdout/stderr 文件必须存在。准备记录、author launch 和 synthetic probes 均不能代替它们。
2. 实际 r3 回执必须 `passed`，34 个阶段、25 个 Rust 阶段及精确 test inventory 一致；helper 会读取原始 parent logs、`--list` 输出、Cargo metadata/compiler artifacts、10 个运行时工具和 6 个桌面工具记录。原始日志没有 producer SHA 字段，因此本入口记录并复核读取到的真实字节，不声称获得了创建时的日志签名。
3. 实际 launcher 必须绑定同一 source/run ID/gate SHA、正常 rustc wrapper、`jobs=1`、固定 Cargo 配置和 lockfile。外层 `env -u PYTHONOPTIMIZE /usr/bin/python3 -I -B` 调用及最终 `source_tree` 仍由发布协调员的真实调用和最终冻结记录保存；这些字段不虚构进 launcher 回执。
4. 已验 native 回执为 `.../ssmcp-zcalld-ef439-feature-gate-20261120-retry-r2/gate-report.json`，SHA256 `de2cdb6c1226b6e09fa4a563293b6985539a1efd20fc972d186a048551f6c218`；同目录 `source-manifest.json` 为 `3b9c97790e500f60c09c6d1e9399614ee2a849c3d3797b3be9b61ac670a81589`。这是未正式发布的独立开发候选；32 阶段及实际 16 metadata / 2 compaction 回执会再核对。
5. 协调员确认没有并发验收，并指定全新的输出目录。最终 P1 获准后才运行下面命令。测试中的终端输入及模拟许可不构成真实用户授权结束会话；本包的 `real_human_finish_permission` 始终是 `false`。

## 运行命令

先设置 `P1_BUNDLE`、`SSMCP_REPOSITORY`、`SSMCP_FINAL_REVISION`、`SSMCP_R3_GATE_SHA256`、`SSMCP_R3_LAUNCH_SHA256` 和 `P1_FINAL_OUT`。后两个 hash 必须来自真实通过回执；不从运行中的文件猜测。输出目录必须不存在，且不能位于 `/tmp`、`/proc`、`/dev` 或 `/sys` 下。

```sh
/usr/bin/env -u PYTHONOPTIMIZE /usr/bin/python3 -I -B \
  "${P1_BUNDLE:?}/ssmcp-zcalld-delivery/p1-r3/run_final_p1_r3.py" \
  --repository "${SSMCP_REPOSITORY:?}" \
  --source-revision "${SSMCP_FINAL_REVISION:?}" \
  --zcalld-revision ef4394ac0928cd53cda5f25862851465ca97f009 \
  --gates /var/tmp/ssmcp-convergence-verification-20261120/release21-final-8-r3/candidate-gates.json \
  --gates-sha256 "${SSMCP_R3_GATE_SHA256:?}" \
  --ssmcp-launch-receipt /var/tmp/ssmcp-convergence-verification-20261120/release21-final-8-r3-launch/exit.json \
  --ssmcp-launch-sha256 "${SSMCP_R3_LAUNCH_SHA256:?}" \
  --zcalld-gates /var/tmp/ssmcp-zcalld-ef439-feature-gate-20261120-retry-r2/gate-report.json \
  --zcalld-gates-sha256 de2cdb6c1226b6e09fa4a563293b6985539a1efd20fc972d186a048551f6c218 \
  --zcalld-source-manifest /var/tmp/ssmcp-zcalld-ef439-feature-gate-20261120-retry-r2/source-manifest.json \
  --inventory-module "${P1_BUNDLE}/final24-controller/gate_inventory_r3.py" \
  --inventory-sha256 b1a4c184c58ed32f8efaee34bb5e0636b07611a0dfd55643e1485fb16799c4fa \
  --gate-validator "${P1_BUNDLE}/ssmcp-zcalld-delivery/p1-r3/gate_r3_binding.py" \
  --gate-validator-sha256 18d13760eebc42e0d83aeffe6ec25e7f95dc6a25c532c86f6f5f5f2f6802e0c4 \
  --native-validator "${P1_BUNDLE}/ssmcp-zcalld-delivery/p1-r3/native_ef439_binding.py" \
  --native-validator-sha256 4ff65e1a7d731196ed47779350fca25e482615acd9a9aac0b4f74987061b6541 \
  --out "${P1_FINAL_OUT:?}"
```

入口复制只读 source、产品产物、证据及 Node/bwrap/prlimit/rsync，并设置冻结的 runner 路径。在独立网络、PID、IPC、UTS 命名空间内运行同源 producer；写入限于 owned evidence 和私有 `/tmp`。不调用真实模型服务。

## 通过条件和证据边界

沿用原 P1 的严格断言：进程 exit 0 且未超时，至少 94 条非空 checks，四次 provider 请求的内容、次序和模型完全一致，三种执行/history 回执正确，以及 120/48 列、30 行的两份真实 PTY captures。`P1_NATIVE_RESULT` 必须同时出现在保存的同一帧 rows 和 cells 中。产物、源树、归档、原始与冻结证据的前后 hash 必须一致；异常时仅清理本次 owned 进程组。

主要输出是 `OUT/evidence/source-binding.json`、`report.json` 与两份 frame JSON。renderer 可继续消费原有 `build_manifests`、`artifacts`、`hashes_before/after`、`frame_sha256` 字段；新 provenance 字段提供附加来源证明。

当前只有 AST 检查、旧 `validate_report`/`stop_owned`/来源归档函数保持不变的核对，以及 7 项 synthetic/owned-file 契约通过。7 项运行对应 helper `ad19f3a8…`；最终 `18d13760…` 仅追加固定 Cargo target 比较并做静态检查，未扩展测试运行。详见 `preparation-static.json`。这些结果不等于最终 r3、P1 或截图验收通过。
