"""Consume the accepted ef439/be72 native receipt without rerunning its gate."""
from __future__ import annotations

import ast
import json
from pathlib import Path
import re

REVISION = "ef4394ac0928cd53cda5f25862851465ca97f009"
COMPAT = "be72b3aa3ef17032a360ea5b9a9d38fe40c4b622"
CONTROLLER_SHA256 = "c31c6383faefc22011b922123d393fcb0e592b74aebae762f319535fe47fa76b"
HELPER_SHA256 = "767e5581d0b18f3fe4b2ab58e7825a65500dff7e0224acc1143249124bff0ef2"
PARENTS = ["d722eb3732f6efb476184a1211e05fb8c8bc5e4a", "31e55247bb44e4e4d06f3a5f4638e5a953ea9427"]
GITLINKS = {
    "apps/zcall-gui": "e6ed24bdd5d7d193d76fc03a53d2bc1e10edec74",
    "apps/zcall-omarchy": "7db52e74ceb6c9d398791406e01265eecc127f87",
    "extensions/compat": COMPAT,
    "vendor/zcall": "45df84f93848a9f7dc66eb7da953d18d14bb08f7",
    "vendor/zconv": "0af1f7eb0766ff0ce9db5cee7c6184eff511a8c1",
    "vendor/zplugin": "00d566eedcff7b2932e90b9dfeb44910c783d305",
    "vendor/zsys": "808fcfdb73584ca7ca122e20b76f0209f56ab0f7",
}
STAGES = (
    "preflight", "cargo-lock", "worktree", "vendors", "freeze-source", "private-caches",
    "tool-versions", "network-preflight", "rust-wrapper-preflight", "fmt", "clippy",
    "workspace-tests", "release-build", "release-check", "release-transactions", "freeze-rust",
    "go-pluginctl", "go-privacy", "freeze-go", "http", "transport", "control", "keys", "library",
    "cutover", "codex-metadata", "codex-compaction", "shellcheck", "native-package",
    "staged-install", "staged-reinstall", "integrity",
)
ARTIFACTS = {
    "zcalld", "libzcalld_aliases.so", "libzcalld_policy.so", "libzcalld_redact.so",
    "libzcalld_community.so", "libzcalld_plugin_routing.so", "zcalld-pluginctl", "zcalld-privacy",
}
LAN_METHOD = "test_real_lan_peer_cannot_claim_loopback_or_another_caller_with_headers"


def require(value, message):
    if not value:
        raise ValueError(message)


def same_json(left, right):
    return json.dumps(left, sort_keys=True, separators=(",", ":")) == json.dumps(right, sort_keys=True, separators=(",", ":"))


def recorded_hash(value, label):
    require(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value),
            f"native {label} has no exact SHA256")
    return value


def validate_native_gate(gates_path, expected_sha256, manifest_path, revision, evidence_type):
    require(revision == REVISION, "P1 native candidate is not the reviewed ef439 cohort")
    evidence = evidence_type()
    gate = evidence.json(gates_path, expected_sha256)
    require(gate.get("status") == "passed" and gate.get("revision") == REVISION
            and gate.get("parents") == PARENTS and gate.get("version") == "0.4.0",
            "native receipt does not identify the accepted development candidate")
    require(all(gate.get(key) is True for key in (
        "source_unchanged", "binaries_unchanged", "inputs_unchanged", "unpacked_unchanged",
        "staged_install_unchanged")), "native integrity checks are incomplete")
    manifest = evidence.json(manifest_path,
                             recorded_hash(gate.get("source_manifest_sha256"), "source manifest"))
    require(manifest.get("revision") == REVISION and manifest.get("parents") == PARENTS
            and manifest.get("gitlinks") == GITLINKS
            and set(manifest.get("materialized_gitlinks", [])) == {
                "extensions/compat", "vendor/zcall", "vendor/zconv", "vendor/zplugin", "vendor/zsys"},
            "native source manifest has another source or compatibility pin")
    require(isinstance(manifest.get("files"), dict) and manifest["files"]
            and type(gate.get("source_files")) is int and len(manifest["files"]) == gate["source_files"],
            "native source manifest is empty or truncated")
    root = Path(gate.get("run_root", ""))
    require(root.is_absolute(), "native run root is absent")
    checks = gate.get("stages")
    require(isinstance(checks, list) and [row.get("name") for row in checks] == list(STAGES),
            "native gate is not the exact 32-stage inventory")
    for row in checks:
        require(row.get("status") == "passed" and type(row.get("exit_code")) is int
                and row["exit_code"] == 0 and row.get("log") == str(root / "logs" / (row["name"] + ".log")),
                f"native stage did not pass: {row.get('name')}")
        evidence.read(row["log"], recorded_hash(row.get("log_sha256"), row["name"] + " log"))
        require(isinstance(row.get("commands"), list)
                and all(type(item.get("exit_code")) is int and item["exit_code"] == 0
                        for item in row["commands"]), f"native stage contains an incomplete command: {row['name']}")
    inputs = gate.get("input_files", {})
    for name, expected in (("controller", CONTROLLER_SHA256), ("fixture_helper", HELPER_SHA256)):
        entry = inputs.get(name, {})
        require(entry.get("sha256") == expected, f"native {name} differs from reviewed bytes")
        evidence.read(entry.get("path", ""), expected)
    binaries = gate.get("binaries")
    require(isinstance(binaries, dict) and set(binaries) == ARTIFACTS,
            "native frozen artifact inventory differs")
    for name, entry in binaries.items():
        evidence.artifact(entry, name, executable=True)
    require(gate.get("artifact_inputs") == {name: entry["sha256"] for name, entry in binaries.items()},
            "native artifact hash projections differ")
    proofs = {}
    for name in ("network-preflight", "codex-metadata", "codex-compaction"):
        row = next(item for item in checks if item["name"] == name)
        entry = row.get("fixture_receipt", {})
        proof = evidence.json(entry.get("path", ""), recorded_hash(entry.get("sha256"), name + " receipt"))
        require(proof.get("status") == "passed" and proof.get("suite") == name
                and same_json(proof, row.get("fixture_summary")), f"native {name} receipt differs")
        require(len(row["commands"]) == 1, f"native {name} has an unexpected command count")
        argv = row["commands"][0].get("argv")
        helper = inputs["fixture_helper"]["path"]
        require(isinstance(argv, list) and argv.count(helper) == 1, f"native {name} did not use its frozen helper")
        index = argv.index(helper)
        require(argv[index + 1:index + 4] == [name, str(root / "source"), entry["path"]]
                and all(flag in argv[:index] for flag in ("--unshare-net", "--unshare-pid", "--clearenv", "--die-with-parent")),
                f"native {name} lacks its exact source/report and private namespace command")
        if name in ("network-preflight", "codex-metadata"):
            host_namespace = argv[index + 4]
            network = proof.get("network", {})
            require(isinstance(network.get("network_namespace"), str)
                    and re.fullmatch(r"net:\[[0-9]+\]", network["network_namespace"])
                    and network["network_namespace"] != host_namespace
                    and network.get("hostname") == "zcalld-ef439-fixture"
                    and network.get("resolved") == ["192.0.2.42"]
                    and network.get("accepted_peer") == "192.0.2.42"
                    and network.get("setup_capabilities_dropped") is True,
                    f"native {name} has no actual private non-loopback peer proof")
        if name != "network-preflight":
            filename, class_name, count = (("test-codex-metadata.py", "CodexMetadataTests", 16)
                if name == "codex-metadata" else ("test-codex-compaction.py", "CodexCompactionTests", 2))
            relative = "scripts/" + filename
            script = evidence.read(root / "source" / relative,
                                   recorded_hash(manifest["files"].get(relative), relative))
            tree = ast.parse(script, filename=relative)
            classes = [node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == class_name]
            require(len(classes) == 1, "native fixture class is not unique")
            expected = sorted("__main__." + class_name + "." + node.name for node in classes[0].body
                if isinstance(node, ast.FunctionDef) and node.name.startswith("test_"))
            require(len(expected) == len(set(expected)) == count and proof.get("expected") == expected
                    and type(proof.get("tests_run")) is int and proof["tests_run"] == count
                    and type(proof.get("script_exit_code")) is int and proof["script_exit_code"] == 0,
                    f"native {name} did not execute the exact source method inventory")
            require(all(isinstance(proof.get(key), list) and sorted(proof[key]) == expected
                        for key in ("started", "finished", "passed"))
                    and all(proof.get(key) == [] for key in (
                        "failures", "errors", "skipped", "expected_failures", "unexpected_successes")),
                    f"native {name} contains skipped, failed or unexecuted methods")
            if name == "codex-metadata":
                lan = "__main__.CodexMetadataTests." + LAN_METHOD
                require(proof.get("lan_test_id") == lan and proof.get("lan_test_passed") is True
                        and lan in proof["passed"], "native real peer method did not pass")
        proofs[name] = {"path": entry["path"], "sha256": entry["sha256"], "status": "passed"}
    return {"schema": "zcalld.ef439.gate-binding.v1", "revision": REVISION,
            "compat_revision": COMPAT, "scope": "accepted unpublished development cohort",
            "evidence_files": evidence.files, "content_files": evidence.content_files,
            "stage_names": list(STAGES), "fixtures": proofs}
