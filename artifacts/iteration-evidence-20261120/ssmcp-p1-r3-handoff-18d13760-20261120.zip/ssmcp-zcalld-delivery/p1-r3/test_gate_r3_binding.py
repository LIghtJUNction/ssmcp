"""Synthetic launch-schema and local byte-binding contracts; never run a product.

MemoryEvidence deliberately supplies synthetic files for the launch-only tests.
Those tests check receipt semantics, not whether a real r3 gate has executed.
The actual Evidence class is tested separately on owned temporary text files.
No driver, launcher, Cargo command, terminal producer, or model is executed.
"""
from __future__ import annotations

import ast
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

import gate_r3_binding as binding


SCRATCH = Path(__file__).resolve().parents[2]
INVENTORY = SCRATCH / "final24-controller/gate_inventory_r3.py"
INVENTORY_SHA256 = "b1a4c184c58ed32f8efaee34bb5e0636b07611a0dfd55643e1485fb16799c4fa"


class MemoryEvidence:
    def __init__(self, objects, files, hashes):
        self.objects, self.files, self.hashes = objects, files, hashes
        self.observed = set()

    def read(self, path, expected=None):
        path = str(path)
        if expected is not None and self.hashes.get(path) != expected:
            raise ValueError("synthetic evidence hash mismatch")
        self.observed.add(path)
        return self.files[path]

    def json(self, path, expected=None):
        self.read(path, expected)
        return deepcopy(self.objects[str(path)])


def synthetic_launch():
    inventory = binding.load_inventory(binding.Evidence(), INVENTORY, INVENTORY_SHA256)
    revision, gate_hash, launch_hash = "a" * 40, "b" * 64, "c" * 64
    worktree = Path("/synthetic-clean-candidate")
    root, launch = binding.GATE_ROOT, binding.LAUNCH_ROOT
    gate = {"source_revision": revision, "status": "passed", "run_id": "d" * 32,
            "root_worktree": str(worktree), "started_at": 102.0, "finished_at": 103.0,
            "library_binary": "/synthetic-library", "binaries": {},
            "checks": [{"name": name, "command": ["synthetic", name],
                        "exit_code": 0, "seconds": 0.01} for name in inventory.EXPECTED_GATES]}
    paths = {"driver": str(root / "run_gates.py"), "wrapper": str(binding.RUST_WRAPPER),
             "cargo_config": str(binding.CARGO_HOME / "config.toml"),
             "cargo_lock": str(worktree / "Cargo.lock")}
    initial = {
        "source_revision": revision, "worktree": str(worktree), "started_at": 101.0,
        "command": ["/usr/bin/python3", "-u", paths["driver"], revision,
                    "--worktree", str(worktree), "--submodule-root", str(binding.OBJECT_ROOT)],
        "input_paths": paths, "hashes_before": deepcopy(binding.LAUNCH_HASHES),
        "launcher_sha256": binding.LAUNCHER_SHA256,
        "environment": {"RUSTC_WRAPPER": str(binding.RUST_WRAPPER), "CARGO_BUILD_JOBS": "1",
                        "CARGO_HOME": str(binding.CARGO_HOME), "CARGO_TARGET_DIR": str(binding.CARGO_TARGET)},
        "versions": {"cargo": "cargo synthetic", "rustc": "rustc synthetic"},
        "umask": "0022", "invocation_id": None, "exclusive_target_lock": True,
    }
    result = {**deepcopy(initial), "exit_code": 0, "hashes_after": deepcopy(binding.LAUNCH_HASHES),
              "gate_status": "passed", "gate_run_id": gate["run_id"], "gate_receipt_sha256": gate_hash,
              "worktree_head_after": revision, "worktree_status_after": "", "status": "passed",
              "finished_at": 104.0}
    objects = {str(launch / "exit.json"): result, str(launch / "launch.json"): initial,
               str(launch / "claim.json"): {"source_revision": revision, "claimed_at": 100.0, "pid": 123}}
    output = []
    for row in gate["checks"]:
        output.extend(({"started": row["name"], "command": row["command"]},
                       {"completed": row["name"], "exit_code": 0, "seconds": row["seconds"],
                        "test_results": None}))
    output.append({"status": "passed", "source_revision": revision,
                   "receipt": str(root / "candidate-gates.json"),
                   "library_binary": gate["library_binary"], "binaries": gate["binaries"]})
    hashes = {str(launch / "exit.json"): launch_hash,
              str(launch / "run_bound.py"): binding.LAUNCHER_SHA256,
              str(root / "candidate-gates.json"): gate_hash,
              str(root / "source/Cargo.lock"): binding.LAUNCH_HASHES["cargo_lock"],
              **{path: binding.LAUNCH_HASHES[name] for name, path in paths.items()}}
    files = {path: b"synthetic only" for path in set(objects) | set(hashes)}
    files[str(launch / "stdout.log")] = ("\n".join(json.dumps(row) for row in output) + "\n").encode()
    files[str(launch / "stderr.log")] = b""
    return MemoryEvidence(objects, files, hashes), gate, revision, gate_hash, launch_hash


def validate_fixture(fixture):
    evidence, gate, revision, gate_hash, launch_hash = fixture
    return binding.validate_launch(evidence, binding.LAUNCH_ROOT / "exit.json", launch_hash,
                                   gate, binding.GATE_ROOT, revision, gate_hash)


class LaunchContracts(unittest.TestCase):
    def test_constants_match_actual_launcher_bytes_without_executing_it(self):
        path = SCRATCH / "gate-r3-final-1517/source/launch/run_bound.py"
        raw = path.read_bytes()
        self.assertEqual(hashlib.sha256(raw).hexdigest(), binding.LAUNCHER_SHA256)
        tree = ast.parse(raw)
        assignment = next(node for node in tree.body if isinstance(node, ast.Assign)
                          and any(isinstance(target, ast.Name) and target.id == "EXPECTED"
                                  for target in node.targets))
        self.assertEqual(ast.literal_eval(assignment.value), binding.LAUNCH_HASHES)

    def test_complete_synthetic_launch_binds_all_three_receipts_and_stdout(self):
        fixture = synthetic_launch()
        result = validate_fixture(fixture)
        self.assertEqual(result["source_revision"], fixture[2])
        self.assertEqual(result["gate_receipt_sha256"], fixture[3])
        for name in ("exit.json", "launch.json", "claim.json", "stdout.log", "stderr.log", "run_bound.py"):
            self.assertIn(str(binding.LAUNCH_ROOT / name), fixture[0].observed)

    def test_exit_boolean_other_gate_dirty_source_or_changed_input_is_rejected(self):
        for key, value in (("exit_code", False), ("gate_run_id", "e" * 32),
                           ("gate_receipt_sha256", "e" * 64), ("worktree_head_after", "e" * 40),
                           ("worktree_status_after", " M Cargo.lock"), ("status", "running"),
                           ("hashes_after", {})):
            with self.subTest(field=key):
                fixture = synthetic_launch()
                fixture[0].objects[str(binding.LAUNCH_ROOT / "exit.json")][key] = value
                with self.assertRaises(ValueError):
                    validate_fixture(fixture)

    def test_consistent_but_unreviewed_environment_and_wrapper_are_rejected(self):
        for field, value in (("CARGO_BUILD_JOBS", "2"), ("RUSTC_WRAPPER", "/synthetic-bypass")):
            with self.subTest(field=field):
                fixture = synthetic_launch()
                for name in ("launch.json", "exit.json"):
                    fixture[0].objects[str(binding.LAUNCH_ROOT / name)]["environment"][field] = value
                with self.assertRaises(ValueError):
                    validate_fixture(fixture)

    def test_missing_or_mismatched_actual_execution_stdout_is_rejected(self):
        for defect in ("missing_stage", "wrong_command", "wrong_final_source"):
            with self.subTest(defect=defect):
                fixture = synthetic_launch()
                path = str(binding.LAUNCH_ROOT / "stdout.log")
                rows = [json.loads(line) for line in fixture[0].files[path].splitlines()]
                if defect == "missing_stage":
                    rows.pop(2)
                elif defect == "wrong_command":
                    rows[0]["command"] = ["synthetic-other"]
                else:
                    rows[-1]["source_revision"] = "e" * 40
                fixture[0].files[path] = ("\n".join(json.dumps(row) for row in rows) + "\n").encode()
                with self.assertRaisesRegex(ValueError, "stdout"):
                    validate_fixture(fixture)

    def test_author_receipt_cannot_replace_actual_exit_path(self):
        evidence, gate, revision, gate_hash, launch_hash = synthetic_launch()
        with self.assertRaisesRegex(ValueError, "actual r3 launcher exit"):
            binding.validate_launch(evidence, Path("/synthetic/author-launch.json"), launch_hash,
                                    gate, binding.GATE_ROOT, revision, gate_hash)

    def test_real_owned_file_bytes_are_pinned_and_duplicate_json_keys_rejected(self):
        with tempfile.TemporaryDirectory(prefix="p1-r3-contract-") as directory:
            path = Path(directory) / "proof.json"
            path.write_bytes(b'{"status":"passed"}\n')
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            evidence = binding.Evidence()
            self.assertEqual(evidence.json(path, digest), {"status": "passed"})
            path.write_bytes(b'{"status":"failed"}\n')
            with self.assertRaisesRegex(ValueError, "hash differs"):
                evidence.json(path, digest)
            with self.assertRaisesRegex(ValueError, "between reads"):
                evidence.json(path)
            path.write_bytes(b'{"status":"failed","status":"passed"}\n')
            with self.assertRaisesRegex(ValueError, "duplicate JSON key"):
                binding.Evidence().json(path)


if __name__ == "__main__":
    unittest.main(verbosity=2)
