"""Read-only contracts for the six additional source-bound PTY producers.

These checks inspect reports and captured files. They never launch a producer,
build, render a replacement image, or infer a successful product result.
"""

import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import stat


FEATURE_SUITES = (
    "human_finish", "goal_startup", "tool_summaries", "readable_commands",
    "summary_commands", "physical_latency",
)
LATENCY_SCRIPT = "docs/reports/ui-input-performance-20261120/pty_latency_focused.py"
LATENCY_SHA256 = "ea601787135257cb3838fa249a233b85a5944a9245de68daa900f5396709e106"
FRAME_CONTRACTS = {
    "human_finish": (5, 30), "goal_startup": (7, 32),
    "tool_summaries": (6, 32), "readable_commands": (14, 40),
    "summary_commands": (4, 32), "physical_latency": (10, 58),
}
HASH = re.compile(r"[0-9a-f]{64}\Z")


class ContractError(ValueError):
    pass


def need(condition, message):
    if not condition:
        raise ContractError(message)


def script_relative(name):
    return LATENCY_SCRIPT if name == "physical_latency" else "scripts/e2e_" + name + ".py"


def read_regular(path, root=None):
    path = Path(path).absolute()
    if root is not None:
        root = Path(root).absolute()
        need(path.is_relative_to(root), "capture is outside its evidence directory")
        current = path
        while current != root:
            need(not current.is_symlink(), "capture path contains a symlink")
            current = current.parent
        need(not root.is_symlink(), "evidence directory became a symlink")
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(descriptor, "rb") as stream:
        metadata = os.fstat(stream.fileno())
        need(stat.S_ISREG(metadata.st_mode), "capture must be a regular file")
        body = stream.read(16 * 1024 * 1024 + 1)
    need(len(body) <= 16 * 1024 * 1024, "capture exceeds the size limit")
    return body


def safe_relative(value):
    need(type(value) is str and value and not Path(value).is_absolute()
         and ".." not in Path(value).parts and Path(value).as_posix() == value,
         "capture path is not a normalized safe relative path")
    return value


def validate_cells(data):
    need(type(data) is dict and data.get("ok") is True, "VT capture is not successful")
    size = data.get("size")
    need(type(size) is list and len(size) == 2
         and all(type(n) is int and 1 <= n <= 1000 for n in size), "invalid VT dimensions")
    rows, cols = size
    content, cells, cursor = data.get("rows"), data.get("cells"), data.get("cursor")
    need(type(content) is list and len(content) == rows and all(type(v) is str for v in content),
         "VT text rows do not cover the screen")
    need(type(cursor) is list and len(cursor) == 2
         and all(type(n) is int and n >= 0 for n in cursor)
         and cursor[0] < rows and cursor[1] <= cols, "invalid VT cursor")
    need(all(type(data.get(key)) is bool for key in ("alternate_screen", "hide_cursor")),
         "VT terminal-state flags are absent")
    need(type(cells) is list and len(cells) == rows
         and all(type(row) is list and len(row) == cols for row in cells),
         "VT capture lacks a complete actual cell grid")
    for row_number, row in enumerate(cells):
        for cell in row:
            need(type(cell) is dict and type(cell.get("text")) is str,
                 "VT cell has no text")
            need(all(type(cell.get(key)) is bool for key in
                     ("wide", "continuation", "bold", "dim", "inverse")),
                 "VT cell style flags are incomplete")
            for key in ("foreground", "background"):
                need(key in cell, "VT cell lacks a color field")
                value = cell[key]
                need(value is None or (type(value) is int and 0 <= value <= 255)
                     or (type(value) is list and len(value) == 3
                         and all(type(n) is int and 0 <= n <= 255 for n in value)),
                     "invalid VT color")
        visible = "".join(cell["text"] or " " for cell in row if not cell["continuation"])
        need(visible.rstrip(" ") == content[row_number].rstrip(" "),
             "VT text rows disagree with the captured cell grid")
    return rows, cols


def _source_hash(baseline, key):
    if key.startswith("source/"):
        key = "scripts/" + key.removeprefix("source/")
    elif key not in baseline["source_files"] and Path(key).name == key:
        key = "scripts/" + key
    return baseline["source_files"].get(key, {}).get("sha256")


def _binary_hashes(baseline):
    files = baseline["files"]
    return {"ssmcp": files["ssmcp"]["sha256"], "ssmcpd": files["ssmcpd"]["sha256"],
            "decoder": files["decoder"]["sha256"], "fixture": files["fixture_binary"]["sha256"]}


def validate_feature_report(report, name, args, baseline):
    """Check the actual producer's declared source, binary and result contract."""
    need(name in FEATURE_SUITES, "unknown feature producer")
    need(report.get("status") == "passed" and report.get("source_revision") == args.source_revision,
         "feature report is not passed at the selected source")
    need(not report.get("error") and not report.get("cleanup_errors")
         and not report.get("input_error"), "feature report contains an error")
    expected_binaries = _binary_hashes(baseline)
    if name == "human_finish":
        expected = {"ssmcp": expected_binaries["ssmcp"], "ssmcpd": expected_binaries["ssmcpd"],
                    "vt_snapshot": expected_binaries["decoder"],
                    "router_test": expected_binaries["fixture"]}
        need(report.get("binaries") == expected, "human-finish binary claims differ")
        sources = {"source/" + Path(path).name: entry["sha256"]
                   for path, entry in baseline["source_files"].items()
                   if Path(path).parent.as_posix() == "scripts"
                   and Path(path).name.startswith("e2e") and path.endswith(".py")}
        need(report.get("sources") == sources, "human-finish helper inventory differs")
        paths = {"ssmcp": args.bin_dir / "ssmcp", "ssmcpd": args.bin_dir / "ssmcpd",
                 "vt_snapshot": args.decoder, "router_test": args.fixture_binary}
        paths.update({key: args.source_path / "scripts" / key.removeprefix("source/")
                      for key in sources})
        all_hashes = {**expected, **sources}
        expected_inputs = {key: {"path": str(path.resolve(strict=True)), "sha256": all_hashes[key]}
                           for key, path in paths.items()}
        need(report.get("inputs_before") == expected_inputs
             and report.get("inputs_after") == expected_inputs,
             "human-finish before/after input descriptors differ")
        need(report.get("source_kind") == "owned_pty_capture"
             and report.get("keyboard_actor") == "fixture_simulated_user"
             and report.get("real_user_finish_permission") is False,
             "human-finish fixture must not claim actual user permission")
    else:
        need(report.get("binaries_sha256_before") == expected_binaries
             and report.get("binaries_sha256_after") == expected_binaries
             and report.get("inputs_unchanged") is True,
             "feature binary hashes or unchanged claim differ")
        sources = report.get("source_sha256")
        need(type(sources) is dict and sources, "feature helper hashes are missing")
        mandatory = "e2e_interactions.py" if name == "physical_latency" else "e2e_" + name + ".py"
        need(mandatory in sources, "feature does not bind its source entry")
        for path, value in sources.items():
            need(type(path) is str and value == _source_hash(baseline, path),
                 "feature helper hash differs: " + str(path))
        if "source_sha256_before" in report:
            need(report["source_sha256_before"] == sources, "feature source changed during its run")
    if name in ("tool_summaries", "summary_commands"):
        expected_font = baseline["files"]["font"]["sha256"]
        need(report.get("font_sha256") == expected_font, "feature used a different render font")
        if "font_sha256_before" in report:
            need(report["font_sha256_before"] == expected_font, "feature font changed")
    if name == "goal_startup":
        need(report.get("fixture_release_cache", {}).get("synthetic") is True,
             "startup evidence must identify its synthetic cached release")
    if name == "summary_commands":
        scenarios = report.get("scenarios")
        need(type(scenarios) is list and [item.get("scenario") for item in scenarios]
             == ["exec-only", "mixed"], "summary commands lacks its two exact scenarios")
        need(all(item.get("status") == "passed" for item in scenarios),
             "a summary command scenario failed")
        flattened = [item["scenario"] + "/" + path for item in scenarios for path in item.get("frames", [])]
        need(report.get("frames") == flattened, "summary scenario frames do not match the parent report")
        for item in scenarios:
            need(len(item.get("native_jobs", [])) == 2
                 and all(type(job.get("exit_code")) is int and job["exit_code"] == 0
                         for job in item["native_jobs"]), "summary native commands did not both succeed")
    if name == "physical_latency":
        validate_latency(report, baseline)


def validate_latency(report, baseline):
    expected = baseline["source_files"].get(LATENCY_SCRIPT, {}).get("sha256")
    need(expected == LATENCY_SHA256 and report.get("focused_runner_sha256") == expected,
         "physical latency runner differs from the reviewed fixed source")
    samples = report.get("latency_samples")
    need(type(samples) is list and samples, "physical latency report has no samples")
    local = {"mouse_content_focus", "mouse_composer_focus", "typed_draft_frame"}
    expected_actions = local | {"send_accepted_frame", "up_confirmed_takeback_frame",
                                "edited_send_accepted_frame", "up_delivered_input_history_frame"}
    need({item.get("action") for item in samples} == expected_actions,
         "physical latency actions differ from the reviewed input path")
    for item in samples:
        budget = 250 if item["action"] in local else 500
        need(type(item.get("budget_ms")) is int and item["budget_ms"] == budget,
             "physical latency budget changed")
        values = [item.get(key) for key in ("input_ms", "visible_ms", "latency_ms")]
        need(all(type(value) in (int, float) and math.isfinite(value) and value >= 0 for value in values),
             "invalid physical latency timestamp")
        entered, visible, latency = values
        need(visible >= entered and math.isclose(visible - entered, latency, abs_tol=0.00001)
             and item.get("within_budget") is True and latency < budget,
             "physical latency budget was exceeded or sample is inconsistent")
    writes = report.get("history_write_calls")
    need(type(writes) is list and writes, "physical latency lacked concurrent history work")
    for item in writes:
        start, end = item.get("start_ms"), item.get("end_ms")
        need(type(start) in (int, float) and type(end) in (int, float)
             and math.isfinite(start) and math.isfinite(end) and 0 <= start <= end
             and item.get("history_saved") is True, "invalid history-write interval")
    local_samples = [item for item in samples if item["action"] in local]
    overlaps = []
    for item in local_samples:
        actual = any(write["start_ms"] <= item["input_ms"] < write["end_ms"] for write in writes)
        need(item.get("overlapped_history_call") is actual,
             "declared physical input/history overlap differs from its timestamps")
        overlaps.append(actual)
    need(any(overlaps), "no physical input overlapped a real history call")


def verify_feature_frames(report, name, evidence):
    """Hash and validate the same cell bytes reported by the fixed producer."""
    expected_count, rows_expected = FRAME_CONTRACTS[name]
    records = report.get("frames")
    need(type(records) is list and len(records) == expected_count,
         name + ": actual frame count differs from the reviewed producer")
    manifest = report.get("frame_manifest") if name == "goal_startup" else None
    if name == "goal_startup":
        need(type(manifest) is list and len(manifest) == len(records), "goal frame manifest is incomplete")
        need(all(type(item) is dict for item in manifest)
             and [item.get("path") for item in manifest] == records,
             "goal frame paths differ from its manifest")
    receipts, seen, widths = [], set(), set()
    for index, record in enumerate(records):
        descriptor = record if name == "human_finish" else (manifest[index] if manifest is not None else {})
        original = record.get("path") if type(record) is dict else record
        safe_relative(original)
        need(original not in seen, "producer listed a duplicate frame")
        seen.add(original)
        png = original if original.endswith(".png") else None
        json_name = str(Path(original).with_suffix(".json"))
        need(Path(original).suffix in (".json", ".png"), "unsupported frame extension")
        raw = read_regular(Path(evidence) / json_name, evidence)
        captured = json.loads(raw)
        rows, cols = validate_cells(captured)
        need(rows == rows_expected and cols in (120, 48), name + ": unexpected actual VT dimensions")
        widths.add(cols)
        sha = hashlib.sha256(raw).hexdigest()
        if descriptor:
            need(type(descriptor.get("sha256")) is str and descriptor["sha256"] == sha,
                 "frame manifest hash does not match the captured JSON bytes")
            if name == "human_finish":
                need(type(descriptor.get("rows")) is int and type(descriptor.get("cols")) is int
                     and (descriptor["rows"], descriptor["cols"]) == (rows, cols)
                     and descriptor.get("source_kind") == "owned_pty_capture"
                     and descriptor.get("keyboard_actor") == "fixture_simulated_user",
                     "human frame metadata differs from its captured grid")
            else:
                need(descriptor.get("size") == [rows, cols], "goal frame dimensions disagree")
        if name == "readable_commands":
            png = str(Path(original).with_suffix(".png"))
        row = {"path": str(Path(evidence) / json_name), "relative_path": json_name,
               "sha256": sha, "bytes": len(raw), "rows": rows, "cols": cols,
               "kind": "actual_terminal_vt_snapshot"}
        if png is not None:
            image = read_regular(Path(evidence) / png, evidence)
            need(image.startswith(b"\x89PNG\r\n\x1a\n"), "VT rendering is not a PNG")
            from PIL import Image
            try:
                with Image.open(io.BytesIO(image)) as picture:
                    need(picture.format == "PNG" and 0 < picture.width <= 16384
                         and 0 < picture.height <= 16384, "invalid VT PNG dimensions or format")
                    picture.verify()
            except (OSError, ValueError, SyntaxError) as error:
                raise ContractError("VT PNG bytes are incomplete or invalid") from error
            row["rendered_png"] = {"relative_path": png, "sha256": hashlib.sha256(image).hexdigest()}
        receipts.append(row)
    need(widths == {48, 120}, name + ": missing a narrow or wide actual VT capture")
    if name == "readable_commands":
        need(report.get("pngs") == [str(Path(item).with_suffix(".png")) for item in records],
             "readable command PNG list differs from its JSON captures")
    return receipts
