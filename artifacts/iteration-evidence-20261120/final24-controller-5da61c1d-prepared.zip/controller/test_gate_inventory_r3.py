"""Synthetic receipt tests only; no SSMCP driver or executable is run."""

import ast
from copy import deepcopy
import hashlib
from pathlib import Path
import unittest

import gate_inventory_r3 as validator


def names(values):
    return sorted(values)


def plan(all_tests, ignored, matched, *, ignored_only=False, required=None):
    skipped = set() if ignored_only else matched & ignored
    selected = matched - skipped
    value = {
        "selected": names(selected), "skipped_ignored": names(skipped),
        "expected_result": {
            "result": "ok", "passed": len(selected), "failed": 0,
            "ignored": len(skipped), "measured": 0, "filtered": len(all_tests - matched),
        },
    }
    if required:
        value["required_ignored_stage"] = required
    return value


def synthetic_receipt():
    rows = {name: {"name": name, "exit_code": 0, "command": ["synthetic", name]}
            for name in validator.EXPECTED_GATES}
    binary = "/synthetic/library"
    code = set(validator.CODE_MODE_IGNORED) | {"code_mode::tests::additional_ignored_case"}
    other_ignored = {"unrelated::ignored_case"}
    ignored = code | other_ignored
    host = set(validator.HOST_TESTS)
    private = {"private::first", "private::second"} | ignored
    all_tests = private | host
    private_args = [binary, "--exact", "--test-threads=4"]
    for name in validator.HOST_TESTS:
        private_args += ["--skip", name]
    selections = {
        "library-private": (private, private_args, False),
        "library-host": (host, [binary, "--exact", "--test-threads=1", *validator.HOST_TESTS], False),
        "library-code-mode-ignored": (
            code, [binary, "--ignored", "--exact", "--test-threads=1", *sorted(code)], True,
        ),
    }
    for stage, (matched, command, ignored_only) in selections.items():
        rows[stage].update(command=command,
                           test_selection=plan(all_tests, ignored, matched, ignored_only=ignored_only))
    report = {
        "status": "passed", "script_sha256": validator.DRIVER_BASELINE_SHA256, "checks": [rows[name] for name in validator.EXPECTED_GATES],
        "library_binary": binary,
        "library_partition": {
            "total": len(all_tests), "private": len(private), "host": len(host),
            "complete": True, "disjoint": True,
        },
        "library_test_names": {
            "all": names(all_tests), "private": names(private), "host": names(host),
            "ignored": names(ignored), "private_selected": names(private - ignored),
            "host_selected": names(host), "ignored_code_mode": names(code),
            "ignored_not_executed": names(other_ignored),
        },
        "integration_test_names": {}, "integration_binaries": {}, "integration_artifacts": {},
        "cargo_metadata": {"test_targets": {}},
    }
    for target in validator.INTEGRATION_TESTS:
        binary = f"/synthetic/{target}"
        ignored = set(validator.INTEGRATION_IGNORED.get(target, ()))
        if target == "two_tools":
            ignored.add("additional_ignored_case")
        elif target == "resources":
            ignored.add("explicitly_unexecuted_ignored_case")
        ordinary = set() if target in ("workspace_bridge", "context_helpers") else {"ordinary_case"}
        all_tests = ignored | ordinary
        ignored_stage = f"integration-{target}-ignored" if target in validator.INTEGRATION_IGNORED else None
        selected_ignored = ignored if ignored_stage else set()
        report["integration_test_names"][target] = {
            "all": names(all_tests), "ignored": names(ignored), "ordinary_selected": names(ordinary),
            "ignored_selected": names(selected_ignored),
            "ignored_not_executed": names(ignored - selected_ignored), "execution_mode": "ordinary",
        }
        report["integration_binaries"][target] = binary
        report["integration_artifacts"][target] = {"path": binary}
        report["cargo_metadata"]["test_targets"][target] = f"/synthetic/tests/{target}.rs"
        rows[f"integration-{target}"].update(
            command=[binary, "--test-threads=4"],
            test_selection=plan(all_tests, ignored, all_tests, required=ignored_stage),
        )
        if ignored_stage:
            rows[ignored_stage].update(
                command=[binary, "--ignored", "--test-threads=1"],
                test_selection=plan(all_tests, ignored, ignored, ignored_only=True),
            )
    target = "zuse_worker_entry"
    required = {validator.ZUSE_WORKER_TEST}
    entry = report["integration_test_names"][target]
    entry.update(all=names(required), ignored=names(required), ordinary_selected=[],
                 ignored_selected=names(required), ignored_not_executed=[],
                 execution_mode="ignored-exact")
    rows["integration-" + target].update(
        command=[report["integration_binaries"][target], "--ignored", "--exact",
                 validator.ZUSE_WORKER_TEST, "--test-threads=1"],
        test_selection={**plan(required, required, required, ignored_only=True),
                        "execution_mode": "ignored-exact"},
    )
    results = {name: deepcopy(row["test_selection"]["expected_result"])
               for name, row in rows.items() if "test_selection" in row}
    return report, results


def replace_name(value, old, new):
    if type(value) is list:
        return [replace_name(item, old, new) for item in value]
    if type(value) is dict:
        return {key: replace_name(item, old, new) for key, item in value.items()}
    return new if value == old else value


class InventoryTests(unittest.TestCase):
    def test_constants_match_r3_driver_without_importing_or_executing_it(self):
        driver = Path(__file__).resolve().parent / "evidence/gate-driver-r3.py"
        raw = driver.read_bytes()
        self.assertEqual(hashlib.sha256(raw).hexdigest(), validator.DRIVER_BASELINE_SHA256)
        assignments = {node.targets[0].id: node.value for node in ast.parse(raw).body
                       if isinstance(node, ast.Assign) and len(node.targets) == 1
                       and isinstance(node.targets[0], ast.Name)}
        for key in ("HOST_TESTS", "INTEGRATION_TESTS", "CODE_MODE_IGNORED", "INTEGRATION_IGNORED"):
            expected = ast.literal_eval(assignments[key])
            actual = getattr(validator, key)
            self.assertEqual(list(actual) if type(expected) is list else actual, expected)
        self.assertEqual(len(validator.EXPECTED_GATES), 34)
        self.assertEqual(len(validator.RUST_TEST_GATES), 25)

    def test_valid_inventory_uses_callback_and_keeps_unexecuted_ignored_explicit(self):
        report, results = synthetic_receipt()
        observed = []
        for check in report["checks"]:
            if "test_selection" in check:
                check["test_results"] = [{"child_result_diagnostic": True}]

        def parent_result(check):
            observed.append(check["name"])
            return results[check["name"]]

        summary = validator.validate_inventory(report, parent_result)
        self.assertEqual(set(observed), validator.RUST_TEST_GATES)
        self.assertEqual(len(observed), 25)
        self.assertEqual(summary["mandatory_ignored_minimum"], 14)
        self.assertEqual(summary["library"]["code_mode_ignored_executed"], 3)
        self.assertEqual(summary["integration_targets"]["two_tools"]["ignored_executed"], 8)
        self.assertEqual(summary["library"]["ignored_not_executed"], ["unrelated::ignored_case"])
        self.assertFalse(summary["execution_provenance_validated_here"])

    def test_same_count_wrong_stage_order_name_or_boolean_exit_is_rejected(self):
        for defect in ("order", "name", "boolean", "unexpected_selection"):
            report, results = synthetic_receipt()
            with self.subTest(defect=defect):
                if defect == "order":
                    report["checks"][0], report["checks"][1] = report["checks"][1], report["checks"][0]
                elif defect == "name":
                    report["checks"][0]["name"] = "replacement-policy"
                elif defect == "boolean":
                    report["checks"][0]["exit_code"] = False
                else:
                    report["checks"][0]["test_selection"] = {}
                with self.assertRaises(validator.InventoryError):
                    validator.validate_inventory(report, lambda check: results[check["name"]])

    def test_declared_disjoint_flags_cannot_hide_overlap_missing_or_duplicate_names(self):
        for defect in ("overlap", "missing", "duplicate", "wrong_host"):
            report, results = synthetic_receipt()
            inventory = report["library_test_names"]
            with self.subTest(defect=defect):
                if defect == "overlap":
                    inventory["private"][0] = inventory["host"][0]
                elif defect == "missing":
                    inventory["all"].append("unselected::test")
                elif defect == "duplicate":
                    inventory["all"][0] = inventory["all"][1]
                else:
                    inventory["host"][0] = "not_the_exact_host_test"
                with self.assertRaises(validator.InventoryError):
                    validator.validate_inventory(report, lambda check: results[check["name"]])

    def test_matching_counts_do_not_replace_required_ignored_test_names(self):
        for mandatory in (next(iter(validator.CODE_MODE_IGNORED)),
                          next(iter(validator.INTEGRATION_IGNORED["two_tools"]))):
            report, results = synthetic_receipt()
            prefix = "code_mode::tests::" if mandatory.startswith("code_mode::tests::") else ""
            report = replace_name(report, mandatory, prefix + "different_test_with_same_count")
            with self.subTest(mandatory=mandatory), self.assertRaises(validator.InventoryError):
                validator.validate_inventory(report, lambda check: results[check["name"]])

    def test_all_ignored_execution_is_required_beyond_the_mandatory_subset(self):
        report, results = synthetic_receipt()
        target = report["integration_test_names"]["two_tools"]
        target["ignored_selected"].remove("additional_ignored_case")
        target["ignored_not_executed"].append("additional_ignored_case")
        check = next(check for check in report["checks"] if check["name"] == "integration-two_tools-ignored")
        check["test_selection"]["selected"].remove("additional_ignored_case")
        check["test_selection"]["expected_result"]["passed"] -= 1
        results[check["name"]]["passed"] -= 1
        with self.assertRaisesRegex(validator.InventoryError, "selected names differ"):
            validator.validate_inventory(report, lambda row: results[row["name"]])

    def test_selected_counts_and_real_parent_summary_must_both_match(self):
        for defect in ("plan_count", "parent_count", "boolean_count", "failed_parent"):
            report, results = synthetic_receipt()
            check = next(row for row in report["checks"] if row["name"] == "library-private")
            with self.subTest(defect=defect):
                if defect == "plan_count":
                    check["test_selection"]["expected_result"]["passed"] += 1
                elif defect == "parent_count":
                    results["library-private"]["passed"] += 1
                elif defect == "boolean_count":
                    results["library-private"]["failed"] = False
                else:
                    results["library-private"]["result"] = "FAILED"
                with self.assertRaises(validator.InventoryError):
                    validator.validate_inventory(report, lambda row: results[row["name"]])

    def test_target_identity_and_exact_ignored_argv_are_checked(self):
        for defect in ("target", "artifact_path", "ignored_argv", "binary_alias"):
            report, results = synthetic_receipt()
            with self.subTest(defect=defect):
                if defect == "target":
                    entries = report["cargo_metadata"]["test_targets"]
                    entries["different_target"] = entries.pop("context")
                elif defect == "artifact_path":
                    report["integration_artifacts"]["two_tools"]["path"] = "/wrong/binary"
                elif defect == "ignored_argv":
                    row = next(check for check in report["checks"]
                               if check["name"] == "integration-two_tools-ignored")
                    row["command"].remove("--ignored")
                else:
                    report["integration_binaries"]["context"] = report["integration_binaries"]["resources"]
                with self.assertRaises(validator.InventoryError):
                    validator.validate_inventory(report, lambda row: results[row["name"]])


    def test_zuse_stage_requires_its_actual_unique_ignored_exact_execution(self):
        for defect in ("ordinary", "wrong_test", "extra_test", "wrong_argv", "skipped"):
            report, results = synthetic_receipt()
            entry = report["integration_test_names"]["zuse_worker_entry"]
            stage = next(x for x in report["checks"] if x["name"] == "integration-zuse_worker_entry")
            with self.subTest(defect=defect):
                if defect == "ordinary":
                    entry["execution_mode"] = "ordinary"
                elif defect == "wrong_test":
                    report = replace_name(report, validator.ZUSE_WORKER_TEST, "same_count_other_test")
                elif defect == "extra_test":
                    entry["all"].append("unaccounted_test")
                elif defect == "wrong_argv":
                    stage["command"].remove("--ignored")
                else:
                    stage["test_selection"]["selected"] = []
                with self.assertRaises(validator.InventoryError):
                    validator.validate_inventory(report, lambda row: results[row["name"]])

    def test_held_driver_hash_is_rejected(self):
        report, results = synthetic_receipt()
        report["script_sha256"] = "e60958dc12e0cd8ab0618f894653273d919252213126481174f6b74318c11b57"
        with self.assertRaises(validator.InventoryError):
            validator.validate_inventory(report, lambda row: results[row["name"]])


class ParentLogTests(unittest.TestCase):
    def fixture(self):
        child = "test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out"
        parent = "test result: ok. 1759 passed; 0 failed; 22 ignored; 0 measured; 4 filtered out; finished in 32.1s"
        raw = "running child\n" + child + "\nparent continued\n" + parent + "\n\n"
        row = {"test_child_summaries": [
            {"line_number": 2, "raw_line": child, "parsed": validator._parse_result_line(child)}],
            "test_results": [validator._parse_result_line(parent)]}
        return row, raw, child, parent

    def test_legitimate_child_summary_does_not_replace_parent(self):
        row, raw, _, _ = self.fixture()
        self.assertEqual(validator.parent_result(row, raw)["passed"], 1759)

    def test_raw_trailer_truncation_or_duplicate_parent_is_rejected(self):
        for defect in ("trailer", "truncated", "duplicate", "indented"):
            row, raw, child, parent = self.fixture()
            with self.subTest(defect=defect):
                if defect == "trailer":
                    raw += "unbound post-test diagnostic\n"
                elif defect == "truncated":
                    raw = raw.replace(parent, parent[:40])
                elif defect == "duplicate":
                    raw = parent + "\n" + raw
                else:
                    raw = raw.replace(parent, " " + parent)
                with self.assertRaises(validator.InventoryError):
                    validator.parent_result(row, raw)

    def test_recorded_children_counts_bool_or_failed_parent_cannot_override_raw(self):
        for defect in ("missing_child", "child_line", "counts", "boolean", "failed"):
            row, raw, child, parent = self.fixture()
            with self.subTest(defect=defect):
                if defect == "missing_child":
                    row["test_child_summaries"] = []
                elif defect == "child_line":
                    row["test_child_summaries"][0]["line_number"] = 3
                elif defect == "counts":
                    row["test_results"][0]["passed"] = 1
                elif defect == "boolean":
                    row["test_results"][0]["failed"] = False
                else:
                    raw = raw.replace(parent, parent.replace("ok.", "FAILED."))
                    row["test_results"][0]["result"] = "FAILED"
                with self.assertRaises(validator.InventoryError):
                    validator.parent_result(row, raw)


if __name__ == "__main__":
    unittest.main()
