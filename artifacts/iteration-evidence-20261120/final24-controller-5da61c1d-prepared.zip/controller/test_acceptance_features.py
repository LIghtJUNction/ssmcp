"""Synthetic filesystem/report contracts; no product, renderer or gate runs."""

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

import acceptance_contracts as contract
import run_bound_v4 as runner


def frame(rows=30, cols=120, marker="SYNTHETIC CONTRACT"):
    blank = {"text": "", "wide": False, "continuation": False,
             "foreground": None, "background": None, "bold": False, "dim": False, "inverse": False}
    grid = [[dict(blank) for _ in range(cols)] for _ in range(rows)]
    for index, char in enumerate(marker):
        grid[0][index]["text"] = char
    return {"ok": True, "size": [rows, cols], "rows": [marker] + [""] * (rows - 1),
            "cells": grid, "cursor": [0, 0], "alternate_screen": True, "hide_cursor": False}


def hashes():
    return {"files": {name: {"sha256": hashlib.sha256(name.encode()).hexdigest()} for name in
                     ("ssmcp", "ssmcpd", "ssmcp-frontend", "decoder", "fixture_binary", "font", "old_server")},
            "source_files": {contract.LATENCY_SCRIPT: {"sha256": contract.LATENCY_SHA256}}}


def latency_report():
    local = {"mouse_content_focus", "mouse_composer_focus", "typed_draft_frame"}
    actions = ["send_accepted_frame", "up_confirmed_takeback_frame", "edited_send_accepted_frame",
               "up_delivered_input_history_frame", *sorted(local)]
    samples = []
    for index, name in enumerate(actions):
        item = {"action": name, "input_ms": index * 10, "visible_ms": index * 10 + 2,
                "latency_ms": 2, "budget_ms": 250 if name in local else 500, "within_budget": True}
        if name in local:
            item["overlapped_history_call"] = True
        samples.append(item)
    return {"focused_runner_sha256": contract.LATENCY_SHA256, "latency_samples": samples,
            "history_write_calls": [{"start_ms": 0, "end_ms": 1000, "history_saved": True}]}


class FeatureContracts(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="ssmcp-feature-contract-")
        self.root = Path(self.temporary.name)

    def tearDown(self):
        self.temporary.cleanup()

    def test_exact_twenty_four_suite_order_and_frozen_native_environment(self):
        self.assertEqual(len(runner.SUITES), 24)
        self.assertEqual(len(set(runner.SUITES)), 24)
        self.assertEqual(runner.SUITES[-6:], contract.FEATURE_SUITES)
        args = SimpleNamespace(runtime_bin=self.root / "runtime", source_path=self.root / "source")
        env = runner.suite_environment(args, "physical_latency")
        self.assertEqual(env["PYTHONPATH"], str(args.source_path / "scripts"))
        self.assertEqual(env["SSMCP_NODE"], str(args.runtime_bin / "node"))
        self.assertEqual(env["SSMCP_CODE_MODE_RUNNER"], str(args.source_path / "src/code_mode.js"))
        self.assertTrue(env["PATH"].startswith(str(args.runtime_bin) + ":"))
        self.assertNotIn("NODE_OPTIONS", env)
        self.assertNotIn("PYTHONPATH", runner.suite_environment(args, "human_finish"))

    def test_cli_ast_reads_fixed_argument_loops_without_running_them(self):
        script = self.root / "never_executed.py"
        script.write_text('raise RuntimeError("must never execute")\n'
                          'for name in ("bin-dir", "font", "out"):\n'
                          '    parser.add_argument("--" + name, required=True)\n'
                          'parser.add_argument("--source-revision", required=True)\n')
        self.assertEqual(runner.cli_flags(script), {"--bin-dir", "--font", "--out", "--source-revision"})

    def test_feature_argv_uses_actual_human_fixture_env_and_latency_entry(self):
        args = SimpleNamespace(bin_dir=self.root / "bin", decoder=self.root / "decoder",
                               fixture_binary=self.root / "fixture", source_revision="a" * 40,
                               font=self.root / "font")
        human, _ = runner.suite_arguments(args, "human_finish", self.root / "new", "0.2.2")
        self.assertNotIn("--fixture-binary", human)
        for name in contract.FEATURE_SUITES[1:]:
            argv, _ = runner.suite_arguments(args, name, self.root / "new", "0.2.2")
            self.assertIn("--fixture-binary", argv)
            self.assertIn("--source-revision", argv)
            self.assertNotIn("-I", argv)
            self.assertEqual("--font" in argv, name in ("tool_summaries", "readable_commands", "summary_commands"))
        self.assertEqual(contract.script_relative("physical_latency"), contract.LATENCY_SCRIPT)

    def test_cell_grid_requires_full_dimensions_styles_and_matching_visible_rows(self):
        self.assertEqual(contract.validate_cells(frame()), (30, 120))
        for defect in ("no_grid", "short_row", "missing_style", "boolean_dimension", "wrong_visible", "bad_color"):
            shot = frame()
            with self.subTest(defect=defect):
                if defect == "no_grid":
                    shot.pop("cells")
                elif defect == "short_row":
                    shot["cells"][0].pop()
                elif defect == "missing_style":
                    shot["cells"][0][0].pop("wide")
                elif defect == "boolean_dimension":
                    shot["size"][0] = True
                elif defect == "wrong_visible":
                    shot["rows"][0] = "different synthetic claim"
                else:
                    shot["cells"][0][0]["foreground"] = True
                with self.assertRaises(contract.ContractError):
                    contract.validate_cells(shot)

    def _human_frames(self):
        records = []
        for index, width in enumerate((120, 48, 48, 120, 48)):
            path = self.root / f"human-{index}.json"
            raw = (json.dumps(frame(cols=width)) + "\n").encode()
            path.write_bytes(raw)
            records.append({"path": path.name, "sha256": hashlib.sha256(raw).hexdigest(),
                            "rows": 30, "cols": width, "source_kind": "owned_pty_capture",
                            "keyboard_actor": "fixture_simulated_user"})
        return {"frames": records}

    def test_human_object_frames_bind_same_bytes_dimensions_and_simulated_actor(self):
        report = self._human_frames()
        verified = contract.verify_feature_frames(report, "human_finish", self.root)
        self.assertEqual(len(verified), 5)
        for defect in ("hash", "dimensions", "actor", "count", "path"):
            altered = deepcopy(report)
            with self.subTest(defect=defect):
                if defect == "hash":
                    altered["frames"][0]["sha256"] = "0" * 64
                elif defect == "dimensions":
                    altered["frames"][0]["rows"] = 32
                elif defect == "actor":
                    altered["frames"][0]["keyboard_actor"] = "real_user"
                elif defect == "count":
                    altered["frames"].pop()
                else:
                    altered["frames"][0]["path"] = "../outside.json"
                with self.assertRaises(contract.ContractError):
                    contract.verify_feature_frames(altered, "human_finish", self.root)

    def test_human_frame_symlink_and_changed_cells_are_rejected(self):
        report = self._human_frames()
        path = self.root / report["frames"][0]["path"]
        outside = self.root.parent / (self.root.name + "-outside.json")
        outside.write_bytes(path.read_bytes())
        try:
            path.unlink()
            path.symlink_to(outside)
            with self.assertRaises(contract.ContractError):
                contract.verify_feature_frames(report, "human_finish", self.root)
            path.unlink()
            changed = frame(marker="CHANGED SYNTHETIC FRAME")
            path.write_text(json.dumps(changed))
            with self.assertRaises(contract.ContractError):
                contract.verify_feature_frames(report, "human_finish", self.root)
        finally:
            outside.unlink()

    def test_goal_strings_require_matching_separate_frame_manifest(self):
        report = {"frames": [], "frame_manifest": []}
        for index, width in enumerate((120, 48, 120, 48, 120, 120, 48)):
            path = self.root / f"goal-{index}.json"
            raw = json.dumps(frame(rows=32, cols=width)).encode()
            path.write_bytes(raw)
            report["frames"].append(path.name)
            report["frame_manifest"].append({"path": path.name, "sha256": hashlib.sha256(raw).hexdigest(),
                                             "size": [32, width]})
        self.assertEqual(len(contract.verify_feature_frames(report, "goal_startup", self.root)), 7)
        missing = deepcopy(report)
        missing.pop("frame_manifest")
        with self.assertRaises(contract.ContractError):
            contract.verify_feature_frames(missing, "goal_startup", self.root)
        report["frame_manifest"][0]["sha256"] = "0" * 64
        with self.assertRaises(contract.ContractError):
            contract.verify_feature_frames(report, "goal_startup", self.root)

    def test_feature_png_requires_complete_image_bytes_not_only_a_signature(self):
        from PIL import Image
        report = {"frames": []}
        for index, width in enumerate((120, 48, 120, 48, 120, 48)):
            png = self.root / f"summary-{index}.png"
            png.with_suffix(".json").write_text(json.dumps(frame(rows=32, cols=width)))
            Image.new("RGB", (width, 32), "white").save(png)
            report["frames"].append(png.name)
        self.assertEqual(len(contract.verify_feature_frames(report, "tool_summaries", self.root)), 6)
        (self.root / report["frames"][0]).write_bytes(b"\x89PNG\r\n\x1a\ntruncated synthetic image")
        with self.assertRaises(contract.ContractError):
            contract.verify_feature_frames(report, "tool_summaries", self.root)

    def test_latency_budget_failure_cannot_be_relabelled_as_success(self):
        contract.validate_latency(latency_report(), hashes())
        for defect in ("budget", "false", "nan", "inconsistent", "missing_action", "changed_runner", "overlap"):
            value = latency_report()
            with self.subTest(defect=defect):
                first = value["latency_samples"][0]
                if defect == "budget":
                    first.update(latency_ms=501, visible_ms=501, within_budget=True)
                elif defect == "false":
                    first["within_budget"] = False
                elif defect == "nan":
                    first["latency_ms"] = float("nan")
                elif defect == "inconsistent":
                    first["visible_ms"] = 17
                elif defect == "missing_action":
                    value["latency_samples"].pop()
                elif defect == "changed_runner":
                    value["focused_runner_sha256"] = "0" * 64
                else:
                    value["history_write_calls"][0]["end_ms"] = 1
                with self.assertRaises(contract.ContractError):
                    contract.validate_latency(value, hashes())

    def test_physical_recall_captures_use_the_full_fifty_eight_row_view(self):
        report = {"frames": []}
        for index, width in enumerate((120, 48) * 5):
            path = self.root / f"recall-{index}.json"
            path.write_text(json.dumps(frame(rows=58, cols=width)))
            report["frames"].append(path.name)
        self.assertEqual(len(contract.verify_feature_frames(report, "physical_latency", self.root)), 10)
        (self.root / report["frames"][0]).write_text(json.dumps(frame(rows=30, cols=120)))
        with self.assertRaises(contract.ContractError):
            contract.verify_feature_frames(report, "physical_latency", self.root)

    def test_summary_scenario_totals_cannot_be_boolean_or_omit_a_scenario(self):
        report = {"checks": 3, "scenarios": [
            {"checks": 1, "passed_checks": ["one"]},
            {"checks": 2, "passed_checks": ["two", "three"]},
        ]}
        self.assertEqual(runner.check_count(report, "summary_commands"), 3)
        for defect in ("boolean", "missing", "failed", "total"):
            value = deepcopy(report)
            with self.subTest(defect=defect):
                if defect == "boolean":
                    value["checks"] = True
                elif defect == "missing":
                    value["scenarios"].pop()
                elif defect == "failed":
                    value["scenarios"][1]["passed_checks"][0] = {"name": "bad", "passed": False}
                else:
                    value["checks"] = 4
                with self.assertRaises(RuntimeError):
                    runner.check_count(value, "summary_commands")

    def test_human_source_prefix_and_router_alias_preserve_exact_hash_contract(self):
        baseline = hashes()
        baseline["source_files"]["scripts/e2e_human_finish.py"] = {"sha256": "a" * 64}
        data = {"status": "passed", "checks": ["one"],
                "sources": {"source/e2e_human_finish.py": "a" * 64},
                "binaries": {"router_test": baseline["files"]["fixture_binary"]["sha256"]}}
        args = SimpleNamespace(source_revision="b" * 40)
        self.assertEqual(runner.verify_report(data, "human_finish", args, "0.2.2", baseline), 1)
        data["binaries"]["router_test"] = "0" * 64
        with self.assertRaises(RuntimeError):
            runner.verify_report(data, "human_finish", args, "0.2.2", baseline)


if __name__ == "__main__":
    unittest.main()
