"""Pure inventory and parent-log checks for the immutable r3 gate contract.

Runs no commands and imports no gate driver. Filesystem, source, archive, binary,
raw log and --list provenance remain the caller's responsibility. The callback
for validate_inventory must return parent_result(check, bound_raw_log_text).
"""

from collections.abc import Callable, Mapping
from typing import Any
import json
import re


DRIVER_BASELINE_SHA256 = (
    "1ad9ec768988aa8aeba23ffbd97ce565908f88d6c64d3a14ebb64049c5bc782d"
)
ZUSE_WORKER_TEST = "missing_worker_entry_is_recoverable_without_spawning_the_embedding_binary"

HOST_TESTS = (
    "client::local::tests::bundled_runner_is_private_and_removed_after_failed_startup",
    "client::local::tests::bundled_runner_never_overwrites_or_removes_a_replaced_file",
    "client::local::tests::private_socket_rejects_symlinks_and_exposed_permissions",
    "client::local::tests::gateway_checks_all_origins_and_has_no_portal_routes",
)
INTEGRATION_TESTS = (
    "allow_account", "cc_backend", "client_resources", "client_server_config",
    "codex_backend", "collaboration", "context", "context_helpers", "context_runtime",
    "oauth_security", "pi_backend", "release_client", "resources", "rsync",
    "server_runtime", "terminals", "two_tools", "workspace_bridge", "zuse_worker_entry",
)
CODE_MODE_IGNORED = frozenset({
    "code_mode::tests::runtime_check_uses_the_mandatory_system_sandbox",
    "code_mode::tests::real_system_runtime_uses_mandatory_os_isolation",
})
INTEGRATION_IGNORED = {
    "two_tools": frozenset({
        "local_composer_delivers_at_response_boundary_and_exact_targets_require_binding",
        "code_mode_http_forwards_full_source_only_to_called_clients_and_reports_run_outcome",
        "reload_returns_its_ack_after_native_disconnect_and_revokes_the_old_token",
        "reload_rejects_unavailable_client_ids_and_invalid_tokens_before_native_dispatch",
        "public_tools_cover_every_backend_with_native_discovery_and_javascript_dispatch",
        "credentials_and_client_ids_follow_individual_connection_lifetimes",
        "running_code_rechecks_issuer_authority_before_each_native_call",
    }),
    "workspace_bridge": frozenset({
        "real_rsync_dry_run_forward_reverse_delete_and_rooted_fs",
        "tcp_mappings_work_in_both_directions_preserve_half_close_and_cleanup",
        "cancelling_an_active_sync_closes_every_owned_rsync_endpoint",
    }),
    "context_helpers": frozenset({
        "skill_discovery_and_instruction_resolution_preserve_scope_and_provenance",
        "text_helpers_preserve_unicode_binary_compatibility_and_edit_preconditions",
    }),
}
IGNORED_GATES = (
    "library-code-mode-ignored",
    *(f"integration-{name}-ignored" for name in INTEGRATION_IGNORED),
)
INTEGRATION_GATES = tuple(f"integration-{name}" for name in INTEGRATION_TESTS)
RUST_TEST_GATES = frozenset({
    "library-private", "library-host", *INTEGRATION_GATES, *IGNORED_GATES,
})
EXPECTED_GATES = (
    "release-policy", "deployment-policy", "fmt", "library-compile",
    "library-private", "library-host", "clippy", "windows-gnu-clippy", "integration-compile",
    *INTEGRATION_GATES, *IGNORED_GATES, "release", "decoder",
)
RESULT_KEYS = frozenset({"result", "passed", "failed", "ignored", "measured", "filtered"})


class InventoryError(ValueError):
    """The declared inventories, stage commands or observed results disagree."""


def _need(condition: bool, message: str) -> None:
    if not condition:
        raise InventoryError(message)


def _mapping(value: Any, label: str) -> Mapping:
    _need(isinstance(value, Mapping), f"{label} must be an object")
    return value


def _names(value: Any, label: str) -> set[str]:
    _need(type(value) is list, f"{label} must be a list")
    _need(all(type(name) is str and name and name.strip() == name for name in value),
          f"{label} contains an invalid name")
    _need(len(value) == len(set(value)), f"{label} contains duplicate names")
    return set(value)


def _integer(value: Any, expected: int, label: str) -> None:
    _need(type(value) is int and value == expected, f"{label}: expected integer {expected}")


def _result(value: Any, label: str) -> dict[str, Any]:
    value = _mapping(value, label)
    _need(set(value) == RESULT_KEYS, f"{label} has unexpected summary fields")
    _need(value["result"] == "ok", f"{label} is not an ok parent summary")
    for key in RESULT_KEYS - {"result"}:
        _need(type(value[key]) is int and value[key] >= 0,
              f"{label}.{key} must be a nonnegative integer, not a boolean")
    return dict(value)


def _command_tail(check: Mapping, tail: list[str]) -> None:
    command = check.get("command")
    _need(type(command) is list and all(type(arg) is str for arg in command),
          f"{check['name']}: missing command argv")
    _need(len(command) >= len(tail) and command[-len(tail):] == tail,
          f"{check['name']}: argv does not execute the enumerated selection")


def _selection(
    check: Mapping,
    all_names: set[str],
    ignored: set[str],
    matched: set[str],
    supplied_result: Callable[[Mapping], Mapping],
    *,
    ignored_only: bool = False,
    allow_empty: bool = False,
    required_ignored_stage: str | None = None,
    execution_mode: str | None = None,
) -> set[str]:
    name = check["name"]
    _need(matched <= all_names and ignored <= all_names, f"{name}: unknown test name")
    _need(not ignored_only or matched <= ignored, f"{name}: ordinary test in ignored stage")
    skipped = set() if ignored_only else matched & ignored
    selected = matched - skipped
    _need(bool(selected) or (allow_empty and bool(skipped) and not ignored_only),
          f"{name}: empty required selection")
    expected = {
        "result": "ok", "passed": len(selected), "failed": 0,
        "ignored": len(skipped), "measured": 0, "filtered": len(all_names - matched),
    }
    plan = _mapping(check.get("test_selection"), f"{name}.test_selection")
    keys = {"selected", "skipped_ignored", "expected_result"}
    if required_ignored_stage is not None:
        keys.add("required_ignored_stage")
        _need(plan.get("required_ignored_stage") == required_ignored_stage,
              f"{name}: missing its required ignored-stage link")
    if execution_mode is not None:
        keys.add("execution_mode")
        _need(plan.get("execution_mode") == execution_mode,
              f"{name}: mismatched execution mode")
    _need(set(plan) == keys, f"{name}: unexpected test-selection fields")
    _need(_names(plan["selected"], f"{name}.selected") == selected,
          f"{name}: selected names differ from inventory")
    _need(_names(plan["skipped_ignored"], f"{name}.skipped_ignored") == skipped,
          f"{name}: skipped ignored names differ from inventory")
    _need(_result(plan["expected_result"], f"{name}.expected_result") == expected,
          f"{name}: declared counts differ from enumerated names")
    # The callback binds the exact r3 parent rule to the authenticated raw log.
    observed = _result(supplied_result(check), f"{name}.supplied_parent_result")
    _need(observed == expected, f"{name}: parent result differs from enumerated selection")
    return selected


def validate_inventory(
    report: Mapping,
    supplied_result: Callable[[Mapping], Mapping],
) -> dict[str, Any]:
    """Validate the fixed inventory and return an inventory-only summary.

    Raises InventoryError on mismatch. No filesystem, network, driver import or
    subprocess is used. Parent-summary provenance belongs to supplied_result;
    source, list-log, executable and runtime bindings remain the caller's gates.
    """
    report = _mapping(report, "report")
    _need(report.get("status") == "passed", "receipt is not in passed state")
    _need(report.get("script_sha256") == DRIVER_BASELINE_SHA256,
          "receipt does not name the immutable reviewed r3 driver")
    _need(callable(supplied_result), "supplied_result must be a parent-summary callback")
    checks = report.get("checks")
    _need(type(checks) is list and all(isinstance(row, Mapping) for row in checks),
          "checks must be an array of stage objects")
    _need([row.get("name") for row in checks] == list(EXPECTED_GATES),
          "stage names/order differ from the 34-stage contract")
    for row in checks:
        _integer(row.get("exit_code"), 0, f"{row['name']}.exit_code")
        _need("test_validation_error" not in row, f"{row['name']}: test validation error")
    _need({row["name"] for row in checks if "test_selection" in row} == RUST_TEST_GATES,
          "exactly the 25 Rust stages must carry test selections")
    by_name = {row["name"]: row for row in checks}

    inventory = _mapping(report.get("library_test_names"), "library_test_names")
    fields = {key: _names(inventory.get(key), f"library.{key}") for key in (
        "all", "private", "host", "ignored", "private_selected", "host_selected",
        "ignored_code_mode", "ignored_not_executed",
    )}
    all_names, private, host, ignored = (fields[key] for key in ("all", "private", "host", "ignored"))
    _need(bool(all_names) and bool(private), "library inventory/private partition is empty")
    _need(host == set(HOST_TESTS), "library host partition is not the four exact host tests")
    _need(not private & host and private | host == all_names,
          "library partitions are not complete and disjoint")
    _need(ignored <= all_names and not host & ignored, "library ignored membership is invalid")
    partition = _mapping(report.get("library_partition"), "library_partition")
    for key, names in (("total", all_names), ("private", private), ("host", host)):
        _integer(partition.get(key), len(names), f"library_partition.{key}")
    _need(partition.get("complete") is True and partition.get("disjoint") is True,
          "library partition receipt flags are inconsistent")
    code_mode = {name for name in ignored if name.startswith("code_mode::tests::")}
    _need(CODE_MODE_IGNORED <= code_mode, "library is missing a mandatory code-mode ignored test")
    _need(fields["ignored_code_mode"] == code_mode,
          "library code-mode stage must execute every listed code-mode ignored test")
    _need(fields["ignored_not_executed"] == ignored - code_mode,
          "library unexecuted ignored inventory is incomplete")
    library_binary = report.get("library_binary")
    _need(type(library_binary) is str and bool(library_binary), "missing library binary path")
    private_tail = [library_binary, "--exact", "--test-threads=4"]
    for name in HOST_TESTS:
        private_tail.extend(("--skip", name))
    _command_tail(by_name["library-private"], private_tail)
    _command_tail(by_name["library-host"], [library_binary, "--exact", "--test-threads=1", *HOST_TESTS])
    _command_tail(by_name["library-code-mode-ignored"],
                  [library_binary, "--ignored", "--exact", "--test-threads=1", *sorted(code_mode)])
    selected_by_stage = {
        "library-private": _selection(by_name["library-private"], all_names, ignored, private, supplied_result),
        "library-host": _selection(by_name["library-host"], all_names, ignored, host, supplied_result),
        "library-code-mode-ignored": _selection(
            by_name["library-code-mode-ignored"], all_names, ignored, code_mode, supplied_result,
            ignored_only=True,
        ),
    }
    _need(fields["private_selected"] == selected_by_stage["library-private"]
          and fields["host_selected"] == selected_by_stage["library-host"],
          "library selected-name projections disagree with their stages")

    expected_targets = set(INTEGRATION_TESTS)
    integrations = _mapping(report.get("integration_test_names"), "integration_test_names")
    binaries = _mapping(report.get("integration_binaries"), "integration_binaries")
    artifacts = _mapping(report.get("integration_artifacts"), "integration_artifacts")
    metadata = _mapping(report.get("cargo_metadata"), "cargo_metadata")
    targets = _mapping(metadata.get("test_targets"), "cargo_metadata.test_targets")
    for label, values in (("test names", integrations), ("binaries", binaries),
                          ("artifacts", artifacts), ("Cargo targets", targets)):
        _need(set(values) == expected_targets, f"integration {label} are not the exact 19 targets")
    _need(all(type(path) is str and path for path in binaries.values()), "invalid integration binary path")
    _need(len(set(binaries.values())) == len(INTEGRATION_TESTS)
          and library_binary not in binaries.values(), "test binary paths are not distinct")
    integration_summary = {}
    for name in INTEGRATION_TESTS:
        entry = _mapping(integrations[name], f"integration.{name}")
        names = {key: _names(entry.get(key), f"integration.{name}.{key}") for key in (
            "all", "ignored", "ordinary_selected", "ignored_selected", "ignored_not_executed",
        )}
        tests, ignored = names["all"], names["ignored"]
        _need(ignored <= tests, f"{name}: ignored names absent from all-tests inventory")
        _need(_mapping(artifacts[name], f"artifact.{name}").get("path") == binaries[name],
              f"{name}: stage binary differs from declared artifact")
        _need(type(targets[name]) is str and bool(targets[name]), f"{name}: missing Cargo source path")
        ordinary_name = f"integration-{name}"
        ignored_name = f"integration-{name}-ignored" if name in INTEGRATION_IGNORED else None
        if name == "zuse_worker_entry":
            required = {ZUSE_WORKER_TEST}
            _need(tests == ignored == required,
                  "zuse_worker_entry must contain exactly the reviewed ignored test")
            _need(entry.get("execution_mode") == "ignored-exact",
                  "zuse_worker_entry must use ignored-exact mode")
            _command_tail(by_name[ordinary_name], [binaries[name], "--ignored", "--exact",
                                                  ZUSE_WORKER_TEST, "--test-threads=1"])
            selected_ignored = _selection(
                by_name[ordinary_name], tests, ignored, required, supplied_result,
                ignored_only=True, execution_mode="ignored-exact",
            )
            ordinary = set()
            selected_by_stage[ordinary_name] = selected_ignored
        else:
            _need(entry.get("execution_mode") == "ordinary", f"{name}: invalid execution mode")
            _command_tail(by_name[ordinary_name], [binaries[name], "--test-threads=4"])
            ordinary = _selection(
                by_name[ordinary_name], tests, ignored, tests, supplied_result,
                allow_empty=ignored_name is not None and name in ("workspace_bridge", "context_helpers"),
                required_ignored_stage=ignored_name,
            )
            selected_by_stage[ordinary_name] = ordinary
            selected_ignored = set()
        if ignored_name is not None:
            _need(INTEGRATION_IGNORED[name] <= ignored, f"{name}: missing a mandatory ignored test")
            _command_tail(by_name[ignored_name], [binaries[name], "--ignored", "--test-threads=1"])
            selected_ignored = _selection(
                by_name[ignored_name], tests, ignored, ignored, supplied_result, ignored_only=True,
            )
            selected_by_stage[ignored_name] = selected_ignored
        _need(names["ordinary_selected"] == ordinary and names["ignored_selected"] == selected_ignored,
              f"{name}: selected-name projections disagree with actual stage selection")
        _need(names["ignored_not_executed"] == ignored - selected_ignored,
              f"{name}: unexecuted ignored inventory is incomplete")
        integration_summary[name] = {
            "all": len(tests), "ordinary_executed": len(ordinary),
            "ignored_executed": len(selected_ignored),
            "ignored_not_executed": sorted(names["ignored_not_executed"]),
        }
    _need(set(selected_by_stage) == RUST_TEST_GATES, "some Rust stages were not independently validated")
    return {
        "schema": "ssmcp.gate-inventory-review.r3",
        "verdict": "inventory_consistent",
        "contract_baseline_sha256": DRIVER_BASELINE_SHA256,
        "stage_names": list(EXPECTED_GATES),
        "rust_stage_names": [name for name in EXPECTED_GATES if name in RUST_TEST_GATES],
        "selected_counts": {name: len(selected_by_stage[name]) for name in EXPECTED_GATES
                            if name in RUST_TEST_GATES},
        "library": {
            "total": len(all_names), "private_matched": len(private), "host_matched": len(host),
            "code_mode_ignored_executed": len(code_mode),
            "ignored_not_executed": sorted(fields["ignored_not_executed"]),
        },
        "integration_targets": integration_summary,
        "mandatory_ignored_minimum": len(CODE_MODE_IGNORED) + sum(map(len, INTEGRATION_IGNORED.values())),
        "zuse_worker_ignored_exact_executed": 1,
        "execution_provenance_validated_here": False,
    }


def _parse_result_line(line: str) -> dict[str, Any] | None:
    match = re.fullmatch(
        r"test result: (ok|FAILED)\. ([0-9]+) passed; ([0-9]+) failed; ([0-9]+) ignored; "
        r"([0-9]+) measured; ([0-9]+) filtered out(?:; finished in [0-9]+(?:\.[0-9]+)?s)?",
        line,
    )
    if match is None:
        return None
    return dict(zip(("result", "passed", "failed", "ignored", "measured", "filtered"),
                    (match[1], *map(int, match.groups()[1:]))))


def _strict_json_equal(left: Any, right: Any) -> bool:
    # Python considers False equal to 0; receipt types are part of the contract.
    return json.dumps(left, sort_keys=True, separators=(",", ":")) == json.dumps(
        right, sort_keys=True, separators=(",", ":"))


def parent_result(check: Mapping, raw_text: str) -> dict[str, Any]:
    """Validate r3's final top-level summary against its original log bytes.

    The caller must freeze/hash the log before decoding it with UTF-8 and
    errors='replace', matching the r3 producer. Child summaries remain diagnostic
    records; an extra copy of the parent's exact counts is ambiguous and refused.
    A success line followed by any nonempty diagnostic is not a valid parent.
    """
    check = _mapping(check, "check")
    _need(type(raw_text) is str, "raw log must be decoded text")
    lines = raw_text.splitlines()
    while lines and not lines[-1].strip():
        lines.pop()
    final = lines[-1] if lines else ""
    observed = _parse_result_line(final)
    _need(observed is not None, "last nonempty raw log line is not a complete parent result")
    children = [
        {"line_number": number, "raw_line": line, "parsed": _parse_result_line(line)}
        for number, line in enumerate(lines[:-1], 1)
        if line.lstrip().startswith("test result:")
    ]
    _need(not any(child["parsed"] == observed for child in children),
          "duplicate parent result in raw log")
    _need(_strict_json_equal(check.get("test_child_summaries"), children),
          "recorded child diagnostics disagree with raw log")
    _need(_strict_json_equal(check.get("test_results"), [observed]),
          "recorded parent result disagrees with raw log")
    _need("test_validation_error" not in check, "driver recorded a parent validation error")
    return _result(observed, "raw parent result")
