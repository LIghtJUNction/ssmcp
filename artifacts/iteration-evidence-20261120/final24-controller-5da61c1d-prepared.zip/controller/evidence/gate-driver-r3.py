#!/usr/bin/env python3
"""Export an exact SSMCP revision and run the release gate inventory on it."""

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import secrets
import shutil
import signal
import stat
import subprocess
import sys
import tarfile
import tempfile
import time

BASE = Path("/var/tmp/ssmcp-convergence-verification-20261120")
ROOT = BASE / "release21-final-8-r3"
TEMPLATE = BASE / "release17-fixed/run_gates.py"
TEMPLATE_SHA256 = "39b1231de0cac1ffbc2f064fc12f08669273876fd655295965f979ea911fceb5"
CARGO_HOME = BASE / "release21-final8-cargo-home-r2"
TARGET = Path("/var/tmp/ssmcp-message-references-20261120/target-final8")
DEFAULT_WORKTREE = BASE / "worktree"
DEFAULT_SUBMODULE_ROOT = Path("/var/tmp/ssmcp-release17-formal-checkout-20261120/crates")
SOURCE = ROOT / "source"
ARCHIVES = ROOT / "archives"
RECEIPT = ROOT / "candidate-gates.json"
MANIFEST = ROOT / "source-manifest.json"
RUNNER = SOURCE / "src/code_mode.js"
NATIVE_BIN = ROOT / "native-bin"
BWRAP = Path("/usr/bin/bwrap")
NATIVE_TOOLS = ("node", "bwrap", "prlimit", "rsync")
DESKTOP_TOOLS = ("Xvfb", "xdotool", "magick", "xprop", "dbus-run-session", "dbus-daemon")
GITLINKS = frozenset(("crates/zharness", "crates/zplugin", "crates/ztuio", "crates/zuse"))
HOST_TESTS = [
    "client::local::tests::bundled_runner_is_private_and_removed_after_failed_startup",
    "client::local::tests::bundled_runner_never_overwrites_or_removes_a_replaced_file",
    "client::local::tests::private_socket_rejects_symlinks_and_exposed_permissions",
    "client::local::tests::gateway_checks_all_origins_and_has_no_portal_routes",
]
INTEGRATION_TESTS = [
    "allow_account", "cc_backend", "client_resources", "client_server_config",
    "codex_backend", "collaboration", "context", "context_helpers", "context_runtime",
    "oauth_security", "pi_backend", "release_client", "resources", "rsync",
    "server_runtime", "terminals", "two_tools", "workspace_bridge", "zuse_worker_entry",
]
ZUSE_WORKER_TEST = "missing_worker_entry_is_recoverable_without_spawning_the_embedding_binary"
CODE_MODE_IGNORED = {
    "code_mode::tests::runtime_check_uses_the_mandatory_system_sandbox",
    "code_mode::tests::real_system_runtime_uses_mandatory_os_isolation",
}
INTEGRATION_IGNORED = {
    "two_tools": {
        "local_composer_delivers_at_response_boundary_and_exact_targets_require_binding",
        "code_mode_http_forwards_full_source_only_to_called_clients_and_reports_run_outcome",
        "reload_returns_its_ack_after_native_disconnect_and_revokes_the_old_token",
        "reload_rejects_unavailable_client_ids_and_invalid_tokens_before_native_dispatch",
        "public_tools_cover_every_backend_with_native_discovery_and_javascript_dispatch",
        "credentials_and_client_ids_follow_individual_connection_lifetimes",
        "running_code_rechecks_issuer_authority_before_each_native_call",
    },
    "workspace_bridge": {
        "real_rsync_dry_run_forward_reverse_delete_and_rooted_fs",
        "tcp_mappings_work_in_both_directions_preserve_half_close_and_cleanup",
        "cancelling_an_active_sync_closes_every_owned_rsync_endpoint",
    },
    "context_helpers": {
        "skill_discovery_and_instruction_resolution_preserve_scope_and_provenance",
        "text_helpers_preserve_unicode_binary_compatibility_and_edit_preconditions",
    },
}
IGNORED_GATES = [
    "library-code-mode-ignored",
    *(f"integration-{name}-ignored" for name in INTEGRATION_IGNORED),
]
INTEGRATION_GATES = [f"integration-{name}" for name in INTEGRATION_TESTS]
RUST_TEST_GATES = {"library-private", "library-host", *INTEGRATION_GATES, *IGNORED_GATES}
EXPECTED_GATES = [
    "release-policy", "deployment-policy", "fmt", "library-compile",
    "library-private", "library-host", "clippy", "windows-gnu-clippy", "integration-compile",
    *INTEGRATION_GATES, *IGNORED_GATES, "release", "decoder",
]
INTERRUPTS = (signal.SIGINT, signal.SIGTERM, signal.SIGHUP, signal.SIGQUIT)


def need(condition, description):
    if not condition:
        raise RuntimeError(description)


def sha256(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_json(path, value, *, exclusive=False):
    # The temporary file is on the same filesystem. Only the first writer may
    # claim a run, and readers always see a complete JSON document.
    pending = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=path.parent, prefix=f".{path.name}.",
            delete=False,
        ) as stream:
            pending = Path(stream.name)
            json.dump(value, stream, ensure_ascii=True, indent=2, sort_keys=True)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        if exclusive:
            os.link(pending, path)
        else:
            os.replace(pending, path)
    finally:
        if pending is not None:
            pending.unlink(missing_ok=True)


def interrupt(signum, _frame):
    raise InterruptedError(f"interrupted by {signal.Signals(signum).name}")


def command(args, *, cwd, env, stdin=None, output=None, merge_stderr=False):
    # Terminate the whole launched gate on interruption, including Cargo's
    # children. The launcher owns this process group.
    with subprocess.Popen(
        args, cwd=cwd, env=env, stdin=stdin if stdin is not None else subprocess.DEVNULL,
        stdout=output if output is not None else subprocess.PIPE,
        stderr=subprocess.STDOUT if merge_stderr else subprocess.PIPE,
        start_new_session=True,
    ) as process:
        try:
            out, err = process.communicate()
        except BaseException:
            previous = signal.pthread_sigmask(signal.SIG_BLOCK, INTERRUPTS)
            try:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait()
            finally:
                signal.pthread_sigmask(signal.SIG_SETMASK, previous)
            raise
    return process.returncode, out, err


def git(repo, *args, stdin=None, output=None):
    # Ignore caller-supplied repository/index overrides and forbid lazy fetches
    # and transport access, including from a partial-clone object source.
    env = {key: value for key, value in os.environ.items() if not key.startswith("GIT_")}
    env.update(
        GIT_OPTIONAL_LOCKS="0", GIT_NO_LAZY_FETCH="1", GIT_ALLOW_PROTOCOL="",
        GIT_TERMINAL_PROMPT="0", GIT_NO_REPLACE_OBJECTS="1", TMPDIR=str(ROOT),
    )
    status, result, error = command(
        ["git", "-c", "core.fsmonitor=false", "-C", str(repo), *args],
        cwd=ROOT, env=env, stdin=stdin, output=output,
    )
    detail = error.decode(errors="replace").strip()
    need(status == 0, f"git {' '.join(args)} failed in {repo} ({status}) {detail}")
    return result


def assert_repo_root(repo, *, allow_bare=False):
    if allow_bare and git(repo, "rev-parse", "--is-bare-repository").strip() == b"true":
        root = git(repo, "rev-parse", "--absolute-git-dir")
    else:
        need(git(repo, "rev-parse", "--is-inside-work-tree").strip() == b"true",
             f"{repo} is not a Git worktree")
        root = git(repo, "rev-parse", "--show-toplevel")
    need(Path(os.fsdecode(root.rstrip(b"\n"))).resolve() == repo,
         f"{repo} is not the root of its Git repository or worktree")


def clean_head(worktree, revision):
    assert_repo_root(worktree)
    head = git(worktree, "rev-parse", "--verify", "HEAD").decode("ascii").strip()
    need(head == revision, f"worktree HEAD is {head}, expected {revision}")
    for marker in ("MERGE_HEAD", "rebase-merge", "rebase-apply", "CHERRY_PICK_HEAD",
                   "REVERT_HEAD", "sequencer"):
        raw = git(worktree, "rev-parse", "--path-format=absolute", "--git-path", marker)
        path = Path(os.fsdecode(raw.rstrip(b"\n")))
        need(not os.path.lexists(path), f"worktree has unfinished Git state at {path}")
    masks = git(worktree, "ls-files", "-v", "-z").split(b"\0")
    masked = [os.fsdecode(line[2:]) for line in masks
              if line[:1].islower() or line.startswith(b"S ")]
    need(not masked, f"worktree has assume-unchanged or skip-worktree entries: {masked[:10]!r}")
    changes = git(worktree, "status", "--porcelain=v1", "-z", "--untracked-files=all",
                  "--ignore-submodules=none")
    need(not changes, f"worktree index or files are dirty: {os.fsdecode(changes[:2000])!r}")
    need(git(worktree, "rev-parse", "--verify", "HEAD").strip() == revision.encode("ascii"),
         f"worktree HEAD changed during the cleanliness check: {worktree}")
    return head


def exact_commit(repo, revision):
    need(git(repo, "cat-file", "-t", revision).strip() == b"commit",
         f"{revision} is not a commit object in {repo}")
    resolved = git(repo, "rev-parse", "--verify", revision + "^{commit}").strip()
    need(resolved == revision.encode("ascii"), f"{repo} resolved {revision} as {resolved!r}")


def read_gitlinks(repo, revision):
    links = {}
    for entry in git(repo, "ls-tree", "-r", "-z", "--full-tree", revision).split(b"\0"):
        if entry:
            header, path = entry.split(b"\t", 1)
            mode, kind, oid = header.split()
            if mode == b"160000":
                need(kind == b"commit" and re.fullmatch(rb"[0-9a-f]{40}", oid),
                     f"invalid gitlink entry {entry!r}")
                relative = os.fsdecode(path)
                need(relative not in links, f"duplicate gitlink at {relative}")
                links[relative] = oid.decode("ascii")
    need(links.keys() == GITLINKS,
         f"expected gitlinks {sorted(GITLINKS)}, found {sorted(links)}")
    return links


def make_archive(repo, revision, name):
    exact_commit(repo, revision)
    path = ARCHIVES / (name + ".tar")
    # Use a separate stderr pipe. Git diagnostics must never become tar bytes.
    with path.open("xb") as stream:
        git(repo, "archive", "--format=tar", revision, output=stream)
    with path.open("rb") as stream:
        embedded = git(repo, "get-tar-commit-id", stdin=stream).strip()
    need(embedded == revision.encode("ascii"),
         f"{path} names {embedded!r}, expected {revision}")
    return {"repository": str(repo), "commit": revision, "archive": str(path),
            "sha256": sha256(path)}


def archive_path(name):
    path = PurePosixPath(name)
    need(path.parts and not path.is_absolute() and str(path) == name
         and ".." not in path.parts and ".git" not in (part.lower() for part in path.parts),
         f"unsafe archive path {name!r}")
    return path


def validate_link(path, target):
    link = PurePosixPath(target)
    need(target and not link.is_absolute(), f"unsafe symlink {path} -> {target!r}")
    depth = len(path.parent.parts)
    for part in link.parts:
        depth += -1 if part == ".." else 1
        need(depth >= 0, f"symlink escapes its archive: {path} -> {target!r}")


def unpack(archive, destination, manifest, *, gitlinks=()):
    """Use exclusive file creation and never extract through a symlink."""
    link_paths = set(map(PurePosixPath, gitlinks))
    with tarfile.open(archive, "r:") as tar:
        members = {}
        for entry in tar:
            relative = archive_path(entry.name)
            need(relative not in members, f"duplicate archive path: {relative}")
            need(entry.type in (tarfile.REGTYPE, tarfile.AREGTYPE, tarfile.DIRTYPE,
                                tarfile.SYMTYPE) and entry.sparse is None,
                 f"unsupported tar member at {relative}: {entry.type!r}")
            need(not entry.mode & ~0o777, f"unsupported mode at {relative}: {entry.mode:o}")
            need(not any(parent in link_paths for parent in relative.parents)
                 and (relative not in link_paths or entry.isdir()),
                 f"main archive writes through gitlink: {relative}")
            if entry.issym():
                validate_link(relative, entry.linkname)
            members[relative] = entry
        need(members, f"empty archive: {archive}")
        for relative in members:
            for parent in relative.parents:
                if parent.parts:
                    need(parent in members and members[parent].isdir(),
                         f"archive parent is absent or not a directory: {parent}")

        directories = []
        for relative, entry in sorted(members.items(), key=lambda item: item[0].parts):
            path = destination.joinpath(*relative.parts)
            key = path.relative_to(SOURCE).as_posix()
            need(key not in manifest, f"overlapping source archives at {key}")
            mode = entry.mode
            if entry.isdir():
                path.mkdir(mode=0o700)
                directories.append((path, mode))
                metadata = {"type": "directory", "mode": mode}
            elif entry.issym():
                path.symlink_to(entry.linkname)
                metadata = {"type": "symlink", "link": entry.linkname,
                            "archive_root": str(destination)}
            else:
                digest = hashlib.sha256()
                size = 0
                with tar.extractfile(entry) as reader, path.open("xb") as writer:
                    while chunk := reader.read(1024 * 1024):
                        digest.update(chunk)
                        size += len(chunk)
                        writer.write(chunk)
                need(size == entry.size, f"incomplete archive file: {relative}")
                path.chmod(mode)
                metadata = {"type": "file", "mode": mode, "bytes": size,
                            "sha256": digest.hexdigest()}
            manifest[key] = metadata
        for path, mode in reversed(directories):
            path.chmod(mode)


def check_manifest(manifest):
    need(stat.S_ISDIR(SOURCE.lstat().st_mode), f"source root changed: {SOURCE}")
    for relative, expected in sorted(manifest.items()):
        path = SOURCE / relative
        info = path.lstat()
        kind = expected["type"]
        if kind == "symlink":
            need(stat.S_ISLNK(info.st_mode) and os.readlink(path) == expected["link"],
                 f"archived symlink changed: {relative}")
            # Check chains as well as the relative target of each individual
            # link. Source paths may contain new generated files outside this manifest.
            base = Path(expected["archive_root"])
            need(path.resolve(strict=False).is_relative_to(base),
                 f"archived symlink resolves outside {base}: {relative}")
        else:
            mode = stat.S_IMODE(info.st_mode)
            if kind == "directory":
                need(stat.S_ISDIR(info.st_mode) and mode == expected["mode"],
                     f"archived directory changed: {relative}")
            else:
                need(stat.S_ISREG(info.st_mode) and mode == expected["mode"]
                     and info.st_size == expected["bytes"] and sha256(path) == expected["sha256"],
                     f"archived file changed: {relative}")


def executable_evidence(path):
    path = Path(path)
    need(path.is_absolute() and path.resolve(strict=True).is_relative_to(TARGET.resolve()),
         f"executable outside the shared Cargo target: {path}")
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode) and before.st_size > 0 and os.access(path, os.X_OK),
         f"expected a nonempty regular executable: {path}")
    digest = sha256(path)
    after = path.lstat()
    need((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
         == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
         f"executable changed while hashing: {path}")
    return {"path": str(path), "bytes": before.st_size, "sha256": digest}


def artifacts(text, kind):
    for line in text.splitlines():
        try:
            item = json.loads(line)
        except ValueError:
            continue
        if (isinstance(item, dict) and item.get("reason") == "compiler-artifact"
                and item.get("executable") and kind in item["target"]["kind"]):
            yield item


def metadata_inventory(metadata, source, target):
    manifest = str(source / "Cargo.toml")
    packages = [package for package in metadata["packages"]
                if package["name"] == "ssmcp" and package["manifest_path"] == manifest]
    need(len(packages) == 1 and metadata["workspace_root"] == str(source)
         and metadata["target_directory"] == str(target),
         f"Cargo metadata does not identify the frozen workspace, manifest and target: {manifest}")
    package = packages[0]
    need(package["id"] in metadata["workspace_members"], "ssmcp is not a frozen workspace member")
    tests = [entry for entry in package["targets"] if "test" in entry["kind"]]
    names = {entry["name"] for entry in tests}
    expected = set(INTEGRATION_TESTS)
    need(names == expected and len(tests) == len(expected),
         f"integration target inventory differs: missing={sorted(expected - names)}, "
         f"unexpected={sorted(names - expected)}, duplicates={len(tests) - len(names)}")
    need(all(entry["kind"] == ["test"] and Path(entry["src_path"]).is_relative_to(source)
             for entry in tests), "integration target is not a test of the frozen source")
    client = [entry for entry in package["targets"]
              if entry["name"] == "ssmcp" and entry["kind"] == ["bin"]]
    need(len(client) == 1 and client[0]["src_path"] == str(source / "src/bin/ssmcp.rs"),
         "frozen package has no unique ssmcp bin at src/bin/ssmcp.rs")
    return {"package_id": package["id"], "manifest_path": manifest,
            "workspace_root": str(source), "target_directory": str(target),
            "test_targets": {entry["name"]: entry["src_path"] for entry in tests},
            "client_source": client[0]["src_path"]}


def package_artifact(item, inventory, kind, source, *, test):
    need(item.get("package_id") == inventory["package_id"]
         and item.get("manifest_path") == inventory["manifest_path"]
         and item["target"]["kind"] == [kind] and item["target"]["src_path"] == source
         and item["profile"].get("test") is test and item["executable"] in item["filenames"],
         f"compiler-artifact provenance differs: {item}")


def workspace_helper(text, inventory, target):
    candidates = [item for item in artifacts(text, "bin")
                  if item["target"]["name"] == "ssmcp" and item["profile"].get("test") is False]
    expected = str(target / "debug/ssmcp")
    need(len(candidates) == 1 and candidates[0]["executable"] == expected,
         f"integration compile did not prove CARGO_BIN_EXE_ssmcp at {expected}; "
         f"reported paths={[item['executable'] for item in candidates]}")
    item = candidates[0]
    package_artifact(item, inventory, "bin", inventory["client_source"], test=False)
    return item


def listed_tests(output, description):
    lines = output.decode().splitlines()
    need(all(line.endswith(": test") and line[:-6] for line in lines),
         f"unsupported test listing (expected terse libtest names): {description}")
    names = {line[:-6] for line in lines}
    need(len(names) == len(lines), f"duplicate test names in {description} listing")
    return names


def require_ignored(actual, required, label):
    need(required <= actual, f"{label} missing required ignored tests: {sorted(required - actual)}")


def selection(all_names, ignored, matched, *, ignored_only=False, allow_empty=False):
    need(matched <= all_names and ignored <= all_names, "test inventory contains unknown names")
    if ignored_only:
        need(matched <= ignored, "ignored-only selection includes an ordinary test")
    skipped = set() if ignored_only else matched & ignored
    selected = matched - skipped
    need(selected or (allow_empty and skipped and not ignored_only), "empty required test selection")
    return {
        "selected": sorted(selected), "skipped_ignored": sorted(skipped),
        "expected_result": {"result": "ok", "passed": len(selected), "failed": 0,
                            "ignored": len(skipped), "measured": 0,
                            "filtered": len(all_names - matched)},
    }


def integration_selections(name, all_names, ignored):
    subset = None
    if name in INTEGRATION_IGNORED:
        require_ignored(ignored, INTEGRATION_IGNORED[name], name)
        subset = selection(all_names, ignored, ignored, ignored_only=True)
    ordinary = selection(all_names, ignored, all_names,
                         allow_empty=subset is not None and name in ("workspace_bridge", "context_helpers"))
    if subset is not None:
        ordinary["required_ignored_stage"] = f"integration-{name}-ignored"
    return ordinary, subset


def test_result(line):
    match = re.fullmatch(
        r"test result: (ok|FAILED)\. ([0-9]+) passed; ([0-9]+) failed; ([0-9]+) ignored; "
        r"([0-9]+) measured; ([0-9]+) filtered out(?:; finished in [0-9]+(?:\.[0-9]+)?s)?",
        line)
    if match is None:
        return None
    return dict(zip(("result", "passed", "failed", "ignored", "measured", "filtered"),
                    (match[1], *map(int, match.groups()[1:]))))


def native_file(path):
    if not path.is_file() or not os.access(path, os.X_OK):
        return False
    with path.open("rb") as stream:
        return stream.read(4) == b"\x7fELF"


def resolve_native(name, env):
    # Resolve relative PATH entries in the cwd used by the gate commands.
    search = os.pathsep.join(str(SOURCE / entry)
                             for entry in env.get("PATH", os.defpath).split(os.pathsep))
    override = env.get("SSMCP_NODE") if name == "node" else None
    entry = override if override is not None else shutil.which(name, path=search)
    need(entry and Path(entry).is_absolute(), f"{name} needs an absolute installed entry point")
    path = Path(entry).resolve(strict=True)
    if name == "node" and override is None and (path.name == "mise" or "/mise/shims/" in entry):
        # Like program.rs, use installed mise runtimes without launching the shim.
        root = Path(env["HOME"]) / ".local/share/mise/installs/node"
        versions = sorted((p for p in root.iterdir() if p.is_dir() and not p.name.startswith(".")),
                          key=lambda p: "".join(part.zfill(16) for part in re.split(r"[.\-_]", p.name)),
                          reverse=True)
        candidates = (version / "bin/node"
                      for version in (root / "global", root / "latest", root / "current", *versions))
        path = next((candidate.resolve(strict=True) for candidate in candidates if native_file(candidate)),
                    None)
        need(path is not None, f"no installed native mise Node under {root}")
    if name == "node":
        need(path.name in ("node", "nodejs")
             and not any(marker in str(path) for marker in ("/.volta/bin/", "/.asdf/shims/", "/mise/shims/")),
             f"Node is still a shim or dispatcher: {path}; select the installed native binary")
    need(native_file(path), f"{name} resolved to a non-native entry point: {path}; use a native PATH entry")
    return path


class Gates:
    def __init__(self, args):
        self.args = args
        self.stage = "claim-output"
        self.record = {
            "run_id": secrets.token_hex(16), "source_revision": args.source_sha,
            "status": "running", "started_at": time.time(), "checks": [],
            "root_worktree": str(args.worktree), "root_worktree_head": {},
            "template": str(TEMPLATE), "template_sha256": TEMPLATE_SHA256,
        }
        self.env = os.environ.copy()
        self.env.update(
            CARGO_HOME=str(CARGO_HOME), CARGO_TARGET_DIR=str(TARGET), CARGO_BUILD_JOBS="1",
            CARGO_INCREMENTAL="0", CARGO_PROFILE_TEST_DEBUG="0", CARGO_PROFILE_DEV_DEBUG="0",
            TMPDIR=str(ROOT / "cargo-tmp"), SSMCP_CODE_MODE_RUNNER=str(RUNNER),
        )
        self.env.pop("SSMCP_OUTPUT_RELOAD", None)
        self.env.pop("CARGO_BUILD_TARGET", None)
        self.manifest = {}

    def save(self):
        need(self.owns_receipt(), f"run no longer owns {RECEIPT}")
        write_json(RECEIPT, self.record)

    def claim(self):
        need(Path(__file__).resolve(strict=True) == ROOT / "run_gates.py",
             f"invoke the owned launcher at {ROOT / 'run_gates.py'}")
        need(ROOT.resolve(strict=True) == ROOT, f"output directory is a symlink: {ROOT}")
        earlier = sorted(path.name for path in ROOT.iterdir()
                         if path.name not in ("run_gates.py", "preparation.json"))
        need(not earlier, f"refusing an existing run in {ROOT}: {', '.join(earlier)}")
        write_json(RECEIPT, self.record, exclusive=True)

    def owns_receipt(self):
        try:
            return json.loads(RECEIPT.read_bytes()).get("run_id") == self.record["run_id"]
        except (OSError, ValueError, AttributeError):
            return False

    def export(self):
        self.stage = "preflight"
        self.script = Path(__file__).resolve(strict=True)
        self.record["script_sha256"] = sha256(self.script)
        need(sha256(TEMPLATE) == TEMPLATE_SHA256, f"template bytes changed: {TEMPLATE}")
        self.worktree = self.args.worktree.resolve(strict=True)
        self.record["root_worktree"] = str(self.worktree)
        self.record["root_worktree_head"]["before_export"] = clean_head(
            self.worktree, self.args.source_sha)
        need(CARGO_HOME.is_dir() and TARGET.is_dir(), "the pinned Cargo cache paths must exist")
        self.save()

        self.stage = "export"
        links = read_gitlinks(self.worktree, self.args.source_sha)
        object_root = self.args.submodule_root.resolve(strict=True)
        repositories = {}
        for relative, oid in sorted(links.items()):
            repo = (object_root / Path(relative).name).resolve(strict=True)
            assert_repo_root(repo, allow_bare=True)
            exact_commit(repo, oid)
            repositories[relative] = repo
        for directory in (SOURCE, ARCHIVES, ROOT / "logs", ROOT / "cargo-tmp",
                          ROOT / "candidate-test-tmp"):
            directory.mkdir(mode=0o700)

        main = make_archive(self.worktree, self.args.source_sha, "main")
        provenance = {"main": main, "gitlinks": {}}
        self.record["source_archives"] = provenance
        unpack(main["archive"], SOURCE, self.manifest, gitlinks=links)
        for relative, oid in sorted(links.items()):
            self.stage = f"export:{relative}"
            location = SOURCE / relative
            need(location.is_dir() and not location.is_symlink() and not any(location.iterdir()),
                 f"main archive did not leave a fresh gitlink directory: {relative}")
            exported = make_archive(repositories[relative], oid, location.name)
            provenance["gitlinks"][relative] = exported
            unpack(exported["archive"], location, self.manifest)

        self.stage = "verify-export"
        check_manifest(self.manifest)
        write_json(MANIFEST, self.manifest, exclusive=True)
        self.record["source_manifest"] = {
            "path": str(MANIFEST), "entries": len(self.manifest), "sha256": sha256(MANIFEST),
        }
        self.record["root_worktree_head"]["after_export"] = clean_head(
            self.worktree, self.args.source_sha)
        self.save()

    def probe(self, name, args, *, env=None):
        self.stage = name
        status, output, error = command(args, cwd=SOURCE, env=self.env if env is None else env)
        log = ROOT / "logs" / f"probe-{name}"
        paths = {channel: log.with_suffix(f".{channel}") for channel in ("stdout", "stderr")}
        for channel, data in (("stdout", output), ("stderr", error)):
            with paths[channel].open("xb") as stream:
                stream.write(data)
        self.record.setdefault("probes", {})[name] = {
            "command": args, "cwd": str(SOURCE), "exit_code": status,
            **{channel: str(path) for channel, path in paths.items()},
        }
        self.save()
        need(status == 0, f"{name} exited {status}: {error.decode(errors='replace').strip()}")
        return output

    def preflight_metadata(self):
        output = self.probe("cargo-metadata", [
            "cargo", "metadata", "--offline", "--locked", "--no-deps", "--format-version", "1",
            "--manifest-path", str(SOURCE / "Cargo.toml"),
        ])
        self.stage = "cargo-metadata-inventory"
        self.record["cargo_metadata"] = metadata_inventory(json.loads(output), SOURCE, TARGET)
        self.save()

    def runner_evidence(self):
        expected = self.manifest.get("src/code_mode.js", {})
        need(expected.get("type") == "file" and RUNNER.resolve(strict=True) == RUNNER
             and stat.S_ISREG(RUNNER.lstat().st_mode)
             and self.env["SSMCP_CODE_MODE_RUNNER"] == str(RUNNER),
             "code-mode runner is not the frozen source file")
        digest = sha256(RUNNER)
        need(digest == expected["sha256"], "frozen code-mode runner bytes changed")
        return {"path": str(RUNNER), "sha256": digest}

    def prepare_runtime(self):
        self.stage = "resolve-native-tools"
        paths = {name: resolve_native(name, self.env) for name in (*NATIVE_TOOLS, *DESKTOP_TOOLS)}
        need(paths["bwrap"] == BWRAP.resolve(strict=True),
             f"PATH bwrap and gate launcher differ: {paths['bwrap']} vs {BWRAP}")
        NATIVE_BIN.mkdir(mode=0o700)
        for name, path in paths.items():
            (NATIVE_BIN / name).symlink_to(path)
        self.env["PATH"] = str(NATIVE_BIN) + os.pathsep + self.env.get("PATH", os.defpath)
        self.env["SSMCP_NODE"] = str(paths["node"])
        self.record["runtime_bindings"] = {
            "path_prefix": str(NATIVE_BIN), "node": self.env["SSMCP_NODE"],
            "outer_bwrap": str(BWRAP), "runner": self.runner_evidence(),
        }
        self.record["runtime_tools"] = self.runtime_evidence(paths, "before")
        self.save()

    def runtime_evidence(self, paths, phase):
        evidence = {}
        # A version probe must not load ambient Node preload modules.
        env = {key: value for key, value in self.env.items() if key not in ("NODE_OPTIONS", "NODE_PATH")}
        for name, path in paths.items():
            entry = NATIVE_BIN / name
            need(shutil.which(name, path=self.env["PATH"]) == str(entry)
                 and entry.is_symlink() and entry.resolve(strict=True) == path and native_file(path),
                 f"controlled PATH does not select recorded {name}: {path}")
            if name == "bwrap":
                need(BWRAP.resolve(strict=True) == path, "outer bwrap no longer matches PATH bwrap")
            if name == "node":
                need(self.env["SSMCP_NODE"] == str(path), "SSMCP_NODE differs from recorded Node")
            before = sha256(path)
            if name in DESKTOP_TOOLS:
                need(entry.resolve(strict=True) == path and native_file(path) and sha256(path) == before,
                     f"unstable desktop tool entry: {path}")
                evidence[name] = {"path": str(path), "sha256": before, "path_entry": str(entry)}
                continue
            output = self.probe(f"version-{phase}-{name}", [str(path), "--version"], env=env)
            version = output.decode().strip()
            need(version and (name != "node" or re.fullmatch(r"v[0-9]+\.[0-9]+\.[0-9]+(?:[-+].+)?", version))
                 and entry.resolve(strict=True) == path and sha256(path) == before,
                 f"invalid or unstable native {name} entry: {path}")
            evidence[name] = {"path": str(path), "sha256": before, "version": version}
        return evidence

    def run(self, name, args, env=None, *, test_plan=None):
        self.stage = name
        log = ROOT / "logs" / f"candidate2-{name}.log"
        print(json.dumps({"started": name, "command": args}), flush=True)
        start = time.monotonic()
        with log.open("xb") as stream:
            status, _, _ = command(
                args, cwd=SOURCE, env=env or self.env, output=stream, merge_stderr=True)
        text = log.read_text(errors="replace")
        lines = text.splitlines()
        row = {"name": name, "command": args, "exit_code": status,
               "seconds": round(time.monotonic() - start, 2), "log": str(log),
               "tail": lines[-12:]}
        if test_plan is not None:
            row["test_selection"] = test_plan
            while lines and not lines[-1].strip():
                lines.pop()
            final = lines[-1] if lines else ""
            children = [
                {"line_number": number, "raw_line": line, "parsed": test_result(line)}
                for number, line in enumerate(lines[:-1], 1)
                if line.lstrip().startswith("test result:")
            ]
            row["test_child_summaries"] = children
            try:
                observed = test_result(final)
                need(observed is not None,
                     f"last nonempty line is not a complete libtest result: {final!r}")
                row["test_results"] = [observed]
                need(observed == test_plan["expected_result"],
                     f"expected {test_plan['expected_result']}, got {observed}")
                duplicates = [child["line_number"] for child in children if child["parsed"] == observed]
                need(not duplicates, f"duplicate parent libtest result at line(s) {duplicates}")
            except RuntimeError as error:
                row["test_validation_error"] = str(error)
        self.record["checks"].append(row)
        self.save()
        print(json.dumps({"completed": name, "exit_code": status,
                          "seconds": row["seconds"], "test_results": row.get("test_results")}),
              flush=True)
        need(status == 0, f"{name} exited {status}, log: {log}\n" + "\n".join(row["tail"]))
        need("test_validation_error" not in row,
             f"{name} did not run its enumerated selection: {row.get('test_validation_error')}; log: {log}")
        return text

    def list_tests(self, label, args):
        invocation = [*args, "--list", "--format", "terse"]
        return listed_tests(self.probe(f"list-{label}", invocation), label)

    def run_rust(self, name, args, artifact, plan, *, env=None, helper=None):
        self.stage = f"verify-{name}"
        need(executable_evidence(artifact["path"]) == artifact, f"{name} executable changed before run")
        self.runner_evidence()
        if helper is not None:
            before = executable_evidence(helper["path"])
            need(before == helper, f"workspace_bridge helper changed before {name}")
            proof = self.record.setdefault("workspace_bridge_helper_checks", {}).setdefault(name, {})
            proof["before"] = before
        try:
            self.run(name, args, env, test_plan=plan)
        finally:
            need(executable_evidence(artifact["path"]) == artifact, f"{name} executable changed during run")
            self.runner_evidence()
            if helper is not None:
                after = executable_evidence(helper["path"])
                proof["after"] = after
                self.save()
                need(after == helper, f"workspace_bridge helper changed during {name}")

    def plan_integration(self, name, binary):
        args = [binary, "--test-threads=4"]
        ignored_args = [binary, "--ignored", "--test-threads=1"]
        all_tests = self.list_tests(f"integration-{name}-all", args)
        ignored_tests = self.list_tests(f"integration-{name}-ignored", ignored_args)
        self.stage = f"integration-{name}-inventory"
        if name == "zuse_worker_entry":
            required = {ZUSE_WORKER_TEST}
            need(all_tests == ignored_tests == required,
                 f"{name} requires exactly the reviewed ignored test {ZUSE_WORKER_TEST}: "
                 f"all={sorted(all_tests)}, ignored={sorted(ignored_tests)}")
            args = [binary, "--ignored", "--exact", ZUSE_WORKER_TEST, "--test-threads=1"]
            plan = selection(all_tests, ignored_tests, required, ignored_only=True)
            plan["execution_mode"] = "ignored-exact"
            ordinary_selected, ignored_selected = [], plan["selected"]
            subset = None
        else:
            plan, subset = integration_selections(name, all_tests, ignored_tests)
            ordinary_selected = plan["selected"]
            ignored_selected = subset["selected"] if subset is not None else []
        self.record["integration_test_names"][name] = {
            "all": sorted(all_tests), "ignored": sorted(ignored_tests),
            "ordinary_selected": ordinary_selected, "ignored_selected": ignored_selected,
            "ignored_not_executed": sorted(ignored_tests - set(ignored_selected)),
            "execution_mode": plan.get("execution_mode", "ordinary"),
        }
        self.save()
        return (args, plan), (ignored_args, subset) if subset is not None else None

    def verify_desktop_tools(self, phase):
        expected = {name: self.record["runtime_tools"][name] for name in DESKTOP_TOOLS}
        observed = self.runtime_evidence(
            {name: Path(item["path"]) for name, item in expected.items()}, phase)
        self.record.setdefault("zuse_desktop_tools", {})[phase] = observed
        self.save()
        need(observed == expected, f"desktop tool provenance changed {phase} zuse_worker_entry")

    def run_primary_integration(self, name, args, artifact, plan, *, helper=None):
        stage = f"integration-{name}"
        env = None
        if name == "server_runtime":
            # The negative fixture clears PATH in its child to test Node discovery.
            env = self.env.copy()
            env.pop("SSMCP_NODE", None)
            self.record.setdefault("test_environment_exceptions", {})[stage] = {
                "unset": ["SSMCP_NODE"],
                "reason": "The dependency-failure fixture must discover Node through its empty PATH.",
            }
            self.save()
        if name == "zuse_worker_entry":
            self.stage = stage
            self.verify_desktop_tools("before")
        try:
            self.run_rust(stage, args, artifact, plan, env=env, helper=helper)
        finally:
            if name == "zuse_worker_entry":
                self.verify_desktop_tools("after")

    def optimized_artifacts(self, text, kind, expected):
        selected = [item for item in artifacts(text, kind)
                    if item["target"]["name"] in expected]
        found = [item["target"]["name"] for item in selected]
        need(len(found) == len(expected) and set(found) == set(expected),
             f"expected exactly the optimized artifacts {expected}, found {found}")
        evidence = {}
        provenance = self.record.setdefault("optimized_build_artifacts", {})
        for item in selected:
            name = item["target"]["name"]
            source = Path(item["target"]["src_path"]).resolve(strict=True)
            profile = item.get("profile", {})
            need(source.is_relative_to(SOURCE.resolve(strict=True)),
                 f"{name} was not compiled from the fixed source: {source}")
            need(profile.get("test") is False
                 and str(profile.get("opt_level")) in ("1", "2", "3", "s", "z"),
                 f"{name} is not a non-test optimized artifact: {profile}")
            evidence[name] = executable_evidence(item["executable"])
            provenance[name] = {
                "source_path": str(source), "package_id": item.get("package_id"),
                "profile": profile, "executable": item["executable"],
            }
        return evidence

    def gates(self):
        self.prepare_runtime()
        self.preflight_metadata()
        self.run("release-policy", ["python3", "-m", "unittest", "discover", "-s", "scripts",
                                    "-p", "test_release.py", "-v"])
        self.run("deployment-policy", ["python3", "-W", "error", "-m", "unittest", "discover",
                                       "-s", "scripts", "-p", "test_server_deploy.py", "-v"])
        self.run("fmt", ["cargo", "fmt", "--all", "--", "--check"])
        text = self.run("library-compile", ["cargo", "test", "--offline", "--locked", "--lib",
                                         "--no-run", "--message-format=json", "--jobs", "1"])
        self.stage = "library-artifact"
        libs = [item for item in artifacts(text, "lib")
                if item["target"]["name"] == "ssmcp" and item["profile"]["test"]]
        need(len(libs) == 1, f"expected one ssmcp test library, found {len(libs)}")
        binary = libs[0]["executable"]
        lib = executable_evidence(binary)
        self.record.update(library_binary=binary, library_sha256=lib["sha256"],
                           library_artifact=lib)

        # The template gives tests a private /tmp. The dev-bind preserves
        # access to the host filesystem everywhere else.
        tmp = ROOT / "candidate-test-tmp"
        prefix = [str(BWRAP), "--unshare-user", "--uid", "1000", "--gid", "1000",
                  "--dev-bind", "/", "/", "--bind", str(tmp), "/tmp", "--unsetenv",
                  "SSMCP_OUTPUT_RELOAD", "--setenv", "TMPDIR", "/tmp", "--chdir", str(SOURCE)]
        private_args = [binary, "--exact", "--test-threads=4"]
        for name in HOST_TESTS:
            private_args += ["--skip", name]
        host_args = [binary, "--exact", "--test-threads=1"] + HOST_TESTS
        all_names = self.list_tests("library-all", [binary])
        all_ignored = self.list_tests("library-ignored", [binary, "--ignored"])
        private_names = self.list_tests("library-private", private_args)
        host_names = self.list_tests("library-host", host_args)
        self.stage = "library-partition"
        need(all_names and private_names and not private_names & host_names
             and private_names | host_names == all_names and host_names == set(HOST_TESTS),
             "library partition must be complete, disjoint and have the four exact host tests")
        need(not host_names & all_ignored, "all four exact host tests must be ordinary tests")
        private_plan = selection(all_names, all_ignored, private_names)
        host_plan = selection(all_names, all_ignored, host_names)
        code_mode = {name for name in all_ignored if name.startswith("code_mode::tests::")}
        require_ignored(code_mode, CODE_MODE_IGNORED, "library code_mode")
        code_mode_args = [binary, "--ignored", "--exact", "--test-threads=1", *sorted(code_mode)]
        selected_code_mode = self.list_tests("library-code-mode-selection", code_mode_args)
        need(selected_code_mode == code_mode, "exact code-mode ignored selection differs from inventory")
        code_mode_plan = selection(all_names, all_ignored, selected_code_mode, ignored_only=True)
        self.record["library_partition"] = {
            "total": len(all_names), "private": len(private_names), "host": len(host_names),
            "disjoint": True, "complete": True,
        }
        self.record["library_test_names"] = {
            "all": sorted(all_names), "private": sorted(private_names), "host": sorted(host_names),
            "ignored": sorted(all_ignored), "private_selected": private_plan["selected"],
            "host_selected": host_plan["selected"], "ignored_code_mode": code_mode_plan["selected"],
            "ignored_not_executed": sorted(all_ignored - code_mode),
        }
        self.save()
        self.run_rust("library-private", prefix + private_args, lib, private_plan)
        host_env = self.env.copy()
        host_env["TMPDIR"] = "/tmp"
        self.run_rust("library-host", host_args, lib, host_plan, env=host_env)
        self.run("clippy", ["cargo", "clippy", "--offline", "--locked", "--workspace",
                            "--all-targets", "--jobs", "1", "--", "-D", "warnings"])
        self.run("windows-gnu-clippy", ["cargo", "clippy", "--offline", "--locked", "--target",
                                       "x86_64-pc-windows-gnu", "--workspace", "--all-targets",
                                       "--jobs", "1", "--", "-D", "warnings"])

        compile_args = ["cargo", "test", "--offline", "--locked", "--package", "ssmcp",
                        "--no-run", "--message-format=json", "--jobs", "1"]
        for name in INTEGRATION_TESTS:
            compile_args += ["--test", name]
        text = self.run("integration-compile", compile_args)
        self.stage = "integration-artifacts"
        compiled = list(artifacts(text, "test"))
        built = {item["target"]["name"]: item["executable"] for item in compiled}
        need(len(compiled) == len(INTEGRATION_TESTS) and built.keys() == set(INTEGRATION_TESTS),
             f"expected one executable per integration target, found {sorted(built)} "
             f"in {len(compiled)} artifacts")
        inventory = self.record["cargo_metadata"]
        for item in compiled:
            name = item["target"]["name"]
            package_artifact(item, inventory, "test", inventory["test_targets"][name], test=True)
        self.record["integration_binaries"] = built
        integration = {name: executable_evidence(path) for name, path in built.items()}
        self.record["integration_artifacts"] = integration
        item = workspace_helper(text, inventory, TARGET)
        helper = executable_evidence(item["executable"])
        self.record["workspace_bridge_helper"] = {
            "artifact": helper, "compiler_artifact": item,
            "source_stage": "integration-compile",
        }
        self.save()

        self.record["integration_test_names"] = {}
        primary_plans = {}
        ignored_plans = {}
        for name in INTEGRATION_TESTS:
            primary_plans[name], ignored_only = self.plan_integration(name, built[name])
            if ignored_only is not None:
                ignored_plans[name] = ignored_only
        for name, (args, plan) in primary_plans.items():
            self.run_primary_integration(name, prefix + args, integration[name], plan,
                                         helper=helper if name == "workspace_bridge" else None)
        self.run_rust("library-code-mode-ignored", prefix + code_mode_args, lib, code_mode_plan)
        for name in INTEGRATION_IGNORED:
            args, plan = ignored_plans[name]
            self.run_rust(f"integration-{name}-ignored", prefix + args, integration[name], plan,
                          helper=helper if name == "workspace_bridge" else None)

        text = self.run("release", ["cargo", "build", "--offline", "--locked", "--release",
                                    "--message-format=json", "--bins", "--jobs", "1"])
        self.stage = "release-artifacts"
        binaries = self.optimized_artifacts(
            text, "bin", ("ssmcp", "ssmcpd", "ssmcp-frontend"))
        self.record["binaries"] = binaries
        self.save()
        text = self.run("decoder", ["cargo", "build", "--offline", "--locked", "--release",
                                    "--message-format=json", "--example", "vt_snapshot",
                                    "--jobs", "1"])
        self.stage = "decoder-artifact"
        binaries.update(self.optimized_artifacts(text, "example", ("vt_snapshot",)))
        self.save()

    def finish(self):
        self.stage = "final-verification"
        checks = self.record["checks"]
        need([row["name"] for row in checks] == EXPECTED_GATES
             and all(row["exit_code"] == 0 for row in checks), "gate inventory did not all pass")
        need({row["name"] for row in checks if "test_selection" in row} == RUST_TEST_GATES
             and all(row.get("test_results") == [row["test_selection"]["expected_result"]]
                     and "test_validation_error" not in row
                     for row in checks if "test_selection" in row),
             "a Rust stage lacks proof of its enumerated selection")
        tools = self.record["runtime_tools"]
        self.record["runtime_tools_final"] = self.runtime_evidence(
            {name: Path(item["path"]) for name, item in tools.items()}, "after")
        self.stage = "final-verification"
        need(self.record["runtime_tools_final"] == tools, "native tool provenance changed during gates")
        self.record["code_mode_runner_final"] = self.runner_evidence()
        need(self.record["code_mode_runner_final"] == self.record["runtime_bindings"]["runner"],
             "code-mode runner provenance changed during gates")
        check_manifest(self.manifest)
        need(sha256(MANIFEST) == self.record["source_manifest"]["sha256"]
             and sha256(self.script) == self.record["script_sha256"]
             and sha256(TEMPLATE) == self.record["template_sha256"], "provenance files changed")
        archives = self.record["source_archives"]
        for archive in (archives["main"], *archives["gitlinks"].values()):
            need(sha256(Path(archive["archive"])) == archive["sha256"],
                 f"archive changed during gates: {archive['archive']}")
        for artifact in (self.record["library_artifact"], self.record["workspace_bridge_helper"]["artifact"],
                         *self.record["integration_artifacts"].values(),
                         *self.record["binaries"].values()):
            need(executable_evidence(artifact["path"]) == artifact,
                 f"executable changed during gates: {artifact['path']}")
        self.record["root_worktree_head"]["final"] = clean_head(self.worktree, self.args.source_sha)
        self.record.update(status="passed", finished_at=time.time())
        self.save()
        print(json.dumps({"status": "passed", "source_revision": self.args.source_sha,
                          "receipt": str(RECEIPT), "library_binary": self.record["library_binary"],
                          "binaries": self.record["binaries"]}), flush=True)


def source_sha(value):
    if not re.fullmatch(r"[0-9a-fA-F]{40}", value):
        raise argparse.ArgumentTypeError("source SHA must be exactly 40 hexadecimal digits")
    return value.lower()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source_sha", type=source_sha, metavar="FINAL_SHA")
    parser.add_argument("--worktree", type=Path, default=DEFAULT_WORKTREE,
                        help=f"clean candidate worktree (default: {DEFAULT_WORKTREE})")
    parser.add_argument("--submodule-root", type=Path, default=DEFAULT_SUBMODULE_ROOT,
                        help=f"directory of Git object repositories (default: {DEFAULT_SUBMODULE_ROOT})")
    args = parser.parse_args()
    gates = Gates(args)
    for signum in INTERRUPTS:
        signal.signal(signum, interrupt)
    try:
        gates.claim()
        gates.export()
        gates.gates()
        gates.finish()
    except BaseException as error:
        for signum in INTERRUPTS:
            signal.signal(signum, signal.SIG_IGN)
        detail = f"{type(error).__name__}: {error}"
        if gates.owns_receipt():
            gates.record.update(status="failed", finished_at=time.time(),
                                failed_stage=gates.stage, error=detail)
            try:
                gates.save()
            except Exception as report_error:
                print(f"could not save failure receipt: {report_error}", file=sys.stderr)
        print(f"{gates.stage}: {detail}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
