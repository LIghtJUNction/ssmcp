"""Launch the reviewed Gate 8 once, with the existing build wrapper bound explicitly."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

BASE = Path('/var/tmp/ssmcp-convergence-verification-20261120')
ROOT = BASE / 'release21-final-8-r3'
OUT = BASE / 'release21-final-8-r3-launch'
DRIVER = ROOT / 'run_gates.py'
CACHE = BASE / 'release21-final8-cargo-home-r2'
TARGET = Path('/var/tmp/ssmcp-message-references-20261120/target-final8')
OBJECTS = BASE / 'release21-gate8-inputs-ec91-20261120-r2/submodule-root'
WRAPPER = Path('/home/lightjunction/.cargo/rustc-serial')
EXPECTED = {
    'driver': '1ad9ec768988aa8aeba23ffbd97ce565908f88d6c64d3a14ebb64049c5bc782d',
    'wrapper': '8b61096a9869fc6e790c963715efded612b17583cee90c830aadda2da8917a43',
    'cargo_config': '822715c915751e3ef1e6711a6716e7bc9e08845550337416568a1c80e7429ccd',
    'cargo_lock': '09e852ddcdf27460b682ae75dbdf49f3ef783657bdff6de0015f3d81d8142e8e',
}


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(name, data):
    with (OUT / name).open('x') as stream:
        json.dump(data, stream, indent=2, sort_keys=True)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def git(worktree, *args):
    result = subprocess.run(['git', '-C', str(worktree), *args], capture_output=True,
                            text=True, timeout=30, check=True)
    return result.stdout.strip()


def main():
    os.umask(0o022)
    sha, raw_worktree = sys.argv[1:]
    assert re.fullmatch('[0-9a-f]{40}', sha), 'expected an exact source SHA'
    worktree = Path(raw_worktree).resolve(strict=True)
    assert OUT.resolve(strict=True) == OUT
    save('claim.json', {'source_revision': sha, 'claimed_at': time.time(), 'pid': os.getpid()})
    lock_fd = os.open(BASE / 'final8-cargo-owner.lock',
                      os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    record = {'source_revision': sha, 'worktree': str(worktree), 'started_at': time.time()}
    status = 1
    try:
        assert set(p.name for p in ROOT.iterdir()) <= {'run_gates.py', 'preparation.json'}, 'gate root already used'
        assert git(worktree, 'rev-parse', 'HEAD') == sha
        assert git(worktree, 'status', '--porcelain=v1') == '', 'candidate worktree is not clean'
        assert CACHE.is_dir() and TARGET.is_dir() and OBJECTS.is_dir()
        configs = [p for p in (CACHE / 'config.toml', CACHE / 'config') if p.is_file()]
        assert len(configs) == 1, 'private Cargo configuration is ambiguous'
        files = {'driver': DRIVER, 'wrapper': WRAPPER, 'cargo_config': configs[0],
                 'cargo_lock': worktree / 'Cargo.lock'}
        before = {name: digest(path) for name, path in files.items()}
        assert before == EXPECTED, 'a reviewed input changed'
        env = os.environ.copy()
        env.update(RUSTC_WRAPPER=str(WRAPPER), CARGO_BUILD_JOBS='1',
                   CARGO_HOME=str(CACHE), CARGO_TARGET_DIR=str(TARGET))
        versions = {}
        for tool in ('cargo', 'rustc'):
            probe = subprocess.run([tool, '--version'], env=env, capture_output=True,
                                   text=True, timeout=30, check=True)
            versions[tool] = probe.stdout.strip()
        command = ['/usr/bin/python3', '-u', str(DRIVER), sha,
                   '--worktree', str(worktree), '--submodule-root', str(OBJECTS)]
        record.update(command=command, input_paths={k: str(v) for k, v in files.items()},
                      hashes_before=before, launcher_sha256=digest(Path(__file__)),
                      environment={k: env[k] for k in ('RUSTC_WRAPPER', 'CARGO_BUILD_JOBS',
                                                       'CARGO_HOME', 'CARGO_TARGET_DIR')},
                      versions=versions, umask='0022',
                      invocation_id=env.get('INVOCATION_ID'), exclusive_target_lock=True)
        save('launch.json', record)
        with (OUT / 'stdout.log').open('xb') as stdout, (OUT / 'stderr.log').open('xb') as stderr:
            result = subprocess.run(command, cwd=worktree, env=env, stdin=subprocess.DEVNULL,
                                    stdout=stdout, stderr=stderr)
        after = {name: digest(path) for name, path in files.items()}
        gate = json.loads((ROOT / 'candidate-gates.json').read_text())
        record.update(exit_code=result.returncode, hashes_after=after,
                      gate_status=gate.get('status'), gate_run_id=gate.get('run_id'),
                      gate_receipt_sha256=digest(ROOT / 'candidate-gates.json'),
                      worktree_head_after=git(worktree, 'rev-parse', 'HEAD'),
                      worktree_status_after=git(worktree, 'status', '--porcelain=v1'))
        assert after == before, 'a bound input changed during the gate'
        assert record['worktree_head_after'] == sha and not record['worktree_status_after']
        assert gate.get('source_revision') == sha
        assert result.returncode == 0 and gate.get('status') == 'passed', 'gate did not pass'
        status = 0
    except Exception as error:
        record['launcher_error'] = type(error).__name__ + ': ' + str(error)
    finally:
        record.update(status='passed' if status == 0 else 'failed', finished_at=time.time())
        save('exit.json', record)
        os.close(lock_fd)
    return status


if __name__ == '__main__':
    raise SystemExit(main())
