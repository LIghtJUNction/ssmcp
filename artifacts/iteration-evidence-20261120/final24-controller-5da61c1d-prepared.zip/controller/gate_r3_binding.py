"""Read and bind the accepted r3 gate evidence; never run build or test commands.

The inventory module is separately reviewed and hash-pinned by the caller.
Source/archive reconstruction belongs to the caller, as in the existing P1
and UI controllers. Raw gate logs have no producer hash field: this reader
captures their observed hashes and callers must preserve/recheck those bytes.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path
import re
import stat
import types

DRIVER_SHA256 = "1ad9ec768988aa8aeba23ffbd97ce565908f88d6c64d3a14ebb64049c5bc782d"
TEMPLATE_SHA256 = "39b1231de0cac1ffbc2f064fc12f08669273876fd655295965f979ea911fceb5"
RUST_WRAPPER_SHA256 = "8b61096a9869fc6e790c963715efded612b17583cee90c830aadda2da8917a43"
LAUNCHER_SHA256 = "99b78f15e4be1a0653289897a255f2cfdb2d92f547c67b1f5cec11769f73f833"
GATE_BASE = Path("/var/tmp/ssmcp-convergence-verification-20261120")
GATE_ROOT = GATE_BASE / "release21-final-8-r3"
LAUNCH_ROOT = GATE_BASE / "release21-final-8-r3-launch"
CARGO_HOME = GATE_BASE / "release21-final8-cargo-home-r2"
CARGO_TARGET = Path("/var/tmp/ssmcp-message-references-20261120/target-final8")
OBJECT_ROOT = GATE_BASE / "release21-gate8-inputs-ec91-20261120-r2/submodule-root"
RUST_WRAPPER = Path("/home/lightjunction/.cargo/rustc-serial")
LAUNCH_HASHES = {
    "driver": DRIVER_SHA256, "wrapper": RUST_WRAPPER_SHA256,
    "cargo_config": "822715c915751e3ef1e6711a6716e7bc9e08845550337416568a1c80e7429ccd",
    "cargo_lock": "09e852ddcdf27460b682ae75dbdf49f3ef783657bdff6de0015f3d81d8142e8e",
}
NATIVE_TOOLS = ("node", "bwrap", "prlimit", "rsync")
DESKTOP_TOOLS = ("Xvfb", "xdotool", "magick", "xprop", "dbus-run-session", "dbus-daemon")
MAX_FILE_BYTES = 256 * 1024 * 1024


def require(value, message):
    if not value:
        raise ValueError(message)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "duplicate JSON key")
        result[key] = value
    return result


def same_json(left, right):
    return json.dumps(left, sort_keys=True, separators=(",", ":")) == json.dumps(right, sort_keys=True, separators=(",", ":"))


class Evidence:
    def __init__(self):
        self.files = {}
        self.content_files = {}

    def read(self, path, expected=None):
        path = Path(path)
        require(path.is_absolute(), f"evidence path must be absolute: {path}")
        before = path.lstat()
        require(stat.S_ISREG(before.st_mode) and before.st_size <= MAX_FILE_BYTES,
                f"evidence is not a bounded regular file: {path}")
        data = path.read_bytes()
        after = path.lstat()
        identity = lambda info: (info.st_dev, info.st_ino, info.st_mode, info.st_size,
                                 info.st_mtime_ns, info.st_ctime_ns)
        require(identity(before) == identity(after) and len(data) == before.st_size,
                f"evidence changed while reading: {path}")
        digest = hashlib.sha256(data).hexdigest()
        if expected is not None:
            require(isinstance(expected, str) and re.fullmatch(r"[0-9a-f]{64}", expected)
                    and digest == expected, f"evidence hash differs: {path}")
        require(str(path) not in self.files or self.files[str(path)] == digest,
                f"evidence changed between reads: {path}")
        self.files[str(path)] = digest
        self.content_files[str(path)] = digest
        return data

    def json(self, path, expected=None):
        return json.loads(self.read(path, expected), object_pairs_hook=unique_object)

    def artifact(self, entry, label, *, executable=False):
        require(isinstance(entry, dict), f"missing {label} artifact")
        path = Path(entry.get("path", ""))
        expected = entry.get("sha256")
        require(path.is_absolute() and isinstance(expected, str)
                and re.fullmatch(r"[0-9a-f]{64}", expected), f"missing {label} path/hash")
        before = path.lstat()
        require(stat.S_ISREG(before.st_mode), f"{label} is not a regular file")
        with path.open("rb") as stream:
            opened = os.fstat(stream.fileno())
            require((before.st_dev, before.st_ino, before.st_size)
                    == (opened.st_dev, opened.st_ino, opened.st_size), f"{label} changed while opening")
            digest = hashlib.file_digest(stream, "sha256").hexdigest()
        after = path.lstat()
        require((before.st_dev, before.st_ino, before.st_mode, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
                == (after.st_dev, after.st_ino, after.st_mode, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
                and digest == expected, f"{label} changed or has another hash")
        require(str(path) not in self.files or self.files[str(path)] == digest,
                f"{label} changed between observations")
        self.files[str(path)] = digest
        if "bytes" in entry:
            require(type(entry["bytes"]) is int and entry["bytes"] == before.st_size,
                    f"wrong {label} byte length")
        if executable:
            require(before.st_size > 0 and os.access(path, os.X_OK), f"{label} is not executable")
        return {"path": str(path), "sha256": digest, "bytes": before.st_size}


def load_inventory(evidence, path, expected):
    raw = evidence.read(path, expected)
    module = types.ModuleType("ssmcp_reviewed_r3_inventory")
    module.__file__ = str(path)
    exec(compile(raw, str(path), "exec"), module.__dict__)
    require(module.DRIVER_BASELINE_SHA256 == DRIVER_SHA256,
            "inventory module is not for the accepted r3 driver")
    require(callable(module.validate_inventory) and callable(module.parent_result),
            "inventory module lacks the reviewed raw-parent contract")
    return module


def listed_names(raw, label):
    lines = raw.decode("utf-8").splitlines()
    require(all(line.endswith(": test") and line[:-6] for line in lines),
            f"{label}: malformed terse list output")
    names = [line[:-6] for line in lines]
    require(len(names) == len(set(names)), f"{label}: duplicate listed test")
    return set(names)


def compiler_artifacts(raw):
    result = []
    for line in raw.decode("utf-8").splitlines():
        try:
            row = json.loads(line, object_pairs_hook=unique_object)
        except (ValueError, UnicodeError):
            continue
        if isinstance(row, dict) and row.get("reason") == "compiler-artifact" and row.get("executable"):
            result.append(row)
    return result


def source_child(source, path):
    require(isinstance(path, str) and Path(path).is_absolute()
            and Path(path).is_relative_to(source) and ".." not in Path(path).parts,
            f"compiler source is outside the frozen source: {path}")


def bind_stage_commands(gate, root, source, module):
    """Bind the complete actual r3 argv, including jobs=1 and sandbox prefix."""
    binary = gate["library_binary"]
    prefix = ["/usr/bin/bwrap", "--unshare-user", "--uid", "1000", "--gid", "1000",
              "--dev-bind", "/", "/", "--bind", str(root / "candidate-test-tmp"), "/tmp",
              "--unsetenv", "SSMCP_OUTPUT_RELOAD", "--setenv", "TMPDIR", "/tmp",
              "--chdir", str(source)]
    private = [binary, "--exact", "--test-threads=4"]
    for name in module.HOST_TESTS:
        private.extend(("--skip", name))
    commands = {
        "release-policy": ["python3", "-m", "unittest", "discover", "-s", "scripts", "-p", "test_release.py", "-v"],
        "deployment-policy": ["python3", "-W", "error", "-m", "unittest", "discover", "-s", "scripts", "-p", "test_server_deploy.py", "-v"],
        "fmt": ["cargo", "fmt", "--all", "--", "--check"],
        "library-compile": ["cargo", "test", "--offline", "--locked", "--lib", "--no-run", "--message-format=json", "--jobs", "1"],
        "library-private": prefix + private,
        "library-host": [binary, "--exact", "--test-threads=1", *module.HOST_TESTS],
        "clippy": ["cargo", "clippy", "--offline", "--locked", "--workspace", "--all-targets", "--jobs", "1", "--", "-D", "warnings"],
        "windows-gnu-clippy": ["cargo", "clippy", "--offline", "--locked", "--target", "x86_64-pc-windows-gnu", "--workspace", "--all-targets", "--jobs", "1", "--", "-D", "warnings"],
        "integration-compile": ["cargo", "test", "--offline", "--locked", "--package", "ssmcp", "--no-run", "--message-format=json", "--jobs", "1"],
        "library-code-mode-ignored": prefix + [binary, "--ignored", "--exact", "--test-threads=1", *sorted(gate["library_test_names"]["ignored_code_mode"])],
        "release": ["cargo", "build", "--offline", "--locked", "--release", "--message-format=json", "--bins", "--jobs", "1"],
        "decoder": ["cargo", "build", "--offline", "--locked", "--release", "--message-format=json", "--example", "vt_snapshot", "--jobs", "1"],
    }
    for name in module.INTEGRATION_TESTS:
        commands["integration-compile"].extend(("--test", name))
        target = gate["integration_binaries"][name]
        tail = ([target, "--ignored", "--exact", module.ZUSE_WORKER_TEST, "--test-threads=1"]
                if name == "zuse_worker_entry" else [target, "--test-threads=4"])
        commands["integration-" + name] = prefix + tail
    for name in module.INTEGRATION_IGNORED:
        commands[f"integration-{name}-ignored"] = prefix + [gate["integration_binaries"][name], "--ignored", "--test-threads=1"]
    require(set(commands) == set(module.EXPECTED_GATES), "incomplete reviewed stage command inventory")
    for check in gate["checks"]:
        require(check.get("command") == commands[check["name"]],
                f"{check['name']}: argv differs from the immutable r3 driver")


def bind_compilation(gate, source, raw_logs, evidence, module, probe):
    metadata = json.loads(probe("cargo-metadata", ["cargo", "metadata", "--offline", "--locked",
                          "--no-deps", "--format-version", "1", "--manifest-path",
                          str(source / "Cargo.toml")]), object_pairs_hook=unique_object)
    packages = [item for item in metadata["packages"] if item.get("name") == "ssmcp"
                and item.get("manifest_path") == str(source / "Cargo.toml")]
    require(len(packages) == 1 and metadata["workspace_root"] == str(source)
            and metadata["target_directory"] == str(CARGO_TARGET),
            "Cargo metadata does not identify the final frozen workspace")
    package = packages[0]
    require(package["id"] in metadata["workspace_members"], "ssmcp is not a workspace member")
    targets = [item for item in package["targets"] if item.get("kind") == ["test"]]
    tests = {item["name"]: item["src_path"] for item in targets}
    require(len(targets) == len(tests) and set(tests) == set(module.INTEGRATION_TESTS),
            "Cargo metadata has a different integration target inventory")
    for path in tests.values():
        source_child(source, path)
    client = [item for item in package["targets"] if item.get("name") == "ssmcp"
              and item.get("kind") == ["bin"]]
    require(len(client) == 1 and client[0]["src_path"] == str(source / "src/bin/ssmcp.rs"),
            "Cargo metadata has a different client source")
    expected = {"package_id": package["id"], "manifest_path": package["manifest_path"],
                "workspace_root": str(source), "target_directory": metadata["target_directory"],
                "test_targets": tests, "client_source": client[0]["src_path"]}
    require(gate.get("cargo_metadata") == expected, "gate metadata projection differs from raw Cargo output")

    def select(stage, name, kind, is_test):
        found = [item for item in compiler_artifacts(raw_logs[stage])
                 if item.get("package_id") == package["id"] and item["target"].get("name") == name
                 and item["target"].get("kind") == [kind]
                 and item.get("profile", {}).get("test") is is_test]
        require(len(found) == 1, f"{stage}: missing or duplicate compiler artifact for {name}")
        item = found[0]
        require(item.get("manifest_path") == package["manifest_path"]
                and item["executable"] in item.get("filenames", []), f"{name}: artifact provenance differs")
        source_child(source, item["target"]["src_path"])
        return item

    library = select("library-compile", "ssmcp", "lib", True)
    require(library["executable"] == gate.get("library_binary"), "library compiler path differs")
    lib = evidence.artifact(gate.get("library_artifact"), "library", executable=True)
    require(lib["path"] == gate["library_binary"] and lib["sha256"] == gate["library_sha256"],
            "library artifact projections differ")
    for name, path in tests.items():
        item = select("integration-compile", name, "test", True)
        require(item["target"]["src_path"] == path
                and item["executable"] == gate["integration_binaries"][name],
                f"{name}: compiled from another test source or executable")
        evidence.artifact(gate["integration_artifacts"][name], name, executable=True)
    helper = select("integration-compile", "ssmcp", "bin", False)
    helper_record = gate.get("workspace_bridge_helper", {})
    require(helper_record.get("source_stage") == "integration-compile"
            and helper_record.get("compiler_artifact") == helper
            and helper["executable"] == str(Path(metadata["target_directory"]) / "debug/ssmcp"),
            "workspace bridge helper is not the same integration build artifact")
    helper_artifact = evidence.artifact(helper_record.get("artifact"), "workspace helper", executable=True)
    require(helper_artifact["path"] == helper["executable"], "workspace helper path differs")
    proofs = gate.get("workspace_bridge_helper_checks")
    require(isinstance(proofs, dict) and set(proofs) == {
        "integration-workspace_bridge", "integration-workspace_bridge-ignored"},
        "workspace helper lacks the two executed-stage proofs")
    for proof in proofs.values():
        require(proof == {"before": helper_artifact, "after": helper_artifact},
                "workspace helper changed across its test stage")
    products = {}
    for name in ("ssmcp", "ssmcpd", "ssmcp-frontend", "vt_snapshot"):
        stage, kind = ("decoder", "example") if name == "vt_snapshot" else ("release", "bin")
        item = select(stage, name, kind, False)
        require(str(item["profile"].get("opt_level")) in {"1", "2", "3", "s", "z"},
                f"{name}: not an optimized non-test artifact")
        products[name] = evidence.artifact(gate["binaries"][name], name, executable=True)
        require(products[name]["path"] == item["executable"], f"{name}: product compiler path differs")
        require(gate["optimized_build_artifacts"][name] == {
            "source_path": item["target"]["src_path"], "package_id": package["id"],
            "profile": item["profile"], "executable": item["executable"]},
            f"{name}: optimized-artifact projection differs")
    return {"library": lib, "products": products, "metadata": expected}


def bind_runtime(gate, root, source, evidence, probe):
    tools = gate.get("runtime_tools")
    require(isinstance(tools, dict) and set(tools) == set((*NATIVE_TOOLS, *DESKTOP_TOOLS))
            and gate.get("runtime_tools_final") == tools, "runtime tool inventory changed")
    bindings = gate.get("runtime_bindings", {})
    prefix = root / "native-bin"
    require(bindings.get("path_prefix") == str(prefix)
            and bindings.get("node") == tools["node"]["path"], "runtime PATH/Node binding differs")
    require(Path(bindings.get("outer_bwrap", "")).resolve(strict=True)
            == Path(tools["bwrap"]["path"]), "outer bwrap differs from tested bwrap")
    normalized = {}
    for name, entry in tools.items():
        normalized[name] = evidence.artifact(entry, name, executable=True)
        with Path(entry["path"]).open("rb") as stream:
            require(stream.read(4) == b"\x7fELF", f"{name}: expected a native binary, not a shim")
        alias = prefix / name
        require(alias.is_symlink() and alias.resolve(strict=True) == Path(entry["path"]),
                f"runtime PATH alias differs: {name}")
        if name in NATIVE_TOOLS:
            require(isinstance(entry.get("version"), str) and entry["version"],
                    f"missing {name} version")
            for phase in ("before", "after"):
                output = probe(f"version-{phase}-{name}", [entry["path"], "--version"])
                require(output.decode("utf-8").strip() == entry["version"],
                        f"{name}: version probe differs from runtime receipt")
        else:
            require(entry.get("path_entry") == str(alias), f"{name}: desktop alias differs")
    runner = bindings.get("runner")
    require(isinstance(runner, dict) and runner.get("path") == str(source / "src/code_mode.js")
            and gate.get("code_mode_runner_final") == runner, "code-mode runner binding differs")
    evidence.artifact(runner, "code-mode runner")
    desktop = {name: tools[name] for name in DESKTOP_TOOLS}
    require(gate.get("zuse_desktop_tools") == {"before": desktop, "after": desktop},
            "zuse worker did not bind the same six desktop tools before and after")
    require(gate.get("test_environment_exceptions") == {"integration-server_runtime": {
        "unset": ["SSMCP_NODE"],
        "reason": "The dependency-failure fixture must discover Node through its empty PATH."}},
        "unexpected or absent negative-fixture environment exception")
    return {"tools": normalized, "bindings": bindings}


def validate_launch(evidence, path, expected_hash, gate, root, source_revision, gate_hash):
    """Bind the real 99b7 launcher exit to its claim, launch and driver output."""
    require(root == GATE_ROOT and Path(path) == LAUNCH_ROOT / "exit.json",
            "expected the actual r3 launcher exit receipt")
    result = evidence.json(path, expected_hash)
    initial = evidence.json(LAUNCH_ROOT / "launch.json")
    claim = evidence.json(LAUNCH_ROOT / "claim.json")
    evidence.read(LAUNCH_ROOT / "run_bound.py", LAUNCHER_SHA256)
    evidence.read(root / "candidate-gates.json", gate_hash)
    initial_keys = {
        "source_revision", "worktree", "started_at", "command", "input_paths", "hashes_before",
        "launcher_sha256", "environment", "versions", "umask", "invocation_id", "exclusive_target_lock",
    }
    final_keys = {
        "exit_code", "hashes_after", "gate_status", "gate_run_id", "gate_receipt_sha256",
        "worktree_head_after", "worktree_status_after", "status", "finished_at",
    }
    require(isinstance(initial, dict) and set(initial) == initial_keys
            and isinstance(result, dict) and set(result) == initial_keys | final_keys
            and same_json({key: result[key] for key in initial_keys}, initial),
            "launcher exit does not preserve the actual initial launch record")
    require(result["source_revision"] == source_revision and result["status"] == "passed"
            and type(result["exit_code"]) is int and result["exit_code"] == 0
            and result["gate_status"] == "passed" and result["gate_receipt_sha256"] == gate_hash
            and isinstance(gate.get("run_id"), str) and re.fullmatch(r"[0-9a-f]{32}", gate["run_id"])
            and result["gate_run_id"] == gate["run_id"]
            and result["worktree_head_after"] == source_revision and result["worktree_status_after"] == "",
            "launcher did not successfully complete this exact clean-source gate run")
    require(isinstance(claim, dict) and set(claim) == {"source_revision", "claimed_at", "pid"}
            and claim["source_revision"] == source_revision
            and type(claim["pid"]) is int and claim["pid"] > 0,
            "actual launcher claim is missing or belongs to another source")
    times = [claim["claimed_at"], result["started_at"], gate.get("started_at"),
             gate.get("finished_at"), result["finished_at"]]
    require(all(type(value) in (int, float) and math.isfinite(value) and value > 0 for value in times)
            and times == sorted(times), "launcher/gate time sequence is incomplete")
    worktree = Path(result["worktree"])
    require(worktree.is_absolute() and str(worktree) == gate.get("root_worktree")
            and ".." not in worktree.parts, "launcher worktree differs from the gate source worktree")
    command = ["/usr/bin/python3", "-u", str(root / "run_gates.py"), source_revision,
               "--worktree", str(worktree), "--submodule-root", str(OBJECT_ROOT)]
    environment = {"RUSTC_WRAPPER": str(RUST_WRAPPER), "CARGO_BUILD_JOBS": "1",
                   "CARGO_HOME": str(CARGO_HOME), "CARGO_TARGET_DIR": str(CARGO_TARGET)}
    require(result["command"] == command and result["environment"] == environment
            and result["launcher_sha256"] == LAUNCHER_SHA256
            and result["umask"] == "0022" and result["exclusive_target_lock"] is True,
            "launcher command, wrapper, jobs or exclusive-target binding differs")
    require(result["invocation_id"] is None or (isinstance(result["invocation_id"], str)
            and re.fullmatch(r"[0-9a-f]{32}", result["invocation_id"])),
            "malformed launcher invocation identity")
    require(isinstance(result["versions"], dict) and set(result["versions"]) == {"cargo", "rustc"}
            and all(isinstance(value, str) and value.startswith(name + " ")
                    for name, value in result["versions"].items()), "missing actual build-tool version probes")
    inputs = result["input_paths"]
    require(isinstance(inputs, dict) and set(inputs) == set(LAUNCH_HASHES)
            and inputs["driver"] == str(root / "run_gates.py")
            and inputs["wrapper"] == str(RUST_WRAPPER)
            and inputs["cargo_lock"] == str(worktree / "Cargo.lock")
            and inputs["cargo_config"] in {str(CARGO_HOME / "config.toml"), str(CARGO_HOME / "config")}
            and result["hashes_before"] == result["hashes_after"] == LAUNCH_HASHES,
            "launcher input paths or before/after hashes differ from the reviewed contract")
    for name, input_path in inputs.items():
        evidence.read(input_path, LAUNCH_HASHES[name])
    evidence.read(root / "source/Cargo.lock", LAUNCH_HASHES["cargo_lock"])
    raw_output = evidence.read(LAUNCH_ROOT / "stdout.log")
    evidence.read(LAUNCH_ROOT / "stderr.log")
    output = [json.loads(line, object_pairs_hook=unique_object)
              for line in raw_output.decode("utf-8").splitlines() if line.strip()]
    expected_output = []
    for row in gate["checks"]:
        expected_output.extend((
            {"started": row["name"], "command": row["command"]},
            {"completed": row["name"], "exit_code": row["exit_code"],
             "seconds": row["seconds"], "test_results": row.get("test_results")},
        ))
    expected_output.append({"status": "passed", "source_revision": source_revision,
                            "receipt": str(root / "candidate-gates.json"),
                            "library_binary": gate["library_binary"], "binaries": gate["binaries"]})
    require(same_json(output, expected_output),
            "actual launcher stdout does not contain this complete ordered gate execution")
    return {"path": str(path), "sha256": expected_hash, "launcher_sha256": LAUNCHER_SHA256,
            "gate_receipt_sha256": gate_hash, "gate_run_id": result["gate_run_id"],
            "source_revision": source_revision, "worktree": str(worktree),
            "environment": environment, "input_paths": inputs, "hashes": dict(LAUNCH_HASHES),
            "versions": result["versions"], "invocation_id": result["invocation_id"],
            "status": "passed", "exit_code": 0}


def validate_r3_gate(gate_path, expected_gate_sha256, source_revision,
                     inventory_path, inventory_sha256, launch_path, launch_sha256):
    """Return immutable evidence paths and runtime inputs for P1 and UI runners.

    The caller must copy or recheck every returned evidence_files entry before
    and after execution, and separately reconstruct the five source archives.
    """
    evidence = Evidence()
    gate = evidence.json(gate_path, expected_gate_sha256)
    require(gate.get("status") == "passed" and gate.get("source_revision") == source_revision,
            "not a passed gate for the requested final source")
    require(gate.get("script_sha256") == DRIVER_SHA256
            and gate.get("template_sha256") == TEMPLATE_SHA256, "unreviewed gate driver/template")
    manifest = gate.get("source_manifest", {})
    root = Path(manifest.get("path", "")).parent
    require(root.is_absolute() and Path(manifest["path"]) == root / "source-manifest.json",
            "missing exact build source manifest")
    source = root / "source"
    evidence.read(root / "run_gates.py", DRIVER_SHA256)
    evidence.read(gate.get("template", ""), TEMPLATE_SHA256)
    recorded_source = evidence.json(manifest["path"], manifest.get("sha256"))
    require(isinstance(manifest.get("sha256"), str)
            and re.fullmatch(r"[0-9a-f]{64}", manifest["sha256"])
            and isinstance(recorded_source, dict) and type(manifest.get("entries")) is int
            and len(recorded_source) == manifest["entries"],
            "source manifest entry count differs")
    require(gate.get("root_worktree_head") == {
        "before_export": source_revision, "after_export": source_revision, "final": source_revision},
        "gate was not frozen from one clean revision")
    module = load_inventory(evidence, inventory_path, inventory_sha256)
    checks = gate.get("checks")
    require(isinstance(checks, list) and [row.get("name") for row in checks] == list(module.EXPECTED_GATES),
            "gate stage inventory differs")
    raw_logs = {}
    for check in checks:
        name = check["name"]
        path = root / "logs" / f"candidate2-{name}.log"
        require(check.get("log") == str(path), f"{name}: log path differs")
        raw = evidence.read(path)
        require(check.get("tail") == raw.decode("utf-8", errors="replace").splitlines()[-12:],
                f"{name}: recorded log tail differs from actual bytes")
        raw_logs[name] = raw
    inventory = module.validate_inventory(
        gate, lambda check: module.parent_result(
            check, raw_logs[check["name"]].decode("utf-8", errors="replace")))
    require(inventory.get("contract_baseline_sha256") == DRIVER_SHA256,
            "inventory result names another gate contract")
    bind_stage_commands(gate, root, source, module)
    probes = gate.get("probes", {})
    consumed_probes = set()

    def probe(label, command):
        consumed_probes.add(label)
        row = probes.get(label)
        require(isinstance(row, dict) and type(row.get("exit_code")) is int and row["exit_code"] == 0
                and row.get("command") == command and row.get("cwd") == str(source),
                f"{label}: actual probe command/cwd/result differs")
        values = {}
        for channel in ("stdout", "stderr"):
            path = root / "logs" / f"probe-{label}.{channel}"
            require(row.get(channel) == str(path), f"{label}: probe output path differs")
            values[channel] = evidence.read(path)
        return values["stdout"]

    def listed(label, command, names):
        raw = probe("list-" + label, [*command, "--list", "--format", "terse"])
        require(listed_names(raw, label) == set(names), f"{label}: inventory differs from real --list")

    lib = gate["library_binary"]
    library = gate["library_test_names"]
    listed("library-all", [lib], library["all"])
    listed("library-ignored", [lib, "--ignored"], library["ignored"])
    private = [lib, "--exact", "--test-threads=4"]
    for name in module.HOST_TESTS:
        private.extend(("--skip", name))
    listed("library-private", private, library["private"])
    listed("library-host", [lib, "--exact", "--test-threads=1", *module.HOST_TESTS], library["host"])
    listed("library-code-mode-selection", [lib, "--ignored", "--exact", "--test-threads=1",
           *sorted(library["ignored_code_mode"])], library["ignored_code_mode"])
    for name in module.INTEGRATION_TESTS:
        binary = gate["integration_binaries"][name]
        entry = gate["integration_test_names"][name]
        listed(f"integration-{name}-all", [binary, "--test-threads=4"], entry["all"])
        listed(f"integration-{name}-ignored", [binary, "--ignored", "--test-threads=1"], entry["ignored"])
    compilation = bind_compilation(gate, source, raw_logs, evidence, module, probe)
    runtime = bind_runtime(gate, root, source, evidence, probe)
    require(set(probes) == consumed_probes, "gate probe inventory has unverified entries")
    launch = validate_launch(evidence, launch_path, launch_sha256, gate, root, source_revision,
                             expected_gate_sha256)
    return {"schema": "ssmcp.r3.gate-binding.v1", "source_revision": source_revision,
            "driver_sha256": DRIVER_SHA256, "evidence_files": dict(evidence.files),
            "content_files": dict(evidence.content_files),
            "inventory_result": inventory, "runtime_tools": runtime["tools"],
            "runtime_bindings": runtime["bindings"], "compilation": compilation,
            "launch": launch, "gate_root": str(root), "source_path": str(source),
            "raw_log_binding": "observed hashes at consumer verification; producer has no per-log hash field"}
